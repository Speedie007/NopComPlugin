﻿using Nop.Plugin.Payments.PayFastComplete.Services.TransactionHistoryServices.Models;
using Nop.Services.News;
using OfficeOpenXml.ConditionalFormatting;
using System;
using System.Collections.Generic;
using System.IO;
using System.Security.Cryptography.X509Certificates;
using System.Text;

namespace Nop.Plugin.Payments.PayFastComplete.Extensions
{
    public static class PayFastCompleteTransactionalHistroyExtensions
    {

        public static void PopulateTransactionalHistoryRecords(this List<PayFastTransactionHistoryDataExtractionRecordModel> TransactionalHistoryRecordDataSet, List<string[]> TransactionalHistoryDataSet)
        {
            foreach (string[] dataSet in TransactionalHistoryDataSet)
            {
                // Add extracted values to the data set model
                TransactionalHistoryRecordDataSet.Add(new PayFastTransactionHistoryDataExtractionRecordModel()
                {
                    TransactionDateTimeStamp = Convert.ToDateTime(dataSet[0]),//Date -0 
                    TransactionType = dataSet[1],//Type - 1
                    TransactionMethod = dataSet[2],//Sign - 2
                    TransactionUserReference = dataSet[3],//Party - 3
                    TransactionName = dataSet[4],//Name - 4
                    TransactionDescription = dataSet[5],//Description - 5
                    TransactionCurrency = dataSet[6],//Currency - 6
                    TransactionFundingSource = dataSet[7],//Funding Type - 7
                    TransactionGrossAmount = decimal.TryParse(dataSet[8].Replace(",", "").Replace(".", ","), out decimal value8) ? value8 : 0,//Gross - 8
                    TransactionFee = decimal.TryParse(dataSet[9].Replace(",", "").Replace(".", ","), out decimal value9) ? value9 : 0,//Fee - 9
                    TransactionNetAmount = decimal.TryParse(dataSet[10].Replace(",", "").Replace(".", ","), out decimal value10) ? value10 : 0,//Net - 10
                    TranactionAccountBalance = decimal.TryParse(dataSet[11].Replace(",", "").Replace(".", ","), out decimal value11) ? value11 : 0,//Balance - 11
                    MerchantTranactionReference = dataSet[12],//M Payment ID -12
                    PayFastTranactionReference = dataSet[13],//PF Payment ID -13
                    CustomStringProperty1 = dataSet[14],// - 14
                    CustomIntegerProperty1 = int.TryParse(dataSet[15], out int value15) ? value15 : 0, // -15
                    CustomStringProperty2 = dataSet[16],// - 16
                    CustomIntegerProperty2 = int.TryParse(dataSet[17], out int value17) ? value17 : 0, //1- 17
                    CustomStringProperty3 = dataSet[18], //-18
                    CustomStringProperty4 = dataSet[19],//-19
                    CustomStringProperty5 = dataSet[20],//-20
                    CustomIntegerProperty3 = int.TryParse(dataSet[21], out int value21) ? value21 : 0,//-21
                    CustomIntegerProperty4 = int.TryParse(dataSet[22], out int value22) ? value22 : 0,//-22
                    CustomIntegerProperty5 = int.TryParse(dataSet[23], out int value23) ? value23 : 0//-23
                });
            }
        }

        public static List<string[]> ExtractTransactionalHistoryData(this string CSVEncodedString)
        {

            /*TODO: Build Result object for the process and return the result with the built dataset/
             * ***************************************************************************************/
            List<string[]> TransactionalHistoryRecords = new List<string[]>();
            int CurrentDataIndex = 0;
            string[] ExtractedDataItems;

            char chQuotation = '"';
            char chComma = ',';

            #region Internal utility methods
            bool IsQuotationWrappedValue(char x)
            {
                return chQuotation.Equals(x);
            }
            void RemovePunctuationOrCommaCharater(ref string CurrentLineItem)
            {
                if (CurrentLineItem.Length > 1)
                {

                    if ((chComma.Equals(Convert.ToChar(CurrentLineItem.Substring(0, 1))) && chComma.Equals(Convert.ToChar(CurrentLineItem.Substring(1, 1)))))
                    {
                        AddDataItemToCache("");
                    }
                    CurrentLineItem = CurrentLineItem.Substring(1, CurrentLineItem.Length - 1);//remove/trim off the first quotaion or comma
                }
                else
                {
                    if (chComma.Equals(Convert.ToChar(CurrentLineItem)))
                    {
                        AddDataItemToCache("");
                    }
                    CurrentLineItem = "";
                }

            }
            void AddQuotationWrappedDataItemToCache(ref string CurrentLineItem)
            {
                RemovePunctuationOrCommaCharater(ref CurrentLineItem);//remove/trim off the first quotaion
                AddDataItemToCache(CurrentLineItem.Substring(0, CurrentLineItem.IndexOf(chQuotation)));// add data item
                CurrentLineItem = CurrentLineItem.Substring(CurrentLineItem.IndexOf(chQuotation), CurrentLineItem.Length - CurrentLineItem.IndexOf(chQuotation));
                RemovePunctuationOrCommaCharater(ref CurrentLineItem);//remove/trim off the second quotaion

            }
            void AddNormalDataItemToCache(ref string CurrentLineItem)
            {
                //if (CurrentLineItem.IndexOf(chComma) != -1)
                //{
                AddDataItemToCache(CurrentLineItem.Substring(0, CurrentLineItem.IndexOf(chComma)));
                CurrentLineItem = CurrentLineItem.Substring(CurrentLineItem.IndexOf(chComma), CurrentLineItem.Length - CurrentLineItem.IndexOf(chComma));
            }
            void AddDataItemToCache(string DataItem)
            {
                ExtractedDataItems[CurrentDataIndex] = DataItem;
                CurrentDataIndex += 1;
            }
            #endregion


            //Has Data to extract
            if (CSVEncodedString.Length > 0)
            {
                using (StringReader reader = new StringReader(CSVEncodedString))
                {
                    //Remove the Header Line
                    var yy = reader.ReadLine();


                    while (true)
                    {
                        string LineToProcess = reader.ReadLine();
                        if (LineToProcess != null)
                        {
                            //reset DataSet insertion index
                            CurrentDataIndex = 0;
                            ExtractedDataItems = new string[24];

                            while (LineToProcess.Length > 0)
                            {
                                //determin if the current first charater is a form of punctuation.
                                if (Char.IsPunctuation(LineToProcess, 0))
                                {
                                    //determin if its a Quotation Mark or comma.
                                    if (IsQuotationWrappedValue(LineToProcess.Substring(0, 1).ToCharArray(0, 1)[0]))
                                    {
                                        //process quotation wrapped dataItem
                                        AddQuotationWrappedDataItemToCache(ref LineToProcess);
                                    }
                                    else
                                    {
                                        //Remove comma delimiter so it can expose the next data item
                                        RemovePunctuationOrCommaCharater(ref LineToProcess);
                                    }
                                }
                                else
                                {
                                    //process normal data item
                                    AddNormalDataItemToCache(ref LineToProcess);
                                }
                            }

                            //Store Transactional History Meta-Data in the cache.
                            TransactionalHistoryRecords.Add(ExtractedDataItems);
                        }
                        else
                        {
                            break;
                        }
                    }
                }
            }

            return TransactionalHistoryRecords;
        }
    }
}
