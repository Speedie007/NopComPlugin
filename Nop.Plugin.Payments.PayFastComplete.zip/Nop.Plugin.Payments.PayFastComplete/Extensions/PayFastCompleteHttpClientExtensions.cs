﻿using Nop.Plugin.Payments.PayFastComplete.Services;
using Nop.Plugin.Payments.PayFastComplete.Services.HttpClientServices;
using System;
using System.Collections.Generic;
using System.Net;
using System.Net.Http;
using System.Text;

namespace Nop.Plugin.Payments.PayFastComplete.Extensions
{
    public static class PayFastCompleteHttpClientExtensions
    {

        public static string GetHttpProcessingErrorMessage(this HttpResponseMessage httpResponseMessage)
        {
            return GetMessageFromSwitch(httpResponseMessage.StatusCode);

            string GetMessageFromSwitch(HttpStatusCode statusCode) => statusCode switch
            {

                HttpStatusCode.BadRequest => "Error Connecting to the PayFast API Gateway - Internal Error (Http Status Code : 400 BadRequest)",
                HttpStatusCode.Unauthorized => "Error Connecting to the PayFast API Gateway - Internal Error (Http Status Code : 401 Unauthorized)",
                HttpStatusCode.NotFound => "Error Connecting to the PayFast API Gateway - Internal Error (Http Status Code : 404 NotFound)",
                HttpStatusCode.InternalServerError => "Error Connecting to the PayFast API Gateway - Internal Error (Http Status Code : 500 ServiceUnavailable)",
                _ => $"Http Status Code : {statusCode.ToString()} - Unknown Error."
            };
        }
        
        
    }
}
