﻿using LinqToDB.Common;
using LinqToDB.Configuration;
using Nop.Core;
using Nop.Core.Domain.Catalog;
using Nop.Core.Infrastructure;
using Nop.Plugin.Payments.PayFastComplete.Infrastructure.Common.Enumerations;
using Nop.Plugin.Payments.PayFastComplete.Services.PayFastApiClientServices.Components.Attributes;
using Nop.Plugin.Payments.PayFastComplete.Services.PayFastApiClientServices.Components.Enumerations;
using Nop.Plugin.Payments.PayFastComplete.Services.PayFastApiClientServices.Models.Api;
using Nop.Plugin.Payments.PayFastComplete.Services.PayFastApiClientServices.Models.Api.Requests.AdHocSubscription;
using Nop.Plugin.Payments.PayFastComplete.Services.PayFastApiClientServices.Models.Api.Requests.NormalSubscription;
using Nop.Plugin.Payments.PayFastComplete.Services.PayFastApiClientServices.Models.Api.Requests.SubscriptionCommon;
using Nop.Plugin.Payments.PayFastComplete.Services.PayFastApiClientServices.Models.Api.Requests.TransactionalHistory;
using Nop.Plugin.Payments.PayFastComplete.Services.PayFastApiClientServices.Models.Api.Results;
using Nop.Plugin.Payments.PayFastComplete.Settings;
using Nop.Services.Configuration;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Reflection;
using System.Security.Cryptography;
using System.Text;

namespace Nop.Plugin.Payments.PayFastComplete.Extensions
{
    public static class PayFastCompleteExtensions
    {
        public static EnumPayFastRecuringFrequency CheckRecurringPeriodMatches(RecurringProductCyclePeriod RecurringProdCycPer, int CycleLength)
        {
            return FindPossibleMatchingPayFastFrequency(RecurringProdCycPer);
            EnumPayFastRecuringFrequency FindPossibleMatchingPayFastFrequency(RecurringProductCyclePeriod aRecurringProdCycPer) => aRecurringProdCycPer switch
            {
                RecurringProductCyclePeriod.Days when CycleLength == 30 => EnumPayFastRecuringFrequency.Monthly,
                RecurringProductCyclePeriod.Days when CycleLength == 90 => EnumPayFastRecuringFrequency.Quarterly,
                RecurringProductCyclePeriod.Days when CycleLength == 180 => EnumPayFastRecuringFrequency.Biannual,
                RecurringProductCyclePeriod.Days when CycleLength == 356 => EnumPayFastRecuringFrequency.Annual,
                RecurringProductCyclePeriod.Months when CycleLength == 1 => EnumPayFastRecuringFrequency.Monthly,
                RecurringProductCyclePeriod.Months when CycleLength == 4 => EnumPayFastRecuringFrequency.Quarterly,
                RecurringProductCyclePeriod.Months when CycleLength == 6 => EnumPayFastRecuringFrequency.Biannual,
                RecurringProductCyclePeriod.Months when CycleLength == 12 => EnumPayFastRecuringFrequency.Annual,
                RecurringProductCyclePeriod.Weeks when CycleLength == 4 => EnumPayFastRecuringFrequency.Monthly,
                RecurringProductCyclePeriod.Weeks when CycleLength == 12 => EnumPayFastRecuringFrequency.Quarterly,
                RecurringProductCyclePeriod.Weeks when CycleLength == 24 => EnumPayFastRecuringFrequency.Biannual,
                RecurringProductCyclePeriod.Weeks when CycleLength == 52 => EnumPayFastRecuringFrequency.Annual,
                RecurringProductCyclePeriod.Years when CycleLength == 1 => EnumPayFastRecuringFrequency.Annual,
                _ => EnumPayFastRecuringFrequency.UnDefinedFrequency
            };
        }
        public static void PreProcessApiRequestBody(this PayFastApiRequestBaseModel request)
        {


            /*Gets the required services need manually instead of using the Independency Inject,
             * this is because a static class in the case the extension class is a static class 
             * which cannot define a constuctor as one would in a normal class.
             * *******************************************************************************************/
            var _SettingService = EngineContext.Current.Resolve<ISettingService>();
            var _StoreService = EngineContext.Current.Resolve<IStoreContext>();

            /*Manually Load the Api settings for the seleted/Current Active Store.
             * ********************************************************************/
            var _payFastSettings = _SettingService.LoadSetting<PayFastCompleteSettings>(_StoreService.CurrentStore.Id);

            request.TargetUrl = BuildEndPoint(request);

            if (request.ActionType == EnumHttpVerbs.GET)
            {
                foreach (KeyValuePair<string, string> kvp in request.RequestBodyMetaData)
                {
                    request.TargetUrl = request.TargetUrl.Contains("?") ? $"{request.TargetUrl}&{kvp.Key}={kvp.Value}" : $"{request.TargetUrl}?{kvp.Key}={kvp.Value}";
                }
            }
            /*if you are currently testing the system in the sandbox we add the testing=true to the End-point Url.
             * ****************************************************************************************************/
            if (_payFastSettings.UseSandbox)
            {
                request.TargetUrl = request.TargetUrl.Contains("?") ? $"{request.TargetUrl}&{_payFastSettings.ApiSubmissionTestingUrl}" : $"{request.TargetUrl}?{_payFastSettings.ApiSubmissionTestingUrl}";
            }

            /*Internal Method used to determine which End-Point to assign to the request.
             * The End-Point(Url) is determined by the type of Request object being processed.
             * The End-Point is stored in the PayFast- Settings Object internally in the Nopcommerce database.
             * *************************************************************************************************/
            string BuildEndPoint(object request) => request switch
            {
                #region Transactional History
                PayFastApiTransactionHistoryDailyModel RequestToSend => _payFastSettings.ApiTransactionHistoryForDailyUrl,
                PayFastApiTransactionWeeklyHistoryModel RequestToSend => _payFastSettings.ApiTransactionHistoryForWeeklyUrl,
                PayFastApiTransactionMonthlyHistoryModel RequestToSend => _payFastSettings.ApiTransactionHistoryForMonthlyUrl,
                PayFastApiTransactionHistoryRequestModel RequestToSend => _payFastSettings.ApiTransactionHistoryForPeriodUrl,
                #endregion
                #region Recurring Billing 
                PayFastApiAdHocChargeModel RequestToSend => string.Format(_payFastSettings.ApiRecurringBilling_ADHOC_CHARGE_SubscriptionUrl, RequestToSend.SubscriptionToken),
                PayFastApiSubscriptionCommonCancelModel RequestToSend => string.Format(_payFastSettings.ApiRecurringBilling_COMMON_CANCEL_SubscriptionUrl, RequestToSend.SubscriptionToken),
                PayFastApiSubscriptionCommonFetchModel RequestToSend => string.Format(_payFastSettings.ApiRecurringBilling_COMMON_FETCH_SubscriptionUrl, RequestToSend.SubscriptionToken),
                PayFastApiNormalSubscriptionPauseModel RequestToSend => string.Format(_payFastSettings.ApiRecurringBilling_NORMAL_PAUSE_SubscriptionUrl, RequestToSend.SubscriptionToken),
                PayFastApiNormalSubscriptionUnpauseModel RequestToSend => string.Format(_payFastSettings.ApiRecurringBilling_NORMAL_UNPAUSE_SubscriptionUrl, RequestToSend.SubscriptionToken),
                PayFastApiNormalSubscriptionUpdateModel RequestToSend => string.Format(_payFastSettings.ApiRecurringBilling_NORMAL_UPDATE_SubscriptionUrl, RequestToSend.SubscriptionToken),
                #endregion
                #region Common

                #endregion

                #region Testing
                PayFastApiPingRequestModel RequestToSend => _payFastSettings.ApiPingUrl,
                #endregion
                _ => ""
            };
        }


        public static BuildApiRequestResult BuildApiRequest(this HttpClient client, PayFastApiRequestBaseModel request)

        {
            /*Result returned to be sued to to determine of the building of the request properties was successful.
            *-This includes setting of the Http-Request header attributes.
            ***************************************************************/
            BuildApiRequestResult result = new BuildApiRequestResult();
            //build HTTPClient Connection Properties

            /*Clears the Http-Clients Header from any previously set attributes.
             * *******************************************************************/
            client.DefaultRequestHeaders.Clear();

            /*Gets the type of object in the context of this method Gets the Type of Request Object
             * Here Relection is used to decomplied Each type of "Request Object/Model" passed through this methood.
             * *****************************************************************************************************/
            Type entityType = request.GetType();//Eg. the PayFastApiPingRequestModel 
            PropertyInfo[] Props = entityType.GetProperties();
            foreach (var prop in Props)
            {
                var attrib = prop.GetCustomAttribute<PayFastApiRequestComponent>();
                if (attrib != null)
                {
                    if (attrib.RequestComponentUsage == EnumRequestComponentUsage.Header)
                    {
                        //adds the header attributes from the model defined in the base Request Model - PayFastApiRequestBaseModel
                        if (!(prop.GetValue(request) is null))
                        {
                            client.DefaultRequestHeaders.Add(attrib.RequestKeyValue, prop.GetValue(request).ToString());
                        }
                    }
                    else
                    {
                        /*add to list that will Form the Body of the request 
                         * -Defined in each Derived Request Type from the Abstract Base Request. Eg - PayFastApiTransactionHistoryRequestModel 
                         * *********************************************************************/
                        if (!(prop.GetValue(request) is null))
                        {
                            ///<summary>
                            ///<para>If the property is null the assumption is that the request will default to the default values used by the Api gateway for the end-point defined for the request.</para>
                            ///<para>Else it will set the value provided by the NopCommerce system and use the value as part of the MD5 check sum generated as part of the signature value to be submitted, else the Api will reject the request</para>
                            ///<para>If the request is a GET Request it will generate a query string as part of the request submmited.</para>
                            ///<para>Else these values are submmited to the Api in the body of the request after being serlised as a Json Object listing the parameters and their associated values in a single Json list. </para>
                            ///<para>NB. This Coding relies on json and does not use From based Request submissions, hense the use of the Json objects to submit the optional parameters.</para>
                            /// </summary>
                            request.RequestBodyMetaData.Add(attrib.RequestKeyValue, prop.GetValue(request).ToString());
                        }
                    }
                }
            }

            try
            {
                /*Builds/Sets the required section such as the request End-Points(Url),
                *builds the required query string etc.
                **********************************************/
                request.PreProcessApiRequestBody();


            }
            catch (Exception ex)
            {
                result.AddError($"Unable to Process the Request Body while generating the API Request! - Internal Error: {ex.Message}");
            }

            return result;
        }

        public static GenerateRequestSignatureResult GenerateApiRequestSignature(this PayFastApiRequestBaseModel Model, PayFastCompleteSettings payFastCompleteSettings)
        {

            GenerateRequestSignatureResult result = new GenerateRequestSignatureResult();
            SortedDictionary<string, string> SignaturekeyValuePairs = new SortedDictionary<string, string>();

            Type t = Model.GetType();
            PropertyInfo[] props = t.GetProperties();

            if (!(payFastCompleteSettings.APIPassPhrase.IsNullOrEmpty()))
            {
                SignaturekeyValuePairs.Add("passphrase", payFastCompleteSettings.APIPassPhrase);
            }
            else
            {
                result.AddError("Pass Phrase has mot been set!");
                return result;
            }

            foreach (var prop in props)
            {
                var attrib = prop.GetCustomAttribute<PayFastApiRequestComponent>();
                if (attrib != null)
                {
                    if (attrib.RequestComponentPartOfSignature == EnumRequestComponentPartOfSignature.YES)
                    {
                        if (!(prop.GetValue(Model) is null))
                        {
                            SignaturekeyValuePairs.Add(attrib.RequestKeyValue, prop.GetValue(Model).ToString());
                        }
                    }
                }
            }

            try
            {
                /*Encode the required Parameters to generate the Signature to be added to the request header.
                 * *****************************************************************************************/
                Model.Signature = GetMD5Hash(GetUrlEncodedString(SignaturekeyValuePairs));

                result.MD5Signature = Model.Signature;
            }
            catch (Exception ex)
            {
                result.AddError($"Error Encoding the Header Signature while gnerating the MD5 Checksum. - Internal error: {ex.Message}");
            }


            return result;
        }
        #region Internal Methods

        public static string UrlEncodeString(this string stringToEncode)
        {
            string EncodedItem = "";
            StringBuilder sb = new StringBuilder(stringToEncode.TrimEnd().TrimStart());
            for (int i = 0; i < sb.Length; i++)
            {
                var Temp = WebUtility.UrlEncode(sb[i].ToString());
                EncodedItem += sb[i].ToString().Equals(Temp, StringComparison.InvariantCultureIgnoreCase) ? sb[i].ToString() : Temp.ToUpper();
            }

            return EncodedItem;

        }
        public static string GetUrlEncodedString(this KeyValuePair<int, KeyValuePair<string, string>>[] SignaturekeyValuePairs)
        {
            //Generate the Signature based on the Items that where  collected in the Sorted Dictionary
            string SignatureToEncode = "";
            foreach (KeyValuePair<int, KeyValuePair<string, string>> item in SignaturekeyValuePairs)
            {
                if (!item.Value.Key.Equals("setup"))
                {
                    if (SignatureToEncode.Length > 0)
                    {
                        SignatureToEncode += "&";
                    }
                    SignatureToEncode += $"{item.Value.Key}={item.Value.Value.UrlEncodeString()}";
                }
            }
            
           
            return SignatureToEncode;
        }
        public static string GetUrlEncodedString(this SortedDictionary<string, string> SignaturekeyValuePairs)
        {
            //Generate the Signature based on the Items that where  collected in the Sorted Dictionary
            string SignatureToEncode = "";
            foreach (KeyValuePair<string, string> item in SignaturekeyValuePairs)
            {
                if (SignatureToEncode.Length > 0)
                {
                    SignatureToEncode += "&";
                }

                SignatureToEncode += $"{item.Key}={item.Value.UrlEncodeString()}";


            }
            return SignatureToEncode;
        }
        public static String GetMD5Hash(this string ContentStringToHash)
        {
            string Rtn = "";
            using (var md5Hash = MD5.Create())
            {
                // Byte array representation of source string
                var sourceBytes = Encoding.Default.GetBytes(ContentStringToHash);

                // Generate hash value(Byte Array) for input data
                var hashBytes = md5Hash.ComputeHash(sourceBytes);

                // Convert hash byte array to string - Output the MD5 hash
                Rtn = BitConverter.ToString(hashBytes).Replace("-", string.Empty).ToLower();
            }

            return Rtn;
        }
        #endregion


        public static TAttribute GetAttributeValue<TAttribute>(Enum enumValue) where TAttribute : Attribute
        {

            var enumType = enumValue.GetType();
            var enumValueInfo = enumType.GetMember(enumValue.ToString()).FirstOrDefault();
            var attribute = enumValueInfo?.GetCustomAttributes(typeof(TAttribute), false).FirstOrDefault();

            return attribute as TAttribute;
        }
        /// <summary>
        /// Retruns a formatted Date Time.
        /// </summary>
        /// <param name="dt">Current Datetime to format</param>
        /// <returns>Formated Date Time Value, Format is "yyyy-MM-dd"</returns>
        public static string GenerateTransactionalTimeStamp(this DateTime dt)
        {
            return dt.ToString("yyyy-MM-dd");
        }

        /// <summary>
        /// Retruns a formatted Date Time.
        /// </summary>
        /// <param name="dt">Current Datetime to format</param>
        /// <returns>Formated Date Time Value, Format is ""yyyy-MM-ddTHH:mm:sszzz""</returns>
        public static string GeneratePayFastApiHeaderTimeStamp(this DateTime dt)
        {
            return dt.ToString("yyyy-MM-ddTHH:mm:sszzz");
        }

        public static List<string> GetEnumEntityNames<T>() where T : struct, IConvertible
        {
            if (!typeof(T).IsEnum)
                throw new ArgumentException("T must be an enumerated type");

            return Enum.GetNames(typeof(T)).ToList();
        }


        public static string GetEnumEntityName<T>(T e) where T : struct, IConvertible
        {
            if (!typeof(T).IsEnum)
                throw new ArgumentException("T must be an enumerated type");

            return Enum.GetName(typeof(T), e).Replace("_", " ");
        }
    }
}
