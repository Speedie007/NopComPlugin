﻿using FluentMigrator.Builders.Create.Table;
using Nop.Data.Mapping.Builders;
using Nop.Plugin.Payments.PayFastComplete.Domain.TransactionalHistory;
using System;
using System.Collections.Generic;
using System.Text;

namespace Nop.Plugin.Payments.PayFastComplete.Data.TransactionHistory
{
    public partial class TransactionHistoryBuilder : NopEntityBuilder<PayFastTransactionHistoryRecord>
    {
        public override void MapEntity(CreateTableExpressionBuilder table)
        {
            table.WithColumn(nameof(PayFastTransactionHistoryRecord.Id)).AsInt32().PrimaryKey().Identity()
                .WithColumn(nameof(PayFastTransactionHistoryRecord.MerchantTranactionReference)).AsGuid()
                .WithColumn(nameof(PayFastTransactionHistoryRecord.PayFastTranactionReference)).AsInt32()
                .WithColumn(nameof(PayFastTransactionHistoryRecord.TranactionAccountBalance)).AsDecimal()
                .WithColumn(nameof(PayFastTransactionHistoryRecord.TransactionCurrency)).AsString()
                .WithColumn(nameof(PayFastTransactionHistoryRecord.TransactionDateTimeStamp)).AsDateTime()
                .WithColumn(nameof(PayFastTransactionHistoryRecord.TransactionDescription)).AsString()
                .WithColumn(nameof(PayFastTransactionHistoryRecord.TransactionFee)).AsDecimal()
                .WithColumn(nameof(PayFastTransactionHistoryRecord.TransactionFundingSource)).AsString()
                .WithColumn(nameof(PayFastTransactionHistoryRecord.TransactionGrossAmount)).AsDecimal()
                .WithColumn(nameof(PayFastTransactionHistoryRecord.TransactionMethod)).AsString()
                .WithColumn(nameof(PayFastTransactionHistoryRecord.TransactionName)).AsString()
                .WithColumn(nameof(PayFastTransactionHistoryRecord.TransactionNetAmount)).AsDecimal()
                .WithColumn(nameof(PayFastTransactionHistoryRecord.TransactionType)).AsString()
                .WithColumn(nameof(PayFastTransactionHistoryRecord.TransactionUserReference)).AsString()
                .WithColumn(nameof(PayFastTransactionHistoryRecord.CustomIntegerProperty1)).AsInt32()
                .WithColumn(nameof(PayFastTransactionHistoryRecord.CustomIntegerProperty2)).AsInt32()
                .WithColumn(nameof(PayFastTransactionHistoryRecord.CustomIntegerProperty3)).AsInt32()
                .WithColumn(nameof(PayFastTransactionHistoryRecord.CustomIntegerProperty4)).AsInt32()
                .WithColumn(nameof(PayFastTransactionHistoryRecord.CustomIntegerProperty5)).AsInt32()
                .WithColumn(nameof(PayFastTransactionHistoryRecord.CustomStringProperty1)).AsString()
                .WithColumn(nameof(PayFastTransactionHistoryRecord.CustomStringProperty2)).AsString()
                .WithColumn(nameof(PayFastTransactionHistoryRecord.CustomStringProperty3)).AsString()
                .WithColumn(nameof(PayFastTransactionHistoryRecord.CustomStringProperty4)).AsString()
                .WithColumn(nameof(PayFastTransactionHistoryRecord.CustomStringProperty5)).AsString();
        }
    }
}
