﻿using FluentMigrator;
using Nop.Data.Migrations;
using Nop.Plugin.Payments.PayFastComplete.Domain.RecurringBilling;
using Nop.Plugin.Payments.PayFastComplete.Domain.TransactionalHistory;
using System;
using System.Collections.Generic;
using System.Text;

namespace Nop.Plugin.Payments.PayFastComplete.Data
{
    [SkipMigrationOnUpdate]
    [NopMigration("2020/09/02 08:40:55:1687541", "Payments.PayFastComplete base schema")]
    public class SchemaMigration : AutoReversingMigration
    {
        protected IMigrationManager _migrationManager;

        public SchemaMigration(IMigrationManager migrationManager)
        {
            _migrationManager = migrationManager;
        }

        public override void Up()
        {
            _migrationManager.BuildTable<PayFastTransactionHistoryRecord>(Create);
            _migrationManager.BuildTable<RecurringBillingFailedLog>(Create);
            _migrationManager.BuildTable<RecurringBillingFailedLogNotes>(Create);
        }
    }
}