﻿using FluentMigrator.Builders.Create.Table;
using Nop.Data.Mapping.Builders;
using Nop.Plugin.Payments.PayFastComplete.Domain.RecurringBilling;
using System;
using System.Collections.Generic;
using System.Text;

namespace Nop.Plugin.Payments.PayFastComplete.Data.RecurringBilling
{
    public partial class RecurringBillingFailedLogBuilder : NopEntityBuilder<RecurringBillingFailedLog>
    {
        public override void MapEntity(CreateTableExpressionBuilder table)
        {
            table.WithColumn(nameof(RecurringBillingFailedLog.Id)).AsInt32().PrimaryKey().Identity()
                .WithColumn(nameof(RecurringBillingFailedLog.HasBeenResolved)).AsBoolean()
                .WithColumn(nameof(RecurringBillingFailedLog.IntialOrderID)).AsInt32()
                .WithColumn(nameof(RecurringBillingFailedLog.LogDateTimeStamp)).AsDateTime();
        }
    }
}
