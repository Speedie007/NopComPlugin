﻿using FluentMigrator.Builders.Create.Table;
using Nop.Core.Domain.Common;
using Nop.Data.Mapping;
using Nop.Data.Mapping.Builders;
using Nop.Plugin.Payments.PayFastComplete.Domain.RecurringBilling;
using System;
using System.Collections.Generic;
using System.Data;
using System.Text;
using Nop.Data.Extensions;

namespace Nop.Plugin.Payments.PayFastComplete.Data.RecurringBilling
{
    public partial class RecurringBillingFailedLogNoteBuilder : NopEntityBuilder<RecurringBillingFailedLogNotes>
    {
        public override void MapEntity(CreateTableExpressionBuilder table)
        {
            table.WithColumn(nameof(RecurringBillingFailedLogNotes.Id)).AsInt32().PrimaryKey().Identity()
                .WithColumn(nameof(RecurringBillingFailedLogNotes.CustomerIDThatMadeEntry)).AsInt32()
                .WithColumn(nameof(RecurringBillingFailedLogNotes.NoteEntryDateTimeStamp)).AsDateTime()
                .WithColumn(NameCompatibilityManager.GetColumnName(typeof(RecurringBillingFailedLogNotes), nameof(RecurringBillingFailedLogNotes.RecurringBillingFailedLogID))).AsInt32().ForeignKey<RecurringBillingFailedLog>(onDelete: Rule.Cascade).Nullable()
                .WithColumn(nameof(RecurringBillingFailedLogNotes.Note)).AsString();
        }
    }
}
