﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Primitives;
using Nop.Core;
using Nop.Core.Domain.Orders;
using Nop.Plugin.Payments.PayFastComplete.Settings;
using Nop.Plugin.Payments.PayFastComplete.WebHooks.Models;
using Nop.Services.Logging;
using Nop.Services.Orders;
using Nop.Web.Framework;
using Nop.Web.Framework.Controllers;
using System;
using System.Collections.Generic;
using System.Collections.Specialized;
using System.Linq;
using System.Net;
using System.Text;

namespace Nop.Plugin.Payments.PayFastComplete.WebHooks
{
    //Payments/PayFastInstantTransactionNotification
   
    [ApiController]
    public class PayFastInstantTransactionNotificationController : ControllerBase
    {


        #region Fields
        private readonly IStoreContext _storeContext;
        private readonly IWorkContext _workContext;
        private readonly PayFastCompleteSettings _payFastCompleteSettings;
        private readonly ILogger _logger;
        private readonly IOrderProcessingService _orderProcessingService;
        private readonly IOrderService _orderService;
        private readonly IWebHelper _webHelper;
        #endregion

        #region Cstor
        public PayFastInstantTransactionNotificationController(
            ILogger logger,
            IOrderProcessingService orderProcessingService,
            IOrderService orderService,
            IWebHelper webHelper,
            IStoreContext storeContext,
            IWorkContext workContext,
            PayFastCompleteSettings payFastCompleteSettings)
        {
            _logger = logger;
            _orderProcessingService = orderProcessingService;
            _orderService = orderService;
            _webHelper = webHelper;
            _storeContext = storeContext;
            _workContext = workContext;
            _payFastCompleteSettings = payFastCompleteSettings;
        }
        #endregion

        #region Api Action Methods
        
        [HttpGet]
        [Route("Payments/PayFastInstantTransactionNotification")]
        public IActionResult PayFastResultHandler(IpnModel model, IFormCollection form)
        {
            _logger.Error($"{ DateTime.Now } : API From Properties Returned:", null, null);
            _logger.Error($"PayFast ITN error: 1 in the API ACTIVE", null, null);
            _logger.Error($"Printing out all form properties", null, null);
            foreach (var item in form)
            {
                _logger.Error($"From Properties Returned:{item.Key} = {item.Value}", null, null);
            }
            if (!ValidateITN(form, out Order order))
            {
                return new StatusCodeResult(200);
            }
            if (_orderProcessingService.CanMarkOrderAsPaid(order))
            {
                order.AuthorizationTransactionId = form["pf_payment_id"];
                _orderService.UpdateOrder(order);
                _orderProcessingService.MarkOrderAsPaid(order);
            }
            return new StatusCodeResult(200);


        }








        #endregion

        #region Internal Methods
        [NonAction]
        public bool ValidateITN(IFormCollection form, out Order order)
        {
            _logger.Error($"API WEBHOOK Beginning of ValidateITN 2", null, null);
            _logger.Error($"Beginning of ValidateITN 2", null, null);
            _logger.Error($"Guid.TryParse(form[m_payment_id] FAILED : 2.1", null, null);
            order = null;
            if (!Guid.TryParse(form["m_payment_id"], out Guid orderGuid))
            {
                _logger.Error($"Guid.TryParse(form[m_payment_id] FAILED : 3", null, null);
                return false;
            }
            _logger.Error($"Able to parse Merchant Payment ID 4", null, null);
            order = _orderService.GetOrderByGuid(orderGuid);
            if (order == null)
            {
                _logger.Error($"PayFast ITN error: Order with guid {orderGuid} is not found", null, null);
                return false;
            }
            if (!form["merchant_id"].ToString().Equals(_payFastCompleteSettings.MerchantId, StringComparison.InvariantCulture))
            {
                _logger.Error("PayFast ITN error: Merchant ID mismatch", null, null);
                return false;
            }
            if (!IPAddress.TryParse(_webHelper.GetCurrentIpAddress(), out IPAddress ipAddress))
            {
                _logger.Error("PayFast ITN error: IP address is empty", null, null);
                return false;
            }
            IEnumerable<IPAddress> validIPs = new string[4]
            {
            "www.payfast.co.za",
            "sandbox.payfast.co.za",
            "w1w.payfast.co.za",
            "w2w.payfast.co.za"
            }.SelectMany(Dns.GetHostAddresses);
            if (!validIPs.Contains(ipAddress))
            {
                _logger.Error($"PayFast ITN error: IP address {ipAddress} is not valid", null, null);
                return false;
            }
            NameValueCollection postData = new NameValueCollection();
            foreach (KeyValuePair<string, StringValues> pair in form)
            {
                if (!pair.Key.Equals("signature", StringComparison.InvariantCultureIgnoreCase))
                {
                    postData.Add(pair.Key, pair.Value);
                }
            }
            try
            {
                string site = (_payFastCompleteSettings.UseSandbox ? "https://sandbox.payfast.co.za" : "https://www.payfast.co.za") + "/eng/query/validate";
                WebClient webClient = new WebClient();
                try
                {
                    byte[] response = webClient.UploadValues(site, postData);
                    string result = Encoding.ASCII.GetString(response);
                    if (!result.StartsWith("VALID", StringComparison.InvariantCulture))
                    {
                        _logger.Error("PayFast ITN error: passed data is not valid", null, null);
                        return false;
                    }
                }
                finally
                {
                    ((IDisposable)webClient)?.Dispose();
                }
            }
            catch (WebException)
            {
                _logger.Error("PayFast ITN error: passed data is not valid", null, null);
                return false;
            }
            if (!form["payment_status"].ToString().Equals("COMPLETE", StringComparison.InvariantCulture))
            {
                _logger.Error(string.Format("PayFast ITN error: order #{0} is {1}", order.Id, form["payment_status"]), null, null);
                return false;
            }
            return true;
        }

        [NonAction]
        public IActionResult CancelOrder()
        {
            Order order = (_orderService.SearchOrders(_storeContext.CurrentStore.Id, 0, _workContext.CurrentCustomer.Id, 0, 0, 0, 0, null, null, null, null, null, null, null, null, "", null, 0, 1, false)).FirstOrDefault();
            if (order != null)
            {
                return RedirectToRoute("OrderDetails", new
                {
                    orderId = ((BaseEntity)order).Id
                });
            }
            return RedirectToRoute("Homepage");
        }
        #endregion
    }
}
