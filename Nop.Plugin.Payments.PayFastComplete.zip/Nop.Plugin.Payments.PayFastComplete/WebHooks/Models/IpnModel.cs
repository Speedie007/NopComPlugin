﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using MySql.Data.MySqlClient.Replication;
using Nop.Web.Framework.Models;
using System;
using System.Collections.Generic;
using System.Text;

namespace Nop.Plugin.Payments.PayFastComplete.WebHooks.Models
{
    public partial class IpnModel : BaseNopModel
    {
        public IpnModel()
        {


        }
        #region Transaction details


        /// <summary>
        /// Description : Unique payment ID on the merchant’s system.
        /// Required    : Optional
        /// Format      : alphanumeric, 100 char
        [BindProperty(Name = "m_payment_id")]
        public string MerchantPaymentID { get; set; }

        /// <summary>
        /// Description : Unique transaction ID on PayFast.
        /// Required    : Required
        /// Format      : numeric
        [BindProperty(Name = "pf_payment_id")]
        public string PayFastPaymentID { get; set; }

        /// <summary>
        /// Description : After a successful payment the status sent will be COMPLETE./n
        ///               When a subscription is cancelled the status will be CANCELLED.
        /// Required    : Required
        /// Format      : String Value Either: COMPLETE or CANCELLED
        [BindProperty(Name = "payment_status")]
        public string PaymentStatus { get; set; }

        /// <summary>
        /// Description :The name of the item being charged for. In this Case it could be the order number.
        /// Required    : Yes
        /// Format      : alphanumeric, 100 char
        /// </summary>
        [BindProperty(Name = "item_name")]
        public string OrderName { get; set; }

        /// <summary>
        /// Description : 	The description of the item being charged for.
        /// Required    : No
        /// Format      : alphanumeric, 255 char
        /// </summary>
        [BindProperty(Name = "item_description")]
        public string OrderDescription { get; set; }


        /// <summary>
        /// Description : The total amount which the payer paid.
        /// Required    : Yes
        /// Format      : decimal
        /// </summary>
        [BindProperty(Name = "amount_gross")]
        public string TotalPaidByTheBuyer { get; set; }

        /// <summary>
        /// Description : The total in fees which was deducted from the amount.
        /// Required    : Yes
        /// Format      : decimal
        /// </summary>
        [BindProperty(Name = "amount_fee")]
        public string PayFastTransactionFee { get; set; }

        /// <summary>
        /// Description : The net amount credited to the receiver’s account.
        /// Required    : Yes
        /// Format      : decimal
        /// </summary>
        [BindProperty(Name = "amount_net")]
        public string NetAmountRecievedByTheMerchant { get; set; }

        /// <summary>
        /// Description : The series of 5 custom string variables (custom_str1, custom_str2…) originally passed by the receiver during the payment request.
        /// Required    : No
        /// Format      : alphanumeric, 255 char
        /// </summary>
        [BindProperty(Name = "custom_str1")]
        public string MerchantDefined_OptionalExtraStringField1 { get; set; }

        /// <summary>
        /// Description : The series of 5 custom string variables (custom_str1, custom_str2…) originally passed by the receiver during the payment request.
        /// Required    : No
        /// Format      : alphanumeric, 255 char
        /// </summary>
        [BindProperty(Name = "custom_str2")]
        public string MerchantDefined_OptionalExtraStringField2 { get; set; }
        /// <summary>
        /// Description : The series of 5 custom string variables (custom_str1, custom_str2…) originally passed by the receiver during the payment request.
        /// Required    : No
        /// Format      : alphanumeric, 255 char
        /// </summary>
        [BindProperty(Name = "custom_str3")]
        public string MerchantDefined_OptionalExtraStringField3 { get; set; }

        /// <summary>
        /// Description : The series of 5 custom string variables (custom_str1, custom_str2…) originally passed by the receiver during the payment request.
        /// Required    : No
        /// Format      : alphanumeric, 255 char
        /// </summary>
        [BindProperty(Name = "custom_str4")]
        public string MerchantDefined_OptionalExtraStringField4 { get; set; }

        /// <summary>
        /// Description : The series of 5 custom string variables (custom_str1, custom_str2…) originally passed by the receiver during the payment request.
        /// Required    : No
        /// Format      : alphanumeric, 255 char
        /// </summary>
        /// </summary>
        [BindProperty(Name = "custom_str5")]
        public string MerchantDefined_OptionalExtraStringField5 { get; set; }

        /// <summary>
        /// Description : The series of 5 custom integer variables (custom_int1, custom_int2…) originally passed by the receiver during the payment request.
        /// Required    : No
        /// Format      : alphanumeric, 255 char
        /// </summary>
        [BindProperty(Name = "custom_int1")]
        public int MerchantDefined_OptionalExtraIntegerField1 { get; set; }

        /// <summary>
        /// Description : The series of 5 custom integer variables (custom_int1, custom_int2…) originally passed by the receiver during the payment request.
        /// Required    : No
        /// Format      : alphanumeric, 255 char
        /// </summary>
        [BindProperty(Name = "custom_int2")]
        public int MerchantDefined_OptionalExtraIntegerField2 { get; set; }

        /// <summary>
        /// Description : The series of 5 custom integer variables (custom_int1, custom_int2…) originally passed by the receiver during the payment request.
        /// Required    : No
        /// Format      : alphanumeric, 255 char
        /// </summary>
        [BindProperty(Name = "custom_int3")]
        public int MerchantDefined_OptionalExtraIntegerField3 { get; set; }

        /// <summary>
        /// Description : The series of 5 custom integer variables (custom_int1, custom_int2…) originally passed by the receiver during the payment request.
        /// Required    : No
        /// Format      : alphanumeric, 255 char
        /// </summary>
        [BindProperty(Name = "custom_int4")]
        public int MerchantDefined_OptionalExtraIntegerField4 { get; set; }

        /// <summary>
        /// Description : The series of 5 custom integer variables (custom_int1, custom_int2…) originally passed by the receiver during the payment request.
        /// Required    : No
        /// Format      : alphanumeric, 255 char
        /// </summary>
        [BindProperty(Name = "custom_int5")]
        public int MerchantDefined_OptionalExtraIntegerField5 { get; set; }
        #endregion

        #region Buyers Details
        /// <summary>
        /// Description : The buyer’s first name.
        /// Required    : No
        /// Format      : alphanumeric, 100 char
        /// </summary>
        [BindProperty(Name = "name_first")]
        public string FirstName { get; set; }

        /// <summary>
        /// Description : The buyer’s last name.
        /// Required    : No
        /// Format      : alphanumeric, 100 cha
        /// </summary>
        [BindProperty(Name = "name_last")]
        public string LastName { get; set; }

        /// <summary>
        /// Description : The buyer’s email address
        /// Required    : No
        /// Format      : alphanumeric, 100 char
        /// </summary>
        [BindProperty(Name = "email_address")]
        public string EmailAddress { get; set; }

        /// <summary>
        /// Description : The buyer’s valid cell number. 
        /// If the email_address field is empty, and cell_number provided, the system will use the cell_number as the username and autologin the user, 
        /// if they do not have a registered account.
        /// Required    : Yes
        /// Format      : numeric, 10 char
        /// </summary>
        [BindProperty(Name = "cell_number")]
        public string CellNumber { get; set; }
        #endregion


        #region Merchant Details
        /// <summary>
        /// Description : The Merchant ID as given by the PayFast system. Used to uniquely identify the receiving account.
        ///               This can be found on the merchant’s settings page.
        /// Required    : Yes
        /// Format      : numeric.
        /// </summary>
        [BindProperty(Name = "merchant_id")]
        public string MerchantID { get; set; }
        #endregion

        #region Recurring billing details
        /// <summary>
        /// Description : Unique ID on PayFast System that represents the subscription.
        /// Required    : Yes
        /// Format      : alphanumeric, 36 char.
        /// </summary>
        [BindProperty(Name = "token")]
        public string SubscriptionToken { get; set; }

        /// <summary>
        /// Description : The date from which future subscription payments will be made. Eg. 2016-01-01. Defaults to current date if not set.
        /// Required    : Yes
        /// Format      : Date format: YYYY-MM-DD
        /// </summary>
        [BindProperty(Name = "billing_date")]
        public string SubscriptionBillingDate { get; set; }
        #endregion

        #region Security information
        /// <summary>
        /// Description : A security signature of the transmitted data taking the form of an MD5 hash of all the url encoded submitted variables. 
        /// The string from which the hash is created, is the concatenation of the name value pairs of all variables (including the blank variables) with ‘&’ used as a separator 
        /// eg. “name_first=John&name_last=Doe&email_address=…” where pairs are listed in the order in which they appear in the $_POST data. 
        /// This hash will be regenerated by the PayFast engine and the values compared to ensure the integrity of the data transfer.
        /// Required    : Yes
        /// Format      : Date format: YYYY-MM-DD
        /// </summary>
        [BindProperty(Name = "signature")]
        public string TransactionSignature { get; set; }

        #endregion

    }
}