﻿using Microsoft.AspNetCore.Mvc.Rendering;
using Nop.Plugin.Payments.PayFastComplete.Areas.Admin.Models.TransactionalHistory;
using Nop.Plugin.Payments.PayFastComplete.Domain.TransactionalHistory;
using Nop.Plugin.Payments.PayFastComplete.Infrastructure.Common.Enumerations;
using Nop.Plugin.Payments.PayFastComplete.Infrastructure.Common.Results;
using Nop.Plugin.Payments.PayFastComplete.Services.TransactionHistoryServices;
using Nop.Web.Areas.Admin.Infrastructure.Mapper.Extensions;
using Nop.Web.Framework.Models.Extensions;
using System;
using System.Globalization;
using System.Linq;

namespace Nop.Plugin.Payments.PayFastComplete.Factories
{
    public partial interface ITransactionHistoryFactory
    {
        TransactionHistroyTransactionSearchModel PrepareTransactionHistorySearchModel(TransactionHistroyTransactionSearchModel model);
        TransactionHistoryListModel PrepareTransactionHistoryListModel(TransactionHistroyTransactionSearchModel searchModel);


        TransactionHistoryViewModel PrepareTransactionHistoryFullDetails(int TransactionHistoryID);
    }
    public partial class TransactionHistoryFactory : ITransactionHistoryFactory
    {
        private readonly IPayFastTransactionHistoryService _payFastTransactionHistoryService;
        #region Ctor
        public TransactionHistoryFactory(IPayFastTransactionHistoryService payFastTransactionHistoryService)
        {
            _payFastTransactionHistoryService = payFastTransactionHistoryService;
        }

        public TransactionHistoryViewModel PrepareTransactionHistoryFullDetails(int TransactionHistoryID)
        {
            
            var Rtn = _payFastTransactionHistoryService.GetPayFastTransactionHistoryRecord_LocalDbCache_ById(TransactionHistoryID);

            if (Rtn.Success)
            {
                return Rtn.ProccesedCRUDEntity.ToModel<TransactionHistoryViewModel>();
            }
            else
            {
                return null;
            }
        }

        public TransactionHistoryListModel PrepareTransactionHistoryListModel(TransactionHistroyTransactionSearchModel searchModel)
        {
            if (searchModel == null)
                throw new ArgumentNullException(nameof(searchModel));

            //get Transaction History Records
            var TransactionHistoryRecords = _payFastTransactionHistoryService.ListAllPayFastTransactionHistoryRecords(
                TransactionType: searchModel.SearchByPayFastTransacionType,
                 OrderID: Convert.ToInt32(searchModel.SearchByOrderNumber),
                  TransactionWithinSpecifiedYear: searchModel.SearchByYearOfTranaction,
                  TransactionWithinSpecifiedMonth: searchModel.SearchByMonthOfTranaction,
                  TransactionOnSpecifiedDay: searchModel.SearchByDayOfTransaction,
                  pageIndex: searchModel.Page - 1, pageSize: searchModel.PageSize
                );

            //prepare list model
            var model = new TransactionHistoryListModel().PrepareToGrid(searchModel, TransactionHistoryRecords, () =>
            {
                return TransactionHistoryRecords.Select(TransactionHistoryRecord =>
                {
                    //fill in model values from the entity
                    var transactionHistoryRecordViewModel = TransactionHistoryRecord.ToModel<TransactionHistoryViewModel>();

                    //convert dates to the user time
                    //customerModel.Email = _customerService.IsRegistered(customer) ? customer.Email : _localizationService.GetResource("Admin.Customers.Guest");
                    //customerModel.FullName = _customerService.GetCustomerFullName(customer);
                    //customerModel.Company = _genericAttributeService.GetAttribute<string>(customer, NopCustomerDefaults.CompanyAttribute);
                    //customerModel.Phone = _genericAttributeService.GetAttribute<string>(customer, NopCustomerDefaults.PhoneAttribute);
                    //customerModel.ZipPostalCode = _genericAttributeService.GetAttribute<string>(customer, NopCustomerDefaults.ZipPostalCodeAttribute);

                    //customerModel.CreatedOn = _dateTimeHelper.ConvertToUserTime(customer.CreatedOnUtc, DateTimeKind.Utc);
                    //customerModel.LastActivityDate = _dateTimeHelper.ConvertToUserTime(customer.LastActivityDateUtc, DateTimeKind.Utc);

                    ////fill in additional values (not existing in the entity)
                    //customerModel.CustomerRoleNames = string.Join(", ", _customerService.GetCustomerRoles(customer).Select(role => role.Name));
                    //if (_customerSettings.AllowCustomersToUploadAvatars)
                    //{
                    //    var avatarPictureId = _genericAttributeService.GetAttribute<int>(customer, NopCustomerDefaults.AvatarPictureIdAttribute);
                    //    customerModel.AvatarUrl = _pictureService.GetPictureUrl(avatarPictureId, _mediaSettings.AvatarPictureSize,
                    //        _customerSettings.DefaultAvatarEnabled, defaultPictureType: PictureType.Avatar);
                    //}

                    return transactionHistoryRecordViewModel;
                }).OrderBy(x=>x.TransactionDateTimeStamp);
            });

            return model;
        }

        public TransactionHistroyTransactionSearchModel PrepareTransactionHistorySearchModel(TransactionHistroyTransactionSearchModel searchModel)
        {
            if (searchModel == null)
                throw new ArgumentNullException(nameof(searchModel));

            searchModel.YearValues.Add(new SelectListItem { Text = "All Years", Value = "0" });
            foreach (var Year in _payFastTransactionHistoryService.GetYearsFromTransactionHistoryRecords_LocalDbCache())
            {
                searchModel.YearValues.Add(new SelectListItem(Year.ToString(CultureInfo.InvariantCulture), Year.ToString(CultureInfo.InvariantCulture)));
            }
            searchModel.MonthNames.Add(new SelectListItem { Text = "Any Month", Value = "0" });
            foreach (int MonthValue in Enum.GetValues(typeof(EnumMonthNames)))
            {
                searchModel.MonthNames.Add(new SelectListItem(Enum.GetName(typeof(EnumMonthNames), MonthValue).ToString(CultureInfo.InvariantCulture), MonthValue.ToString(CultureInfo.InvariantCulture)));
            }

            searchModel.PayFastTransacionTypes.Add(new SelectListItem { Text = "Any Transaction Type", Value = "0" });
            foreach (var item in _payFastTransactionHistoryService.GetTransactionTypesFromTransactionHistoryRecords_LocalDbCache())
            {
                searchModel.PayFastTransacionTypes.Add(new SelectListItem(item.Replace("_", " ").ToString(CultureInfo.InvariantCulture), item.ToString(CultureInfo.InvariantCulture)));
            }

            //prepare page parameters
            searchModel.SetGridPageSize();

            return searchModel;
        }
        #endregion

    }
}
