﻿using LinqToDB.Common;
using Nop.Core;
using Nop.Core.Domain.Catalog;
using Nop.Core.Domain.Common;
using Nop.Core.Domain.Orders;
using Nop.Plugin.Payments.PayFastComplete.Extensions;
using Nop.Plugin.Payments.PayFastComplete.Infrastructure.Common.Enumerations;
using Nop.Plugin.Payments.PayFastComplete.Services.PaymentProcessingServices.Compoments.Enumerations;
using Nop.Plugin.Payments.PayFastComplete.Services.PaymentProcessingServices.Models.FromProcessing.Components;
using Nop.Plugin.Payments.PayFastComplete.Settings;
using Nop.Services.Catalog;
using Nop.Services.Common;
using Nop.Services.Customers;
using Nop.Services.Orders;
using OfficeOpenXml.FormulaParsing.Excel.Functions.DateTime;
using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Net;
using System.Text;

namespace Nop.Plugin.Payments.PayFastComplete.Factories
{
    /// <summary>
    /// 
    /// </summary>
    public interface IPayFastPaymentConfigurationFactory
    {
        /// <summary>
        /// 
        /// </summary>
        /// <param name="order"></param>
        /// <returns></returns>
        PayFastFormProcessingMerchantDetailModel PrepareMerchantDetails(Order order);

        /// <summary>
        /// 
        /// </summary>
        /// <param name="order"></param>
        /// <returns></returns>
        PayFastFormProcessingBuyerDetailModel PrepareBuyerDetails(Order order);
        /// <summary>
        /// 
        /// </summary>
        /// <param name="order"></param>
        /// <returns></returns>
        PayFastFormProcessingTransactionDetailModel PrepareTransactionDetails(Order order);
        /// <summary>
        /// 
        /// </summary>
        /// <returns></returns>
        PayFastFormProcessingTransactionOptionsModel PrepareTransactionOptions();
        /// <summary>
        /// 
        /// </summary>
        /// <returns></returns>
        PayFastFormProcessingPaymentMethodModel PreparePaymentMethod();
        /// <summary>
        /// 
        /// </summary>
        /// <param name="order"></param>
        /// <returns></returns>
        PayFastFormProcessingRecurringBillingSubscriptionDetailModel PrepareRecurringBillingDetailsSubscription(Order order);
        /// <summary>
        /// 
        /// </summary>
        /// <returns></returns>
        PayFastFormProcessingSplitPaymentDetailModel PrepareSplitPaymentDetails(Order order);
    }
    public partial class PayFastPaymentConfigurationFactory : IPayFastPaymentConfigurationFactory
    {


        #region Fields
        private readonly PayFastCompleteSettings _payFastCompleteSettings;
        private readonly IAddressService _addressService;
        private readonly IWebHelper _webHelper;
        private readonly IStoreContext _storeContext;
        private readonly ICustomerService _customerService;
        private readonly IProductService _productService;
        private readonly IOrderService _orderService;
        #endregion

        #region Cstor
        public PayFastPaymentConfigurationFactory(
            PayFastCompleteSettings payFastCompleteSettings,
            IWebHelper webHelper,
            IAddressService addressService,
             IOrderService orderService,
            IProductService productService,
            ICustomerService customerService,
            IStoreContext storeContext)
        {
            _storeContext = storeContext;
            _customerService = customerService;
            _productService = productService;
            _orderService = orderService;
            _addressService = addressService;
            _webHelper = webHelper;
            _payFastCompleteSettings = payFastCompleteSettings;
        }
        #endregion

        #region Methods

        /// <summary>
        /// <para>While these fields are optional, it is highly recommended to provide this information (if available),</para>
        /// <para>as it is used to pre-populate any forms the user needs to fill in to complete payment.</para>
        /// <para>It decreases the time taken to complete the transaction and improves the rate of successful payment completion.</para>
        /// </summary>
        /// <param name="order">
        /// 
        /// </param>
        /// <returns></returns>
        public PayFastFormProcessingBuyerDetailModel PrepareBuyerDetails(Order order)
        {
            Address billingAddress = _addressService.GetAddressById(order.BillingAddressId);
            PayFastFormProcessingBuyerDetailModel model = new PayFastFormProcessingBuyerDetailModel();

            if (billingAddress != null)
            {
                model.CellNumber = billingAddress.PhoneNumber;
                model.EmailAddress = billingAddress.Email;
                model.FirstName = billingAddress.FirstName;
                model.LastName = billingAddress.LastName;
            }

            return model;
        }

        public PayFastFormProcessingMerchantDetailModel PrepareMerchantDetails(Order order)
        {
            PayFastFormProcessingMerchantDetailModel model = new PayFastFormProcessingMerchantDetailModel()
            {
                MerchantID = _payFastCompleteSettings.MerchantId,
                MerchantKey = _payFastCompleteSettings.MerchantKey,
                ReturnUrl = $"https://www.vptuckshop.co.za/checkout/completed/{ order.Id }",//  var storeLocation = _webHelper.GetStoreLocation();
                CancelUrl = $"https://www.vptuckshop.co.za/orderdetails/{  order.Id }",//  var storeLocation = _webHelper.GetStoreLocation();
                NotifyUrl = $"https://www.vptuckshop.co.za/PaymentGateway/PayFastInstantTransactionNotification"
                //ReturnUrl = $"{_webHelper.GetStoreLocation()}checkout/completed/{order.Id}",//  var storeLocation = _webHelper.GetStoreLocation();
                //CancelUrl = $"{_webHelper.GetStoreLocation()}orderdetails/{order.Id}",//  var storeLocation = _webHelper.GetStoreLocation();
                //NotifyUrl = $"{_webHelper.GetStoreLocation()}PaymentGateway/PayFastInstantTransactionNotification"
            };

            return model;
        }

        /// <summary>
        /// <para>When this field is set, only the payment method specified can be used when the buyer reaches PayFast.</para>
        /// <para>If this field is blank, or not included, then all available payment methods will be shown.</para>
        /// <para>The values are as follows:</para>
        /// <para>‘eft’ – sets eft payment method</para>
        /// <para>‘cc’ – sets credit card payment method</para>
        /// <para>‘dc’ – sets debit card payment method</para>
        /// <para>‘bc’ – sets bitcoin payment method</para>
        /// <para>‘mp’ – sets masterpass payment method</para>
        /// <para>‘mc’ – sets mobicred payment method</para>
        /// <para>‘cd’ – sets cash deposit payment method</para>
        /// <para>‘sc’ – sets SCode payment method</para>
        /// </summary>
        /// <returns></returns>
        public PayFastFormProcessingPaymentMethodModel PreparePaymentMethod()
        {
            //TODO: Build the configuration page that will allow confir the payment option.
            PayFastFormProcessingPaymentMethodModel model = new PayFastFormProcessingPaymentMethodModel()
            {

            };

            return model;
        }


        public PayFastFormProcessingRecurringBillingSubscriptionDetailModel PrepareRecurringBillingDetailsSubscription(Order order)
        {
            PayFastFormProcessingRecurringBillingSubscriptionDetailModel model = new PayFastFormProcessingRecurringBillingSubscriptionDetailModel();

            IList<OrderItem> OrderItems = _orderService.GetOrderItems(order.Id);

            if (OrderItems.Count >= 1)
            {
                bool HasReccuringItems = false;
                foreach (var item in OrderItems)
                {
                    Product productToCheck = _productService.GetProductById(OrderItems.FirstOrDefault().ProductId);
                    if (productToCheck.IsRecurring)
                    {
                        HasReccuringItems = productToCheck.IsRecurring;
                    }
                }

                if (HasReccuringItems)
                {

                    RecurringPayment rp = _orderService.SearchRecurringPayments(initialOrderId: order.Id).FirstOrDefault();
                    ///<summary>
                    ///<para>Determine if there is a a vaild Recurring Frequency supported by PayFast.</para>
                    ///<para>If None is found a simple Ad Hoc Recurring Payment will be generated.</para>
                    /// </summary>
                    if (PayFastCompleteExtensions.CheckRecurringPeriodMatches(rp.CyclePeriod, rp.CycleLength) == EnumPayFastRecuringFrequency.UnDefinedFrequency)
                    {
                        model.SubscriptionType = Convert.ToInt32(EnumRecurringBillingTypes.AdHoc).ToString();
                    }
                    else
                    {
                        ///<summary>
                        ///<para>There is a valid PayFast Recurring Cycle/Frquency Defined.</para>
                        ///<para>Therefore we will Create a Normal Recurring Order On PayFast System.</para>
                        /// <para>This Will let PayFast Handel the Recurring Payment Cycle.</para>
                        /// <para> The system Will be updated via the </para>
                        ///</summary>
                        model.SubscriptionType = Convert.ToInt32(EnumRecurringBillingTypes.Subscription).ToString();
                        model.SubscriptionRecurringAmount = order.OrderTotal.ToString("0.00", CultureInfo.InvariantCulture);
                        model.SubscriptionFrequency = Convert.ToInt32(PayFastCompleteExtensions.CheckRecurringPeriodMatches(rp.CyclePeriod, rp.CycleLength)).ToString();
                        model.SetAmountOfSubscriptionCycles = rp.TotalCycles.ToString();
                    }
                }
            }
            return model;
        }

        public PayFastFormProcessingSplitPaymentDetailModel PrepareSplitPaymentDetails(Order order)
        {

            decimal ShippingCost = order.OrderShippingInclTax;
            decimal addtionalCost = order.PaymentMethodAdditionalFeeInclTax;
            decimal OrderAmountToCalcFrom = order.OrderTotal - (ShippingCost + addtionalCost);

            SplitPaymentObject SplitOptions = null;
            // string JsonString = "";

            if (_payFastCompleteSettings.SplitPayment_IsSplitPaymentActive)
                if (!_payFastCompleteSettings.SplitPayment_RecievingMerchantId.IsNullOrEmpty())
                {
                    decimal amount = 0;
                    var CalcThreshold = _payFastCompleteSettings.SplitPayment_Amount;
                    var MinimumCost = _payFastCompleteSettings.SplitPayment_MinimumAmount;
                    var MaximumCost = _payFastCompleteSettings.SplitPayment_MaximumAmount;
                    var AboveThresholdPercentage = _payFastCompleteSettings.SplitPayment_Percentage;
                    var MustIncludeShippingCosts = _payFastCompleteSettings.SplitPayment_MustIncludeShippingCosts;
                    //If The Calculated Cost To the Client is less than the Threshhold
                    if (OrderAmountToCalcFrom <= CalcThreshold)
                        amount = MinimumCost;
                    //If The Calculated Cost To the Client is Greater than the Threshhold
                    if (OrderAmountToCalcFrom > CalcThreshold)
                        amount = MinimumCost + ((OrderAmountToCalcFrom - CalcThreshold) * (AboveThresholdPercentage / 100));
                    //If The Calculated Cost To the Client is Greater than the Maximum
                    if (MaximumCost > 0 && amount > MaximumCost)
                        amount = MaximumCost;

                    if (!order.PickupInStore || MustIncludeShippingCosts)
                        amount += ShippingCost;

                    ///<summary>
                    ///<para>Only the Amount to payover to the merchant and the recieving merchant ID is  the only thing that will ever be set.</para>
                    ///<para>The Logic to calculate the amount is handeled on the NopCommerce side before sending the request.</para>
                    /// </summary>
                    SplitOptions = new SplitPaymentObject()
                    {
                        SplitPaymentItems = new SplitPaymentJsonValues()
                        {
                            AmountToRecievingMerchant = Convert.ToInt32(amount * 100),
                            RecievingMerchantID = Convert.ToInt32(_payFastCompleteSettings.SplitPayment_RecievingMerchantId)
                        }
                    };
                }

            return new PayFastFormProcessingSplitPaymentDetailModel(SplitOptions);
        }

        public PayFastFormProcessingTransactionDetailModel PrepareTransactionDetails(Order order)
        {
            var customer = _customerService.GetCustomerById(order.CustomerId).Email;
            var sOrderName = order.CustomOrderNumber is string ? order.CustomOrderNumber : order.Id.ToString();
            PayFastFormProcessingTransactionDetailModel model = new PayFastFormProcessingTransactionDetailModel()
            {
                MerchantPaymentID = order.OrderGuid.ToString(),
                OrderAmount = order.OrderTotal.ToString("0.00", CultureInfo.InvariantCulture),
                OrderDescription = $"Order is for customer :[{order.CustomerId}] : Email Address {_customerService.GetCustomerById(order.CustomerId).Email} - Date and Time Placed : [{DateTime.UtcNow}]",
                OrderName = $"Order Number #{sOrderName} Date:[{DateTime.Now.GenerateTransactionalTimeStamp()}]"
            };
            return model;
        }

        public PayFastFormProcessingTransactionOptionsModel PrepareTransactionOptions()
        {
            PayFastFormProcessingTransactionOptionsModel model = new PayFastFormProcessingTransactionOptionsModel()
            {
                SendEmailConfirmationToMarchent = "1",
                EmailAddressToSendConfirmationToMerchant = "Brendan@inspecserv.co.za"
            };
            return model;
        }
        #endregion

    }
}
