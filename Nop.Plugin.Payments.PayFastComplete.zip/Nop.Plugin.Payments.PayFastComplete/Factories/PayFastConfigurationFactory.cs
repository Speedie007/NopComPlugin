﻿using Nop.Plugin.Payments.PayFastComplete.Areas.Admin.Models.Configuration;
using Nop.Plugin.Payments.PayFastComplete.Settings;
using Nop.Services.Configuration;
using System;
using System.Collections.Generic;
using System.Text;

namespace Nop.Plugin.Payments.PayFastComplete.Factories
{
    public interface IPayFastConfigurationFactory
    {
        #region PayFast Configuration Sections
        #region SplitPayments
        SpiltPaymentsViewModel PrepareSpiltPaymentsViewModel();
        #endregion
        #region Url Configuration
        UrlConfigurationViewModel PrepareUrlConfigurationViewModel();
        #endregion
        #region Configuration Testing
        ConfigurationTestingViewModel PrepareConfigurationTestingViewModel();
        #endregion
        #region Additional Charges
        AdditionalChargesViewModel PrepareAdditionalChargesViewModel();
        #endregion
        #region Security Settings
        SecuritySettingsViewModel PrepareSecuritySettingsViewModel();
        #endregion
        #endregion
    }
    public class PayFastConfigurationFactory : IPayFastConfigurationFactory
    {
        #region Fields
        private readonly PayFastCompleteSettings _payFastCompleteSettings;
        #endregion


        #region Cstor
        public PayFastConfigurationFactory(
            PayFastCompleteSettings payFastCompleteSettings)
        {
            _payFastCompleteSettings = payFastCompleteSettings;
        }
        #endregion

        #region PayFast Configuration

        #region Security Settings
        public SecuritySettingsViewModel PrepareSecuritySettingsViewModel()
        {
            SecuritySettingsViewModel model = new SecuritySettingsViewModel()
            {
                MerchantKey = _payFastCompleteSettings.MerchantKey,
                APIPassPhrase = _payFastCompleteSettings.APIPassPhrase,
                MerchantId = _payFastCompleteSettings.MerchantId,
                APIVersion = _payFastCompleteSettings.APIVersion
            };

            return model;
        }
        #endregion
        #endregion


        public AdditionalChargesViewModel PrepareAdditionalChargesViewModel()
        {
            AdditionalChargesViewModel Model = new AdditionalChargesViewModel()
            {
                AdditionalFee = _payFastCompleteSettings.AdditionalFee,
                AdditionalFeePercentage = _payFastCompleteSettings.AdditionalFeePercentage
            };

            return Model;
        }

        public ConfigurationTestingViewModel PrepareConfigurationTestingViewModel()
        {
            ConfigurationTestingViewModel model = new ConfigurationTestingViewModel()
            {
                ApiTimeOutValue = _payFastCompleteSettings.ApiTimeOutValue,
                ApiSubmissionTestingUrl = _payFastCompleteSettings.ApiSubmissionTestingUrl,
                UseSandbox = _payFastCompleteSettings.UseSandbox,
                FormSubmissionTestingUri = _payFastCompleteSettings.FormSubmissionTestingUri
            };

            return model;
        }

        public UrlConfigurationViewModel PrepareUrlConfigurationViewModel()
        {
            UrlConfigurationViewModel model = new UrlConfigurationViewModel()
            {
                ApiPingUrl = _payFastCompleteSettings.ApiPingUrl,
                ApiTransactionDetailsUrl = _payFastCompleteSettings.ApiTransactionDetailsUrl,
                ApiTransactionHistoryForDailyUrl = _payFastCompleteSettings.ApiTransactionHistoryForDailyUrl,
                ApiTransactionHistoryForMonthlyUrl = _payFastCompleteSettings.ApiTransactionHistoryForMonthlyUrl,
                ApiTransactionHistoryForPeriodUrl = _payFastCompleteSettings.ApiTransactionHistoryForPeriodUrl,
                ApiTransactionHistoryForWeeklyUrl = _payFastCompleteSettings.ApiTransactionHistoryForWeeklyUrl,
                APIBaseUri = _payFastCompleteSettings.APIBaseUri,
                FormBaseUri = _payFastCompleteSettings.FormBaseUri,
                ApiRecurringBillingAdHocChargeUrl = _payFastCompleteSettings.ApiRecurringBilling_ADHOC_CHARGE_SubscriptionUrl,
                ApiRecurringBillingCommonCancelUrl = _payFastCompleteSettings.ApiRecurringBilling_COMMON_CANCEL_SubscriptionUrl,
                ApiRecurringBillingCommonFetchUrl = _payFastCompleteSettings.ApiRecurringBilling_COMMON_FETCH_SubscriptionUrl,
                ApiRecurringBillingNormalPauseUrl = _payFastCompleteSettings.ApiRecurringBilling_NORMAL_PAUSE_SubscriptionUrl,
                ApiRecurringBillingNormalUnpauseUrl = _payFastCompleteSettings.ApiRecurringBilling_NORMAL_UNPAUSE_SubscriptionUrl,
                ApiRecurringBillingNormalUpdateUrl = _payFastCompleteSettings.ApiRecurringBilling_NORMAL_UPDATE_SubscriptionUrl
            };

            return model;
        }

        public SpiltPaymentsViewModel PrepareSpiltPaymentsViewModel()
        {
            SpiltPaymentsViewModel model = new SpiltPaymentsViewModel()
            {
                Amount = _payFastCompleteSettings.SplitPayment_Amount,
                IsSplitPaymentActive = _payFastCompleteSettings.SplitPayment_IsSplitPaymentActive,
                MaximumAmount = _payFastCompleteSettings.SplitPayment_MaximumAmount,
                MinimumAmount = _payFastCompleteSettings.SplitPayment_MinimumAmount,
                MustIncludeShippingCosts = _payFastCompleteSettings.SplitPayment_MustIncludeShippingCosts,
                Percentage = _payFastCompleteSettings.SplitPayment_Percentage,
                RecievingMerchantId = _payFastCompleteSettings.SplitPayment_RecievingMerchantId
            };

            return model;
        }
    }
}
