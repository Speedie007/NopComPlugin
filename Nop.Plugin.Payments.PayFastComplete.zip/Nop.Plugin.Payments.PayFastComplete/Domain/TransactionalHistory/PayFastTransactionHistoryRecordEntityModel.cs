﻿using Nop.Core;
using Nop.Web.Framework.Models;
using System;
using System.Collections.Generic;
using System.Text;
using static LinqToDB.Sql;

namespace Nop.Plugin.Payments.PayFastComplete.Domain.TransactionalHistory
{
    public partial class PayFastTransactionHistoryRecord : BaseEntity
    {
        public DateTime TransactionDateTimeStamp { get; set; }
        public string TransactionType { get; set; }
        public string TransactionMethod { get; set; }
        public string TransactionUserReference { get; set; }
        public string TransactionName { get; set; }
        public string TransactionDescription { get; set; }
        public string TransactionCurrency { get; set; }
        public string TransactionFundingSource { get; set; }
        public decimal TransactionGrossAmount { get; set; }
        public decimal TransactionFee { get; set; }
        public decimal TransactionNetAmount { get; set; }
        public decimal TranactionAccountBalance { get; set; }
        public string MerchantTranactionReference { get; set; }
        public string PayFastTranactionReference { get; set; }
        public string CustomStringProperty1 { get; set; }
        public int CustomIntegerProperty1 { get; set; }
        public string CustomStringProperty2 { get; set; }
        public int CustomIntegerProperty2 { get; set; }
        public string CustomStringProperty3 { get; set; }
        public int CustomIntegerProperty3 { get; set; }
        public string CustomStringProperty4 { get; set; }
        public int CustomIntegerProperty4 { get; set; }
        public string CustomStringProperty5 { get; set; }
        public int CustomIntegerProperty5 { get; set; }

    }
}