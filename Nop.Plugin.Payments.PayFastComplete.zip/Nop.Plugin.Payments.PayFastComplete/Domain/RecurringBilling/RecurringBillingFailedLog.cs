﻿using Nop.Core;
using System;
using System.Collections.Generic;
using System.Text;

namespace Nop.Plugin.Payments.PayFastComplete.Domain.RecurringBilling
{
    public partial class RecurringBillingFailedLog : BaseEntity
    {
        public DateTime LogDateTimeStamp { get; set; }

        public int IntialOrderID { get; set; }

        public bool HasBeenResolved { get; set; }

    }
}
