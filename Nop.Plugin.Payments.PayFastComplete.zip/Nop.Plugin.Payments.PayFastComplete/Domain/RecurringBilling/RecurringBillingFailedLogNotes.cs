﻿using Nop.Core;
using System;
using System.Collections.Generic;
using System.Text;

namespace Nop.Plugin.Payments.PayFastComplete.Domain.RecurringBilling
{
    public partial class RecurringBillingFailedLogNotes : BaseEntity
    {
        public int RecurringBillingFailedLogID { get; set; }
        public DateTime NoteEntryDateTimeStamp { get; set; }
        public string Note { get; set; }
        public int CustomerIDThatMadeEntry { get; set; }
    }
}
