﻿using Nop.Core.Configuration;


namespace Nop.Plugin.Payments.PayFastComplete.Settings
{
    public class PayFastCompleteSettings : ISettings
    {
        public int ApiTimeOutValue { get; set; } 
        public string MerchantId { get; set; }
        public string MerchantKey { get; set; }
        public bool UseSandbox { get; set; }
        public decimal AdditionalFee { get; set; }
        public bool AdditionalFeePercentage { get; set; }
        public string FormBaseUri { get; set; }
        public string APIBaseUri { get; set; }
        public string APIVersion { get; set; }
        public string APIPassPhrase { get; set; }

        #region API Url
        public string ApiPingUrl { get; set; }
        /// <summary>
        /// [GET] history
        /// Obtain the transaction history for given a period.
        /// Url example:
        /// https://api.payfast.co.za/transactions/history/[timeframe]
        /// or
        /// https://api.payfast.co.za/transactions/history?from=2017-01-01&to=2017-02-01
        ///  A successful history response will return comma-separated values (CSV) of required the transactions.
        /// </summary>
        public string ApiTransactionHistoryForPeriodUrl { get; set; }
        public string ApiTransactionHistoryForDailyUrl { get; set; }
        public string ApiTransactionHistoryForWeeklyUrl { get; set; }
        public string ApiTransactionHistoryForMonthlyUrl { get; set; }
        public string ApiTransactionDetailsUrl { get; set; }
        public string ApiSubmissionTestingUrl { get; set; }
        public string FormSubmissionTestingUri { get; set; }


        #region Recurring Billing Ad Hoc API End Points
        public string ApiRecurringBilling_ADHOC_CHARGE_SubscriptionUrl { get; set; }
        public string ApiRecurringBilling_COMMON_FETCH_SubscriptionUrl { get; set; }
        public string ApiRecurringBilling_COMMON_CANCEL_SubscriptionUrl { get; set; }
        public string ApiRecurringBilling_NORMAL_PAUSE_SubscriptionUrl { get; set; }
        public string ApiRecurringBilling_NORMAL_UNPAUSE_SubscriptionUrl { get; set; }
        public string ApiRecurringBilling_NORMAL_UPDATE_SubscriptionUrl { get; set; }
        #endregion
        #endregion

        #region SplitPayment
        /// <summary>
        /// Description : Merchant_id - The receiving merchant PayFast ID that must be paid.
        /// Required    : Yes
        /// Format      : numeric, 8 char
        /// /// </summary>
        public string SplitPayment_RecievingMerchantId { get; set; }

        /// <summary>
        /// Description : The amount in cents (ZAR), that will go to the receiving merchant./n
        /// Required    : Yes* (unless only percentage is used)/n
        /// Format      : numeric
        /// /// </summary>
        public decimal SplitPayment_Amount { get; set; }

        /// <summary>
        /// Description : The percentage allocated to the receiving merchant./n
        /// Required    : Yes* (unless only amount is used)/n
        /// Format      : numeric, 2 char
        /// /// </summary>
        public decimal SplitPayment_Percentage { get; set; }

        /// <summary>
        /// Description : The minimum amount that will be split, in cents (ZAR)./n
        /// Required    : Optional/n
        /// Format      : numeric
        /// /// </summary>
        public decimal SplitPayment_MinimumAmount { get; set; }

        /// <summary>
        /// Description : The maximum amount that will be split, in cents (ZAR)./n
        /// Required    : Optional/n
        /// Format      : numeric
        /// /// </summary>
        public decimal SplitPayment_MaximumAmount { get; set; }

        /// <summary>
        /// Description : Defines if the split payment is used.
        /// Required    : Optional
        /// Format      : bool
        /// /// </summary>
        public bool SplitPayment_IsSplitPaymentActive { get; set; }

        /// <summary>
        /// Description : Defines if the split payment is used.
        /// Required    : Optional
        /// Format      : bool
        /// /// </summary>
        public bool SplitPayment_IsSplitUsingAmount { get; set; }
        /// <summary>
        /// Description : Defines if the split Percentage is used.
        /// Required    : Optional
        /// Format      : bool
        /// /// </summary>
        public bool SplitPayment_IsSplitUsingPercentage { get; set; }

        /// <summary>
        /// Description : Defines if the split Minimum is used.
        /// Required    : Optional
        /// Format      : bool
        /// /// </summary>
        public bool SplitPayment_IsSplitUsingMinimumAmount { get; set; }

        /// <summary>
        /// Description : Defines if the split Minimum is used.
        /// Required    : Optional
        /// Format      : bool
        /// /// </summary>
        public bool SplitPayment_IsSplitUsingMaximumAmount { get; set; }

        /// <summary>
        /// Description : Defines if the split payment trasfered must include the shipping.
        /// Required    : Optional
        /// Format      : bool
        /// /// </summary>
        public bool SplitPayment_MustIncludeShippingCosts { get; set; }
        #endregion
    }
}
