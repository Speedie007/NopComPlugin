﻿using System;

namespace Nop.Plugin.Payments.PayFastComplete.Services.PaymentProcessingServices.Compoments.Attributes
{
    public class PayFastPaymentMethodAttribute : Attribute
    {

        #region cstor
        public PayFastPaymentMethodAttribute(string PaymentMethodName, string PaymentMethodCode)
        {
            MethodCode = PaymentMethodCode;
            MethodName = PaymentMethodName;
        }
        #endregion

        #region Properties
        public string MethodCode { get; set; }
        public string MethodName { get; set; }
        #endregion
    }
}
