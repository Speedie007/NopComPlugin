﻿using Nop.Plugin.Payments.PayFastComplete.Services.PaymentProcessingServices.Compoments.Attributes;

namespace Nop.Plugin.Payments.PayFastComplete.Services.PaymentProcessingServices.Compoments.Enumerations
{
    public enum EnumPayFastPaymentMethods
    {
        [PayFastPaymentMethod(PaymentMethodName: "EFT Payment", PaymentMethodCode: "eft")]
        EFTPayemnt,
        [PayFastPaymentMethod(PaymentMethodName: "Credit Card Payment", PaymentMethodCode: "cc")]
        CreditCardPayment,
        [PayFastPaymentMethod(PaymentMethodName: "Debit Card Payment", PaymentMethodCode: "dc")]
        DebitCardPayment,
        [PayFastPaymentMethod(PaymentMethodName: "Bit Coin Payment", PaymentMethodCode: "bc")]
        BitCointPayment,
        [PayFastPaymentMethod(PaymentMethodName: "Master Pass Payment", PaymentMethodCode: "mp")]
        MasterPassPayment,
        [PayFastPaymentMethod(PaymentMethodName: "Mobicred Payment", PaymentMethodCode: "mc")]
        MobicredPayment,
        [PayFastPaymentMethod(PaymentMethodName: "Cash Deposit Payment", PaymentMethodCode: "cd")]
        CashDeposit,
        [PayFastPaymentMethod(PaymentMethodName: "SCode Payment", PaymentMethodCode: "sc")]
        SCodePayment
    }
}
