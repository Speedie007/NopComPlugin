﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Nop.Plugin.Payments.PayFastComplete.Services.PaymentProcessingServices.Compoments.Enumerations
{
    public enum EnumRecurringBillingTypes
    {
        Subscription = 1,
        AdHoc = 2
    }
}
