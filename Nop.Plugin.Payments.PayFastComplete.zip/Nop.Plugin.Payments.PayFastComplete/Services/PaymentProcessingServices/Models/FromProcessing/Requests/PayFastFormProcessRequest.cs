﻿using Nop.Core.Domain.Orders;
using Nop.Plugin.Payments.PayFastComplete.Services.PaymentProcessingServices.Models.FromProcessing.Components;
using System;
using System.Collections.Generic;
using System.Text;

namespace Nop.Plugin.Payments.PayFastComplete.Services.PaymentProcessingServices.Models.FromProcessing.Requests
{
    public partial class PayFastFormProcessRequest
    {

        public PayFastFormProcessRequest(Order order)
        {
            OrderToProcess = order;
        }

        public Order OrderToProcess { get; private set; }
        public PayFastFormProcessingBuyerDetailModel BuyerDetails { get; set; }
        public PayFastFormProcessingMerchantDetailModel MerchantDetails { get; set; }
        public PayFastFormProcessingPaymentMethodModel PaymentMethodDetails { get; set; }
        public PayFastFormProcessingRecurringBillingSubscriptionDetailModel RecurringBillingSubscriptionDetails { get; set; }
        public PayFastFormProcessingSplitPaymentDetailModel SplitPaymentDetails { get; set; }
        public PayFastFormProcessingTransactionDetailModel TransactionDetails { get; set; }
        public PayFastFormProcessingTransactionOptionsModel TransactionOptions { get; set; }



    }
}
