﻿using Nop.Web.Framework.Models;

namespace Nop.Plugin.Payments.PayFastComplete.Services.PaymentProcessingServices.Models.FromProcessing
{
    public abstract class PayFastFormProcessRequestBaseModel : BaseNopModel
    {

        #region Cstor
        public PayFastFormProcessRequestBaseModel()

        {


        }
        #endregion
    }
}
