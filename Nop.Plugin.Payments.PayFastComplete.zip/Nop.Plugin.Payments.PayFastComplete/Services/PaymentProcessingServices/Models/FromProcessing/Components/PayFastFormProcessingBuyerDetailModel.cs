﻿using Nop.Plugin.Payments.PayFastComplete.Services.PayFastApiClientServices.Components.Attributes;
using Nop.Plugin.Payments.PayFastComplete.Services.PayFastApiClientServices.Components.Enumerations;
using System.ComponentModel.DataAnnotations;

namespace Nop.Plugin.Payments.PayFastComplete.Services.PaymentProcessingServices.Models.FromProcessing.Components
{
    public partial class PayFastFormProcessingBuyerDetailModel : PayFastFormProcessRequestBaseModel
    {


        #region Buyers Details
        /// <summary>
        /// Description : The buyer’s first name.
        /// Required    : No
        /// Format      : alphanumeric, 100 char
        /// </summary>
        [MaxLength(100)]
        [PayFastFormProcessingFieldAttribute(Key: "name_first", OrdinalValue: 5, AttributeIsRequired: false, ComponentPartOfSignature: EnumRequestComponentPartOfSignature.YES)]
        public string FirstName { get; set; }

        /// <summary>
        /// Description : The buyer’s last name.
        /// Required    : No
        /// Format      : alphanumeric, 100 cha
        /// </summary>
        [MaxLength(100)]
        [PayFastFormProcessingFieldAttribute(Key: "name_last", OrdinalValue: 6, AttributeIsRequired: false, ComponentPartOfSignature: EnumRequestComponentPartOfSignature.YES)]
        public string LastName { get; set; }

        /// <summary>
        /// Description : The buyer’s email address
        /// Required    : No
        /// Format      : alphanumeric, 100 char
        /// </summary>
        [MaxLength(100)]
        [PayFastFormProcessingFieldAttribute(Key: "email_address", OrdinalValue: 7, AttributeIsRequired: false, ComponentPartOfSignature: EnumRequestComponentPartOfSignature.YES)]
        public string EmailAddress { get; set; }

        /// <summary>
        /// Description : The buyer’s valid cell number. 
        /// If the email_address field is empty, and cell_number provided, the system will use the cell_number as the username and autologin the user, 
        /// if they do not have a registered account.
        /// Required    : Yes
        /// Format      : numeric, 10 char
        /// </summary>
        [MaxLength(10)]
        [PayFastFormProcessingFieldAttribute(Key: "cell_number", OrdinalValue: 8, AttributeIsRequired: false, ComponentPartOfSignature: EnumRequestComponentPartOfSignature.YES)]
        public string CellNumber { get; set; }
        #endregion

    }
}
