﻿using Newtonsoft.Json;
using Nop.Plugin.Payments.PayFastComplete.Services.PayFastApiClientServices.Components.Attributes;
using Nop.Plugin.Payments.PayFastComplete.Services.PayFastApiClientServices.Components.Enumerations;

namespace Nop.Plugin.Payments.PayFastComplete.Services.PaymentProcessingServices.Models.FromProcessing.Components
{
    public partial class PayFastFormProcessingSplitPaymentDetailModel : PayFastFormProcessRequestBaseModel
    {

        #region Cstor
        public PayFastFormProcessingSplitPaymentDetailModel(SplitPaymentObject Options = null)
        {
            
            if (Options is SplitPaymentObject SplitPay)
            {
                splitPaymentObject = SplitPay;
                SplitPaymentValue = JsonConvert.SerializeObject(SplitPay);
                
            }
        }
        #endregion

        #region Methods

        #endregion

        #region Split Payment Details
        public SplitPaymentObject  splitPaymentObject { get; set; }
        /// <summary>
        /// Description : The number of payments/cycles that will occur for this subscription. Set to 0 for infinity.
        /// Required    : Yes (For subscription only)
        /// Format      : numeric, 0 for indefinite subscription
        /// </summary>
        [PayFastFormProcessingFieldAttribute(Key: "setup", OrdinalValue: 31, AttributeIsRequired: false, ComponentPartOfSignature: EnumRequestComponentPartOfSignature.YES)]
        public string SplitPaymentValue { get; set; }
        #endregion

    }
}
