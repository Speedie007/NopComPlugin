﻿using Nop.Plugin.Payments.PayFastComplete.Services.PayFastApiClientServices.Components.Attributes;
using Nop.Plugin.Payments.PayFastComplete.Services.PayFastApiClientServices.Components.Enumerations;
using System.ComponentModel.DataAnnotations;

namespace Nop.Plugin.Payments.PayFastComplete.Services.PaymentProcessingServices.Models.FromProcessing.Components
{
    public partial class PayFastFormProcessingRecurringBillingSubscriptionDetailModel : PayFastFormProcessRequestBaseModel
    {

        #region Recurring Billing Details

        /// <summary>
        /// Description : The subscription type sets the recurring billing type to a subscription Or Ad-Hoc Payment. 
        /// Value is as follows:
        /// 1 – sets type to a subscription.
        /// 2 – sets type to an ad hoc payment
        /// Required    : No
        /// Format      : alphanumeric, 100 char
        /// </summary>
        [MaxLength(1)]
        [PayFastFormProcessingFieldAttribute(Key: "subscription_type", OrdinalValue: 26, AttributeIsRequired: false, ComponentPartOfSignature: EnumRequestComponentPartOfSignature.YES)]
        public string SubscriptionType { get; set; }


        /// <summary>
        /// Description : The subscription type sets the recurring billing type to a subscription Or Ad-Hoc Payment. 
        /// Value is as follows:
        /// 1 – sets type to a subscription.
        /// 2 – sets type to an ad hoc payment
        /// Required    : No
        /// Format      : decimal
        /// </summary>
        [PayFastFormProcessingFieldAttribute(Key: "billing_date", OrdinalValue: 27, AttributeIsRequired: false, ComponentPartOfSignature: EnumRequestComponentPartOfSignature.YES)]
        public string SubscriptionBillingDate { get; set; }

        /// <summary>
        /// Description : The subscription type sets the recurring billing type to a subscription Or Ad-Hoc Payment. 
        /// Value is as follows:
        /// 1 – sets type to a subscription.
        /// 2 – sets type to an ad hoc payment
        /// Required    : No
        /// Format      : decimal
        /// </summary>
        [PayFastFormProcessingFieldAttribute(Key: "recurring_amount", OrdinalValue: 28, AttributeIsRequired: false, ComponentPartOfSignature: EnumRequestComponentPartOfSignature.YES)]
        public string SubscriptionRecurringAmount { get; set; }

        /// <summary>
        /// Description : The cycle period.
        /// Required    : Yes (For subscription only)
        /// Format      : numeric:
        ///                     3- Monthly
        ///                     4- Quarterly
        ///                     5- Biannual
        ///                     6- Annual
        /// </summary>
        [PayFastFormProcessingFieldAttribute(Key: "frequency", OrdinalValue: 29, AttributeIsRequired: true, ComponentPartOfSignature: EnumRequestComponentPartOfSignature.YES)]
        public string SubscriptionFrequency { get; set; }

        /// <summary>
        /// Description : The number of payments/cycles that will occur for this subscription. Set to 0 for infinity.
        /// Required    : Yes (For subscription only)
        /// Format      : numeric, 0 for indefinite subscription
        /// </summary>
        [PayFastFormProcessingFieldAttribute(Key: "cycles", OrdinalValue: 30, AttributeIsRequired: true, ComponentPartOfSignature: EnumRequestComponentPartOfSignature.YES)]
        public string SetAmountOfSubscriptionCycles { get; set; }
        #endregion

       
    }
}
