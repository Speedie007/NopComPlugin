﻿using Nop.Plugin.Payments.PayFastComplete.Services.PayFastApiClientServices.Components.Attributes;
using Nop.Plugin.Payments.PayFastComplete.Services.PayFastApiClientServices.Components.Enumerations;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Text;

namespace Nop.Plugin.Payments.PayFastComplete.Services.PaymentProcessingServices.Models.FromProcessing.Components
{
    public partial class PayFastFormProcessingPaymentMethodModel : PayFastFormProcessRequestBaseModel
    {
        #region Set Payment Method
        /// <summary>
        /// Description : When this field is set, only the payment method specified can be used when the buyer reaches PayFast.
        /// If this field is blank, or not included, then all available payment methods will be shown.
        /// The values are as follows:
        /// eft – sets eft payment method
        /// cc – sets credit card payment method
        /// dc – sets debit card payment method
        /// bc – sets bitcoin payment method
        /// mp – sets masterpass payment method
        /// mc – sets mobicred payment method
        /// cd – sets cash deposit payment method
        /// sc – sets SCode payment method
        /// Required    : No
        /// Format      : alphanumeric, 3 char
        /// </summary>
        [MaxLength(3)]
        [PayFastFormProcessingFieldAttribute(Key: "payment_method", OrdinalValue: 25, AttributeIsRequired: false, ComponentPartOfSignature: EnumRequestComponentPartOfSignature.YES)]
        public string PaymentType { get; set; }

        #endregion
    }
}
