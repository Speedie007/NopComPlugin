﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Text.Json;
using System.Text.Json.Serialization;
using Newtonsoft.Json;
using Newtonsoft;

namespace Nop.Plugin.Payments.PayFastComplete.Services.PaymentProcessingServices.Models.FromProcessing.Components
{
    public class SplitPaymentObject
    {
        [JsonProperty(Order = 1, PropertyName = "split_payment")]
        public SplitPaymentJsonValues SplitPaymentItems { get; set; }
    }
    public class SplitPaymentJsonValues
    {

        /// <summary>
        /// Description : The receiving merchant.
        /// Required    : Yes 
        /// Format      : numeric, 8 char
        /// </summary>
        [JsonProperty(Order = 1, PropertyName = "merchant_id")]
        public int RecievingMerchantID { get; set; }

        /// <summary>
        /// Description :The amount in cents (ZAR), that will go to the receiving merchant
        /// Required    : Yes* (unless only percentage is used) 
        /// Format      : numeric
        /// </summary>
        [JsonProperty(Order = 2, PropertyName = "amount")]
        public int AmountToRecievingMerchant { get; set; }


        ///// <summary>
        ///// Description : TThe percentage allocated to the receiving merchant
        ///// Required    : Yes* (unless only amount is used) 
        ///// Format      : numeric
        ///// </summary>
        //[JsonProperty(Order = 3, PropertyName = "percentage")]
        //public string PercentageAllocatedToRecievingMerchant { get; set; }

        ///// <summary>
        ///// Description : The minimum amount that will be split, in cents (ZAR)
        ///// Required    : No 
        ///// Format      : numeric
        ///// </summary>
        //[JsonProperty(Order = 4, PropertyName = "min")]
        //public int SplitMinimumAmount { get; set; }

        ///// <summary>
        ///// Description : The maximum amount that will be split, in cents (ZAR)
        ///// Required    : No 
        ///// Format      : numeric
        ///// </summary>
        //[JsonProperty(Order = 5, PropertyName = "max")]
        //public int SplitMaximumAmount { get; set; }

    }
}
