﻿using Nop.Plugin.Payments.PayFastComplete.Services.PayFastApiClientServices.Components.Attributes;
using Nop.Plugin.Payments.PayFastComplete.Services.PayFastApiClientServices.Components.Enumerations;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Text;

namespace Nop.Plugin.Payments.PayFastComplete.Services.PaymentProcessingServices.Models.FromProcessing.Components
{
    public partial class PayFastFormProcessingTransactionDetailModel : PayFastFormProcessRequestBaseModel
    {

        #region cstor
        public PayFastFormProcessingTransactionDetailModel()
        {
            
        }
        #endregion

        #region Transactional Detils

        /// <summary>
        /// Description : Unique payment ID on the merchant’s system.
        /// Required    : No
        /// Format      : alphanumeric, 100 char
        /// </summary>
        [MaxLength(100)]
        [PayFastFormProcessingFieldAttribute(Key: "m_payment_id", OrdinalValue: 9, AttributeIsRequired: false, ComponentPartOfSignature: EnumRequestComponentPartOfSignature.YES)]
        public string MerchantPaymentID { get; set; }

        /// <summary>
        /// Description : The amount which the payer must pay in ZAR.
        /// Required    : Yes
        /// Format      : decimal - eg 100.00
        /// </summary>
        [PayFastFormProcessingFieldAttribute(Key: "amount", OrdinalValue: 10, AttributeIsRequired: true, ComponentPartOfSignature: EnumRequestComponentPartOfSignature.YES)]
        public string OrderAmount { get; set; }


        /// <summary>
        /// Description :The name of the item being charged for. In this Case it could be the order number.
        /// Required    : No
        /// Format      : alphanumeric, 100 char
        /// </summary>
        [MaxLength(100)]
        [PayFastFormProcessingFieldAttribute(Key: "item_name", OrdinalValue: 11, AttributeIsRequired: false, ComponentPartOfSignature: EnumRequestComponentPartOfSignature.YES)]
        public string OrderName { get; set; }

        /// <summary>
        /// Description : 	The description of the item being charged for.
        /// Required    : No
        /// Format      : alphanumeric, 255 char
        /// </summary>
        [MaxLength(255)]
        [PayFastFormProcessingFieldAttribute(Key: "item_description", OrdinalValue: 12, AttributeIsRequired: false, ComponentPartOfSignature: EnumRequestComponentPartOfSignature.YES)]
        public string OrderDescription { get; set; }

        /// <summary>
        /// Description : A series of 5 custom string variables (custom_str1, custom_str2…) 
        /// which can be used by the merchant as pass-through variables. 
        /// They will be posted back to the merchant at the completion of the transaction..
        /// Required    : No
        /// Format      : alphanumeric, 255 char
        /// </summary>
        [PayFastFormProcessingFieldAttribute(Key: "custom_int1", OrdinalValue: 13, AttributeIsRequired: false, ComponentPartOfSignature: EnumRequestComponentPartOfSignature.YES)]
        public int MerchantDefined_OptionalExtraIntegerField1 { get; set; } = -1;

        /// <summary>
        /// Description : A series of 5 custom integer variables (custom_int1, custom_int2…) which can be used by the merchant as pass-through variables. They will be posted back to the merchant at the completion of the transaction.
        /// Required    : No
        /// Format      : alphanumeric, 255 char
        /// </summary>
        [PayFastFormProcessingFieldAttribute(Key: "custom_int2", OrdinalValue: 14, AttributeIsRequired: false, ComponentPartOfSignature: EnumRequestComponentPartOfSignature.YES)]
        public int MerchantDefined_OptionalExtraIntegerField2 { get; set; } = -1;

        /// <summary>
        /// Description : A series of 5 custom integer variables (custom_int1, custom_int2…) which can be used by the merchant as pass-through variables. They will be posted back to the merchant at the completion of the transaction.
        /// Required    : No
        /// Format      : alphanumeric, 255 char
        /// </summary>
        [PayFastFormProcessingFieldAttribute(Key: "custom_int3", OrdinalValue: 15, AttributeIsRequired: false, ComponentPartOfSignature: EnumRequestComponentPartOfSignature.YES)]
        public int MerchantDefined_OptionalExtraIntegerField3 { get; set; } = -1;

        /// <summary>
        /// Description : A series of 5 custom integer variables (custom_int1, custom_int2…) which can be used by the merchant as pass-through variables. They will be posted back to the merchant at the completion of the transaction.
        /// Required    : No
        /// Format      : alphanumeric, 255 char
        /// </summary>
        [PayFastFormProcessingFieldAttribute(Key: "custom_int4", OrdinalValue: 16, AttributeIsRequired: false, ComponentPartOfSignature: EnumRequestComponentPartOfSignature.YES)]
        public int MerchantDefined_OptionalExtraIntegerField4 { get; set; } = -1;

        /// <summary>
        /// Description : A series of 5 custom integer variables (custom_int1, custom_int2…) which can be used by the merchant as pass-through variables. They will be posted back to the merchant at the completion of the transaction.
        /// Required    : No
        /// Format      : alphanumeric, 255 char
        /// </summary>
        [PayFastFormProcessingFieldAttribute(Key: "custom_int5", OrdinalValue: 17, AttributeIsRequired: false, ComponentPartOfSignature: EnumRequestComponentPartOfSignature.YES)]
        public int MerchantDefined_OptionalExtraIntegerField5 { get; set; } = -1;

        /// <summary>
        /// Description : A series of 5 custom string variables (custom_str1, custom_str2…) 
        /// which can be used by the merchant as pass-through variables. 
        /// They will be posted back to the merchant at the completion of the transaction..
        /// Required    : No
        /// Format      : alphanumeric, 255 char
        /// </summary>
        [MaxLength(255)]
        [PayFastFormProcessingFieldAttribute(Key: "custom_str1", OrdinalValue: 18, AttributeIsRequired: false, ComponentPartOfSignature: EnumRequestComponentPartOfSignature.YES)]
        public string MerchantDefined_OptionalExtraStringField1 { get; set; }

        /// <summary>
        /// Description : A series of 5 custom string variables (custom_str1, custom_str2…) 
        /// which can be used by the merchant as pass-through variables. 
        /// They will be posted back to the merchant at the completion of the transaction..
        /// Required    : No
        /// Format      : alphanumeric, 255 char
        /// </summary>
        [MaxLength(255)]
        [PayFastFormProcessingFieldAttribute(Key: "custom_str2", OrdinalValue: 19, AttributeIsRequired: false, ComponentPartOfSignature: EnumRequestComponentPartOfSignature.YES)]
        public string MerchantDefined_OptionalExtraStringField2 { get; set; }

        /// <summary>
        /// Description : A series of 5 custom string variables (custom_str1, custom_str2…) 
        /// which can be used by the merchant as pass-through variables. 
        /// They will be posted back to the merchant at the completion of the transaction..
        /// Required    : No
        /// Format      : alphanumeric, 255 char
        /// </summary>
        [MaxLength(255)]
        [PayFastFormProcessingFieldAttribute(Key: "custom_str3", OrdinalValue: 20, AttributeIsRequired: false, ComponentPartOfSignature: EnumRequestComponentPartOfSignature.YES)]
        public string MerchantDefined_OptionalExtraStringField3 { get; set; }

        /// <summary>
        /// Description : A series of 5 custom string variables (custom_str1, custom_str2…) 
        /// which can be used by the merchant as pass-through variables. 
        /// They will be posted back to the merchant at the completion of the transaction..
        /// Required    : No
        /// Format      : alphanumeric, 255 char
        /// </summary>
        [MaxLength(255)]
        [PayFastFormProcessingFieldAttribute(Key: "custom_str4", OrdinalValue: 21, AttributeIsRequired: false, ComponentPartOfSignature: EnumRequestComponentPartOfSignature.YES)]
        public string MerchantDefined_OptionalExtraStringField4 { get; set; }

        /// <summary>
        /// Description : A series of 5 custom string variables (custom_str1, custom_str2…) 
        /// which can be used by the merchant as pass-through variables. 
        /// They will be posted back to the merchant at the completion of the transaction..
        /// Required    : No
        /// Format      : alphanumeric, 255 char
        /// </summary>
        [MaxLength(255)]
        [PayFastFormProcessingFieldAttribute(Key: "custom_str5", OrdinalValue: 22, AttributeIsRequired: false, ComponentPartOfSignature: EnumRequestComponentPartOfSignature.YES)]
        public string MerchantDefined_OptionalExtraStringField5 { get; set; }
        #endregion
    }
}
