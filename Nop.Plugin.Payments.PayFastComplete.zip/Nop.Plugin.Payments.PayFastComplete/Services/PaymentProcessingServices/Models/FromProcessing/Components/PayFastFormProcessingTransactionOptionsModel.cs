﻿using Nop.Plugin.Payments.PayFastComplete.Services.PayFastApiClientServices.Components.Attributes;
using Nop.Plugin.Payments.PayFastComplete.Services.PayFastApiClientServices.Components.Enumerations;
using System.ComponentModel.DataAnnotations;

namespace Nop.Plugin.Payments.PayFastComplete.Services.PaymentProcessingServices.Models.FromProcessing.Components
{
    public partial class PayFastFormProcessingTransactionOptionsModel : PayFastFormProcessRequestBaseModel
    {

        #region Transaction Options
        /// <summary>
        /// Description : Whether to send email confirmation to the merchant of the transaction. 
        /// Email confirmation is automatically sent to the payer.
        /// Required    : No
        /// Format      : 1 or 0
        /// </summary>
        [PayFastFormProcessingFieldAttribute(Key: "email_confirmation", OrdinalValue: 23, AttributeIsRequired: false, ComponentPartOfSignature: EnumRequestComponentPartOfSignature.YES)]
        public string SendEmailConfirmationToMarchent { get; set; }

        /// <summary>
        /// Description : The address to send the confirmation email to.
        /// Required    : No
        /// Format      : alphanumeric, 100 char
        /// </summary>
        [MaxLength(100)]
        [PayFastFormProcessingFieldAttribute(Key: "confirmation_address", OrdinalValue: 24, AttributeIsRequired: false, ComponentPartOfSignature: EnumRequestComponentPartOfSignature.YES)]
        public string EmailAddressToSendConfirmationToMerchant { get; set; }
        #endregion
    }
}
