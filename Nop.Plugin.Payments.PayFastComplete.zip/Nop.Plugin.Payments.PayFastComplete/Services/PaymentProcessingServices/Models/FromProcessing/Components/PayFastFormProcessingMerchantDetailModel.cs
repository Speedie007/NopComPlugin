﻿using Nop.Plugin.Payments.PayFastComplete.Services.PayFastApiClientServices.Components.Attributes;
using Nop.Plugin.Payments.PayFastComplete.Services.PayFastApiClientServices.Components.Enumerations;

namespace Nop.Plugin.Payments.PayFastComplete.Services.PaymentProcessingServices.Models.FromProcessing.Components
{
    public partial class PayFastFormProcessingMerchantDetailModel : PayFastFormProcessRequestBaseModel
    {


        #region Cstor
        public PayFastFormProcessingMerchantDetailModel() 
        {
           
        }
        #endregion


        #region Properties
        #region Merchant Details
        /// <summary>
        /// Description : The Merchant ID as given by the PayFast system. Used to uniquely identify the receiving account.
        ///               This can be found on the merchant’s settings page.
        /// Required    : Yes
        /// Format      : numeric.
        /// </summary>
        [PayFastFormProcessingFieldAttribute(Key: "merchant_id", OrdinalValue: 0, AttributeIsRequired: true, ComponentPartOfSignature: EnumRequestComponentPartOfSignature.YES)]
        public string MerchantID { get; set; }

        /// <summary>
        /// Description : The Merchant Key as given by the PayFast system. 
        /// Used to uniquely identify the receiving account. 
        /// This provides an extra level of certainty concerning the correct account as both the ID and the Key must be correct in order for the transaction to proceed.
        /// This can be found on the merchant’s settings page.
        /// Required    : Yes
        /// Format      : alphanumeric.
        /// </summary>
        [PayFastFormProcessingFieldAttribute(Key: "merchant_key", OrdinalValue: 1, AttributeIsRequired: true, ComponentPartOfSignature: EnumRequestComponentPartOfSignature.YES)]
        public string MerchantKey { get; set; }

        /// <summary>
        /// Description : The URL where the user is returned to after payment has been successfully taken.
        /// Required    : Yes
        /// Format      : url
        /// </summary>
        [PayFastFormProcessingFieldAttribute(Key: "return_url", OrdinalValue: 2, AttributeIsRequired: true, ComponentPartOfSignature: EnumRequestComponentPartOfSignature.YES)]
        public string ReturnUrl { get; set; }

        /// <summary>
        /// Description : The Merchant ID as given by the PayFast system. Used to uniquely identify the receiving account.
        ///               This can be found on the merchant’s settings page.
        /// Required    : No
        /// Format      : url
        /// </summary>
        [PayFastFormProcessingFieldAttribute(Key: "cancel_url", OrdinalValue: 3, AttributeIsRequired: true, ComponentPartOfSignature: EnumRequestComponentPartOfSignature.YES)]
        public string CancelUrl { get; set; }

        /// <summary>
        /// Description : The URL which is used by PayFast to post the Instant Transaction Notifications (ITNs) for this transaction.
        /// Required    : No
        /// Format      : url
        /// </summary>
        [PayFastFormProcessingFieldAttribute(Key: "notify_url", OrdinalValue: 4, AttributeIsRequired: true, ComponentPartOfSignature: EnumRequestComponentPartOfSignature.YES)]
        public string NotifyUrl { get; set; }
        #endregion

        


      


      


       

        

        #endregion
    }
}
