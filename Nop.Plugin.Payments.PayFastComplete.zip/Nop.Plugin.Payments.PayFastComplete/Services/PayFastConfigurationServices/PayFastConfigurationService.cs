﻿using Nop.Core;
using Nop.Core.Infrastructure.Mapper;
using Nop.Plugin.Payments.PayFastComplete.Areas.Admin.Models.Configuration;
using Nop.Plugin.Payments.PayFastComplete.Infrastructure.Common.Results;
using Nop.Plugin.Payments.PayFastComplete.Settings;
using Nop.Services.Configuration;
using System;
using System.Collections.Generic;
using System.Text;

namespace Nop.Plugin.Payments.PayFastComplete.Services.PayFastConfigurationServices
{
    public partial interface IPayFastConfigurationService
    {
        SettingsResult UpdateUrlCpnfiguration(UrlConfigurationViewModel model);
        SettingsResult UpdateConfigurationSettings(SecuritySettingsViewModel model);

        SettingsResult UpdateSplitPaymentOptions(SpiltPaymentsViewModel model);
        SettingsResult UpdateConfigurationTesting(ConfigurationTestingViewModel model);

        SettingsResult UpdateAdditionalCharges(AdditionalChargesViewModel model);
    }
    public partial class PayFastConfigurationService : IPayFastConfigurationService
    {

        #region Fields
        private readonly ISettingService _settingService;
        private readonly IStoreContext _storeContext;
        private readonly PayFastCompleteSettings _payFastCompleteSettings;
        #endregion

        #region cstor
        public PayFastConfigurationService(
             PayFastCompleteSettings payFastCompleteSettings,
            IStoreContext storeContext,
            ISettingService settingService
            )
        {
            _settingService = settingService;
            _storeContext = storeContext;
            _payFastCompleteSettings = payFastCompleteSettings;
        }

        public SettingsResult UpdateAdditionalCharges(AdditionalChargesViewModel model)
        {
            SettingsResult Rtn = new SettingsResult();

            try
            {
                Rtn.SettingsProcessed = (PayFastCompleteSettings)AutoMapperConfiguration.Mapper.Map(model, _payFastCompleteSettings, typeof(AdditionalChargesViewModel), typeof(PayFastCompleteSettings));
                _settingService.ClearCache();
                _settingService.SaveSetting<PayFastCompleteSettings>(Rtn.SettingsProcessed, _storeContext.CurrentStore.Id);

            }
            catch (Exception ex)
            {

                Rtn.AddError($"Error Updating Addtioanl Charges: Error Message: {ex.Message}");
            }
            return Rtn;
        }

        public SettingsResult UpdateConfigurationSettings(SecuritySettingsViewModel model)
        {
            SettingsResult Rtn = new SettingsResult();

            try
            {
                Rtn.SettingsProcessed = (PayFastCompleteSettings)AutoMapperConfiguration.Mapper.Map(model, _payFastCompleteSettings, typeof(SecuritySettingsViewModel), typeof(PayFastCompleteSettings));
                _settingService.ClearCache();
                _settingService.SaveSetting<PayFastCompleteSettings>(Rtn.SettingsProcessed, _storeContext.CurrentStore.Id);

            }
            catch (Exception ex)
            {

                Rtn.AddError($"Error Updating Configuration Settings : Error Message: {ex.Message}");
            }
            return Rtn;
        }

        public SettingsResult UpdateConfigurationTesting(ConfigurationTestingViewModel model)
        {
            SettingsResult Rtn = new SettingsResult();

            try
            {
                Rtn.SettingsProcessed = (PayFastCompleteSettings)AutoMapperConfiguration.Mapper.Map(model, _payFastCompleteSettings, typeof(ConfigurationTestingViewModel), typeof(PayFastCompleteSettings));
                _settingService.ClearCache();
                _settingService.SaveSetting<PayFastCompleteSettings>(Rtn.SettingsProcessed, _storeContext.CurrentStore.Id);

            }
            catch (Exception ex)
            {

                Rtn.AddError($"Error Updating Configuration Testing : Error Message: {ex.Message}");
            }
            return Rtn;
        }

        public SettingsResult UpdateSplitPaymentOptions(SpiltPaymentsViewModel model)
        {
            SettingsResult Rtn = new SettingsResult();

            try
            {
                Rtn.SettingsProcessed = (PayFastCompleteSettings)AutoMapperConfiguration.Mapper.Map(model, _payFastCompleteSettings, typeof(SpiltPaymentsViewModel), typeof(PayFastCompleteSettings));
                _settingService.ClearCache();
                _settingService.SaveSetting<PayFastCompleteSettings>(Rtn.SettingsProcessed, _storeContext.CurrentStore.Id);

            }
            catch (Exception ex)
            {

                Rtn.AddError($"Error Updating Url Configuration : Error Message: {ex.Message}");
            }
            return Rtn;
        }

        public SettingsResult UpdateUrlCpnfiguration(UrlConfigurationViewModel model)
        {
            SettingsResult Rtn = new SettingsResult();

            try
            {
                Rtn.SettingsProcessed = (PayFastCompleteSettings)AutoMapperConfiguration.Mapper.Map(model, _payFastCompleteSettings, typeof(UrlConfigurationViewModel), typeof(PayFastCompleteSettings));
                _settingService.ClearCache();
                _settingService.SaveSetting<PayFastCompleteSettings>(Rtn.SettingsProcessed, _storeContext.CurrentStore.Id);

            }
            catch (Exception ex)
            {

                Rtn.AddError($"Error Updating Url Configuration : Error Message: {ex.Message}");
            }
            return Rtn;
        }
        #endregion


    }
}
