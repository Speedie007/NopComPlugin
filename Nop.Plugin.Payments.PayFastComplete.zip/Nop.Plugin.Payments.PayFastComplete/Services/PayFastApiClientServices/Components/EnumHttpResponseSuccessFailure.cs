﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Nop.Plugin.Payments.PayFastComplete.Services.PayFastApiClientServices.Components
{
    public enum EnumHttpResponseSuccessFailure
    {
        Success,
        Failure
    }
}
