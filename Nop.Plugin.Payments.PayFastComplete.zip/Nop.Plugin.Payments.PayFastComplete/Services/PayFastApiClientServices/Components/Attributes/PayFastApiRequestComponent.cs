﻿using Nop.Plugin.Payments.PayFastComplete.Services.PayFastApiClientServices.Components.Enumerations;
using System;

namespace Nop.Plugin.Payments.PayFastComplete.Services.PayFastApiClientServices.Components.Attributes
{
    public class PayFastApiRequestComponent : Attribute
    {

        #region Cstor
        public PayFastApiRequestComponent(
            string Key,
            bool AttributeIsRequired,
            EnumRequestComponentUsage ComponentUsage,
             EnumRequestComponentPartOfSignature ComponentPartOfSignature
            )
        {
            RequestKeyValue = Key;
            RequestComponentUsage = ComponentUsage;
            RequestComponentIsRequired = AttributeIsRequired;
            RequestComponentPartOfSignature = ComponentPartOfSignature;
        }
        #endregion

        #region Properties
        public string RequestKeyValue { get; private set; }
        public bool RequestComponentIsRequired { get; private set; }
        public EnumRequestComponentUsage RequestComponentUsage { get; set; }
        public EnumRequestComponentPartOfSignature RequestComponentPartOfSignature { get; set; }
        #endregion
    }
}
