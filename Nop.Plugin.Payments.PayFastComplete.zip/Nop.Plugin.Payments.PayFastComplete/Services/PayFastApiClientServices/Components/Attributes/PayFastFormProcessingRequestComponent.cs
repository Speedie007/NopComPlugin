﻿using Nop.Plugin.Payments.PayFastComplete.Services.PayFastApiClientServices.Components.Enumerations;
using System;

namespace Nop.Plugin.Payments.PayFastComplete.Services.PayFastApiClientServices.Components.Attributes
{
    public class PayFastFormProcessingFieldAttribute : Attribute
    {


        #region cstor
        public PayFastFormProcessingFieldAttribute(
            string Key,
            int OrdinalValue,
            bool AttributeIsRequired,
            EnumRequestComponentPartOfSignature ComponentPartOfSignature
            )
        {
            RequestKeyValue = Key;
            RequestOrdinal = OrdinalValue;
            RequestComponentIsRequired = AttributeIsRequired;
            RequestComponentPartOfSignature = ComponentPartOfSignature;
        }
        #endregion

        #region Properties
        public string RequestKeyValue { get; private set; }
        public int RequestOrdinal { get; set; }
        public bool RequestComponentIsRequired { get; private set; }
        public EnumRequestComponentPartOfSignature RequestComponentPartOfSignature { get; set; }
        #endregion
    }
}
