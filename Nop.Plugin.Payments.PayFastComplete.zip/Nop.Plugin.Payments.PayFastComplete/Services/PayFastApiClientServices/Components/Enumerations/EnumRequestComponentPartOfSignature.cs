﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Nop.Plugin.Payments.PayFastComplete.Services.PayFastApiClientServices.Components.Enumerations
{
    public enum EnumRequestComponentPartOfSignature
    {
        NO,
        YES
    }
}
