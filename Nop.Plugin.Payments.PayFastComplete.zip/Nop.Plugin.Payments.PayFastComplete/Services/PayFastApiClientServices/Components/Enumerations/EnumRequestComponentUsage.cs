﻿using System;

namespace Nop.Plugin.Payments.PayFastComplete.Services.PayFastApiClientServices.Components.Enumerations
{
    public enum EnumRequestComponentUsage
    {
        Header,
        Body
    }
}
