﻿using LinqToDB.Common;
using Nop.Core;
using Nop.Plugin.Payments.PayFastComplete.Extensions;
using Nop.Plugin.Payments.PayFastComplete.Infrastructure.Common;
using Nop.Plugin.Payments.PayFastComplete.Infrastructure.Common.Results;
using Nop.Plugin.Payments.PayFastComplete.Services.PayFastApiClientServices.Models.Api;
using Nop.Plugin.Payments.PayFastComplete.Services.PayFastApiClientServices.Models.Api.Requests.AdHocSubscription;
using Nop.Plugin.Payments.PayFastComplete.Services.PayFastApiClientServices.Models.Api.Requests.NormalSubscription;
using Nop.Plugin.Payments.PayFastComplete.Services.PayFastApiClientServices.Models.Api.Requests.SubscriptionCommon;
using Nop.Plugin.Payments.PayFastComplete.Services.PayFastApiClientServices.Models.Api.Requests.TransactionalHistory;
using Nop.Plugin.Payments.PayFastComplete.Services.PayFastApiClientServices.Models.Api.Results;
using Nop.Plugin.Payments.PayFastComplete.Services.PayFastApiClientServices.Models.Api.Results.SubscriptionAdHoc;
using Nop.Plugin.Payments.PayFastComplete.Services.PayFastApiClientServices.Models.Api.Results.SubscriptionCommon;
using Nop.Plugin.Payments.PayFastComplete.Services.PayFastApiClientServices.Models.Api.Results.SubscriptionNormal;
using Nop.Plugin.Payments.PayFastComplete.Services.PayFastApiClientServices.Models.Api.Results.TransactionHistroy;
using Nop.Plugin.Payments.PayFastComplete.Services.PaymentProcessingServices.Models.FromProcessing.Components;
using Nop.Plugin.Payments.PayFastComplete.Settings;
using Nop.Services.Logging;
using Renci.SshNet.Messages.Authentication;
using System;
using System.Net.Http;
using System.Text;

namespace Nop.Plugin.Payments.PayFastComplete.Services.IPayFastApiClientServices
{
    public interface IPayFastApiClientService
    {
        //void ProcessRequestToApiGateway<TRequest, TResult>(TRequest ApiResquest, TResult RequestResult) where TRequest : PayFastApiRequestBaseModel where TResult : Result;


        #region ApiTesting
        PingPayFastApiGatewayResult PingPayFastApiGateway();
        #endregion

        #region Recurring Payment Methods
        StandardSuccsessFailurePayFastApiResult CancelReccuringPayment(string SubscriptionToken);
        StandardSuccsessFailurePayFastApiResult ChargeAdHocRecurringPayment(
            string AmountToCharge,
            string OrderNumber,
            string SubscriptionRemoteToken,
            string OrderNameOrShortDescription = null,
            string OrderDescriptionOrFullDescription = null,
            string Must_ITN_BeSent = "1",
             string SplitPayment = null);
        #endregion
        #region Trtansaction History Methods
        TransactionHistoryPayFastApiGatewayResult GetTransactionHistoryBySelectedToAndFromPeriod(string FromDate, string ToDate);
        /// <summary>
        /// <para>Gets all transactions for a selected day</para>
        /// </summary>
        /// <param name="Date">Date for which the daily transactions are required, If Null will default to today.</param>
        TransactionHistoryPayFastApiGatewayResult GetTransactionHistoryBySelectedDailyPeriod(string Date = null);
        TransactionHistoryPayFastApiGatewayResult GetTransactionHistoryBySelectedMonthPeriod(string Date);
        TransactionHistoryPayFastApiGatewayResult GetTransactionHistoryBySelectedWeekPeriod(string Date);

        #endregion
    }

    public class PayFastApiClientService : IPayFastApiClientService
    {

        #region Fields
        private readonly HttpClient _client;
        private readonly ILogger _logger;
        private readonly IWebHelper _webHelper;
        private readonly PayFastCompleteSettings _payFastCompleteSettings;
        #endregion

        #region Ctor
        public PayFastApiClientService(
                  HttpClient client,
                  PayFastCompleteSettings payFastCompleteSettings,
                  IWebHelper webHelper,
                  ILogger logger)
        {
            _logger = logger;
            _webHelper = webHelper;
            _payFastCompleteSettings = payFastCompleteSettings;

            string sUri = _payFastCompleteSettings.APIBaseUri.IsNullOrEmpty() == false ? _payFastCompleteSettings.APIBaseUri : PayFastCompleteDefaults.ApiSubmissionBaseUri;
            client.BaseAddress = new Uri($"https://{sUri}");
            client.Timeout = TimeSpan.FromSeconds(60);

            _client = client;
        }
        #endregion


        #region Transaction History Methods

        public TransactionHistoryPayFastApiGatewayResult GetTransactionHistoryBySelectedDailyPeriod(string Date = null)
        {
            TransactionHistoryPayFastApiGatewayResult result = new TransactionHistoryPayFastApiGatewayResult();
            //cause no date is supplied it defaults to todays date.
            ProcessRequestToApiGateway(new PayFastApiTransactionHistoryDailyModel(Date), result);

            return result;
        }

        public TransactionHistoryPayFastApiGatewayResult GetTransactionHistoryBySelectedMonthPeriod(string Date)
        {
            TransactionHistoryPayFastApiGatewayResult result = new TransactionHistoryPayFastApiGatewayResult();
            //cause no date is supplied it defaults to todays date.
            ProcessRequestToApiGateway(new PayFastApiTransactionMonthlyHistoryModel(Date), result);

            return result;
        }

        public TransactionHistoryPayFastApiGatewayResult GetTransactionHistoryBySelectedToAndFromPeriod(string FromDate, string ToDate)
        {
            TransactionHistoryPayFastApiGatewayResult result = new TransactionHistoryPayFastApiGatewayResult();
            //cause no date is supplied it defaults to todays date.
            ProcessRequestToApiGateway(new PayFastApiTransactionHistoryRequestModel(FromDate, ToDate), result);

            return result;
        }

        public TransactionHistoryPayFastApiGatewayResult GetTransactionHistoryBySelectedWeekPeriod(string Date)
        {
            TransactionHistoryPayFastApiGatewayResult result = new TransactionHistoryPayFastApiGatewayResult();
            //cause no date is supplied it defaults to todays date.
            ProcessRequestToApiGateway(new PayFastApiTransactionWeeklyHistoryModel(Date), result);

            return result;
        }
        #endregion

        #region Api Testing
        public PingPayFastApiGatewayResult PingPayFastApiGateway()
        {

            //Ping the GateWay to validate the the gateway is active.
            PingPayFastApiGatewayResult ApiPingResult = new PingPayFastApiGatewayResult();
            ProcessRequestToApiGateway(new PayFastApiPingRequestModel(), ApiPingResult);
            //IF Api Active.
            if (!ApiPingResult.Success)
            {

                foreach (var item in ApiPingResult.Errors)
                {
                    _logger.Error($"Ping to PayFast Gateway encounter error while attempting to update the Transaction History : [{DateTime.Now}], Internal Errors :[{item}]", null, null);
                }

            }
            return ApiPingResult;
        }
        #endregion


        /// <summary>
        /// <para>Charge an ad hoc subscription based on token.</para>
        /// <para>Example:</para> 
        /// <para><code>
        /// https://api.payfast.co.za/subscriptions/dc0521d3-55fe-269b-fa00-b647310d760f/adhoc 
        /// </code></para>
        /// <para>This Model when processed/Passed through for Processing  will send a </para>
        /// <para>POST request to the PayFast Api. this represents a new subscription Order.</para>
        /// <para>The Api will send a ITN REquest back to the system to proces and generate a new recurring order if the payment is succssfull.</para>
        /// </summary>
        /// <param name="AmountToCharge">
        ///     <para>This is the order amount that must be charged.</para>
        ///     <para>Will be added to the Body of the Request.</para>
        ///     <para>The amount which the buyer must pay, in CENTS (ZAR).</para>
        /// </param>
        /// <param name="OrderNumber">This is the GUID number/Order number for the original order that was place from the system.</param>
        /// <param name="SubscriptionRemoteToken">Token used to identify an ad hoc subscription to Charge.</param>
        /// <param name="OrderNameOrShortDescription">Short Description noramlly the order number with the data.</param>
        /// <param name="OrderDescriptionOrFullDescription">Description of the order items being processed.</param>
        /// <param name="Must_ITN_BeSent">This indicates wheather or not the Api must send a ITN to the system so that it can process the next Subscrition Order.</param>
        public StandardSuccsessFailurePayFastApiResult ChargeAdHocRecurringPayment(
            string AmountToCharge,
            string OrderNumber,
            string SubscriptionRemoteToken,
            string OrderNameOrShortDescription = null,
            string OrderDescriptionOrFullDescription = null,
            string Must_ITN_BeSent = "1",
            string SplitPayment = null
            )
        {
            StandardSuccsessFailurePayFastApiResult result = new StandardSuccsessFailurePayFastApiResult();

            ProcessRequestToApiGateway(new PayFastApiAdHocChargeModel(
                   AmountToCharge: AmountToCharge.ToString(),
                   OrderNumber: OrderNumber,
                   SubscriptionRemoteToken: SubscriptionRemoteToken,
                   OrderNameOrShortDescription: OrderNameOrShortDescription,
                   OrderDescriptionOrFullDescription: OrderDescriptionOrFullDescription,
                   Must_ITN_BeSent: Must_ITN_BeSent,
                   SplitPayment: SplitPayment
               ), result);

            return result;
        }
        public StandardSuccsessFailurePayFastApiResult CancelReccuringPayment(string SubscriptionToken)
        {
            StandardSuccsessFailurePayFastApiResult result = new StandardSuccsessFailurePayFastApiResult();

            if (!SubscriptionToken.IsNullOrEmpty())
            {
                ProcessRequestToApiGateway(new PayFastApiSubscriptionCommonCancelModel(SubscriptionToken), result);
            }
            else
            {
                result.AddError($"Subscription Token can not be empty or null. Error attempting to Cancel recurring billing subscription.");
            }


            return result;
        }




        #region Utilities

        private void ProcessRequestToApiGateway<TRequest, TResult>(TRequest ApiResquest, TResult RequestResult)
        where TRequest : PayFastApiRequestBaseModel
        where TResult : Result
        {

            //Populates the request Model with the relievant values
            GenerateRequestSignatureResult GenerateSignatureResult = ApiResquest.GenerateRequestSignature();
            if (GenerateSignatureResult.Success)
            {
                BuildApiRequestResult BApiRResult = _client.BuildApiRequest(ApiResquest);
                if (BApiRResult.Success)
                {
                    try
                    {
                        HttpResponseMessage response = SendRequest(ApiResquest);
                        if (response.IsSuccessStatusCode)
                        {
                            try
                            {
                                ProcessSuccesssfulHttpResponse(RequestResult, response);
                            }
                            catch (Exception ex)
                            {
                                RequestResult.AddError($"Failed To Deserialize the OK response from the API(GateWay) while attempting to process the successful response from the {nameof(ApiResquest)} request: Internal Error:{ex.Message}");
                            }
                        }
                        else
                        {
                            try
                            {
                                HttpRequestMessage message = new HttpRequestMessage() { 
                                   
                                };
                                RequestResult.AddError(response.GetHttpProcessingErrorMessage());
                                ProcessUnSuccesssfulHttpResponse(RequestResult, response);
                            }
                            catch (Exception ex)
                            {
                                RequestResult.AddError($"Failed To process the Error message generated from the response from the API(GateWay) while attempting to process the {nameof(ApiResquest)} Request: Internal Error:{ex.Message}");
                            }
                        }
                    }
                    catch (Exception ex)
                    {
                        RequestResult.AddError($"Failed To Send the request to the API(GateWay) while attempting to process the {nameof(ApiResquest)} Request: Internal Error:{ex.Message}");
                    }

                }
                else
                    RequestResult.CombineError(BApiRResult.Errors);

            }
            else
                RequestResult.CombineError(GenerateSignatureResult.Errors);


            ///<summary>
            ///<para>This in a private inner method used to sent the request tot the PayFast Api</para>
            ///
            /// </summary>
            HttpResponseMessage SendRequest(object ApiResquest) => ApiResquest switch
            {

                #region Recurring Billing - Ad Hoc Methods
                PayFastApiAdHocChargeModel RequestToSend => _client.PostAsync(RequestToSend.TargetUrl, RequestToSend.GetHttpRequestStringContent()).Result,
                #endregion
                #region Recurring Billing -Common Methods
                PayFastApiSubscriptionCommonFetchModel RequestToSend => _client.GetAsync(RequestToSend.TargetUrl).Result,
                PayFastApiSubscriptionCommonCancelModel RequestToSend => _client.PutAsync(RequestToSend.TargetUrl, RequestToSend.GetHttpRequestStringContent()).Result,
                #endregion
                #region Recurring Billing - Subscriptions
                PayFastApiNormalSubscriptionPauseModel RequestToSend => _client.PutAsync(RequestToSend.TargetUrl, RequestToSend.GetHttpRequestStringContent()).Result,
                PayFastApiNormalSubscriptionUnpauseModel RequestToSend => _client.PutAsync(RequestToSend.TargetUrl, RequestToSend.GetHttpRequestStringContent()).Result,
                PayFastApiNormalSubscriptionUpdateModel RequestToSend => _client.PatchAsync(RequestToSend.TargetUrl, RequestToSend.GetHttpRequestStringContent()).Result,
                #endregion
                #region Pay Fast Accounts - Transaction History
                PayFastApiTransactionMonthlyHistoryModel RequestToSend => _client.GetAsync(RequestToSend.TargetUrl).Result,
                PayFastApiTransactionWeeklyHistoryModel RequestToSend => _client.GetAsync(RequestToSend.TargetUrl).Result,
                PayFastApiTransactionHistoryDailyModel RequestToSend => _client.GetAsync(RequestToSend.TargetUrl).Result,
                PayFastApiTransactionHistoryRequestModel RequestToSend => _client.GetAsync(RequestToSend.TargetUrl).Result,
                #endregion
                #region Api Testing - PING
                PayFastApiPingRequestModel RequestToSend => _client.GetAsync(RequestToSend.TargetUrl).Result,
                #endregion
                { } => throw new ArgumentException(message: "Not a known request type", paramName: nameof(TRequest)),
                null => throw new ArgumentNullException(nameof(TRequest))
            };
            Result ProcessSuccesssfulHttpResponse(TResult RequestResult, HttpResponseMessage response)
            {
                return RequestResult switch
                {
                    #region Recurring Billing Result
                    SubscriptionNormalFetchSuccessFailurePayFastApiResult ResultToReturn => ResultToReturn.SetSuccessfulResponse(response.Content.ReadAsStringAsync().Result),
                    SubscriptionNormalUpdateSuccessFailurePayFastApiResult ResultToReturn => ResultToReturn.SetSuccessfulResponse(response.Content.ReadAsStringAsync().Result),
                    SubscriptionAdHocFetchSuccessFailurePayFastApiResult ResultToReturn => ResultToReturn.SetSuccessfulResponse(response.Content.ReadAsStringAsync().Result),
                    #endregion
                    #region General Standard Result
                    StandardSuccsessFailurePayFastApiResult ResultToReturn => ResultToReturn.SetSuccessfulResponse(response.Content.ReadAsStringAsync().Result),
                    #endregion
                    #region Ping Succes Result
                    PingPayFastApiGatewayResult ResultToReturn => ResultToReturn.SetSuccessfulResponse(response.Content.ReadAsStringAsync().Result),
                    #endregion
                    #region Transaction History Success Result
                    TransactionHistoryPayFastApiGatewayResult ResultToReturn => ResultToReturn.ProcessSuccessfulResponse(response.Content.ReadAsStringAsync().Result),
                    #endregion
                    { } => throw new ArgumentException(message: "Not a known result type", paramName: nameof(TResult)),
                    null => throw new ArgumentNullException(nameof(TResult))
                };
            }
            Result ProcessUnSuccesssfulHttpResponse(TResult RequestResult, HttpResponseMessage response)
            {
                return RequestResult switch
                {
                    #region Recurring Billing Result
                    SubscriptionNormalFetchSuccessFailurePayFastApiResult ResultToReturn => ResultToReturn.SetUnSuccessfulResponse(response.Content.ReadAsStringAsync().Result),
                    SubscriptionNormalUpdateSuccessFailurePayFastApiResult ResultToReturn => ResultToReturn.SetUnSuccessfulResponse(response.Content.ReadAsStringAsync().Result),
                    SubscriptionAdHocFetchSuccessFailurePayFastApiResult ResultToReturn => ResultToReturn.SetUnSuccessfulResponse(response.Content.ReadAsStringAsync().Result),
                    #endregion 
                    #region General Standard Result
                    StandardSuccsessFailurePayFastApiResult ResultToReturn => ResultToReturn.SetUnSuccessfulResponse(response.Content.ReadAsStringAsync().Result),
                    #endregion
                    #region Ping Succes Result
                    PingPayFastApiGatewayResult ResultToReturn => ResultToReturn.SetUnSuccessfulResponse(response.Content.ReadAsStringAsync().Result),
                    #endregion
                    #region Transaction History Success Result
                    TransactionHistoryPayFastApiGatewayResult ResultToReturn => ResultToReturn.SetUnSuccessfulResponse(response.Content.ReadAsStringAsync().Result),
                    #endregion
                    { } => throw new ArgumentException(message: "Not a known result type", paramName: nameof(TResult)),
                    null => throw new ArgumentNullException(nameof(TResult))
                };
            }
        }
        #endregion
    }
}
