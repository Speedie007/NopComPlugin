﻿using LinqToDB.Common;
using Newtonsoft.Json;
using Nop.Core.Infrastructure;
using Nop.Plugin.Payments.PayFastComplete.Extensions;
using Nop.Plugin.Payments.PayFastComplete.Infrastructure.Common.Enumerations;
using Nop.Plugin.Payments.PayFastComplete.Services.PayFastApiClientServices.Components.Attributes;
using Nop.Plugin.Payments.PayFastComplete.Services.PayFastApiClientServices.Components.Enumerations;
using Nop.Plugin.Payments.PayFastComplete.Services.PayFastApiClientServices.Models.Api.Results;
using Nop.Plugin.Payments.PayFastComplete.Settings;
using Nop.Services.Logging;
using System;
using System.Collections.Generic;
using System.Net.Http;
using System.Reflection;


namespace Nop.Plugin.Payments.PayFastComplete.Services.PayFastApiClientServices.Models.Api
{
    public interface IPayFastRequestBaseModel
    {
        //void IntitiliseSignatureDataSet();

        GenerateRequestSignatureResult GenerateRequestSignature();

        void SetRequiredProperties();

    }
    [JsonObject(MemberSerialization.OptIn)]
    public abstract class PayFastApiRequestBaseModel : IPayFastRequestBaseModel
    {
        protected readonly ILogger _logger;
        protected readonly PayFastCompleteSettings _payFastCompleteSettings;

        public PayFastApiRequestBaseModel() : this(
            EngineContext.Current.Resolve<PayFastCompleteSettings>(),
            EngineContext.Current.Resolve<ILogger>()) { }

        public PayFastApiRequestBaseModel(PayFastCompleteSettings payFastCompleteSettings, ILogger logger)
        {
            _logger = logger;
            _payFastCompleteSettings = payFastCompleteSettings;
            RequestBodyMetaData = new SortedDictionary<string, string>();
            SetRequiredProperties();
        }

        public string TargetUrl { get; set; }
        public abstract EnumHttpVerbs ActionType { get; }

        public SortedDictionary<string, string> RequestBodyMetaData { get; private set; }
        public StringContent JsonSerilisedRequestBody { get; set; }



        #region Request Header Properties



        /// <summary>
        /// Description : Header, the Merchant ID as given by the PayFast system..
        /// Required    : Yes.
        /// Format      : Numeric, 8 charaters.
        /// </summary>
        [PayFastApiRequestComponent(Key: "merchant-id", AttributeIsRequired: true, ComponentUsage: EnumRequestComponentUsage.Header, ComponentPartOfSignature: EnumRequestComponentPartOfSignature.YES)]
        public virtual string MerchantID { get; set; }

        /// <summary>
        /// Description : Header, the PayFast API version.
        /// Required    : Yes
        /// Format      : v1
        /// </summary>
        [PayFastApiRequestComponent(Key: "version", AttributeIsRequired: true, ComponentUsage: EnumRequestComponentUsage.Header, ComponentPartOfSignature: EnumRequestComponentPartOfSignature.YES)]
        public virtual string Version { get; set; }


        /// <summary>
        /// Description : Header, the current timestamp.
        /// Required    : Yes.
        /// Format      : ISO-8601 date and time, YYYY-MM-DDTHH:MM:SS[+HH:MM]
        /// The[+HH:MM] section of the time stamp is optional. will default to +02:00, South African (Pertoria) Time if not added.
        /// </summary>
        [PayFastApiRequestComponent(Key: "timestamp", AttributeIsRequired: true, ComponentUsage: EnumRequestComponentUsage.Header, ComponentPartOfSignature: EnumRequestComponentPartOfSignature.YES)]
        public virtual string TimeStamp { get; set; }


        /// <summary>
        /// Description : Header, MD5 hash of the alphabetised submitted header and body variables, as well as the passphrase.
        /// Required    : Yes
        /// Format      : MD5 hash, characters must be in lower case.
        /// </summary>
        [PayFastApiRequestComponent(Key: "signature", AttributeIsRequired: true, ComponentUsage: EnumRequestComponentUsage.Header, ComponentPartOfSignature: EnumRequestComponentPartOfSignature.NO)]
        public virtual string Signature { get; set; }
        #endregion



        #region Methods

        /// <summary>
        /// <para>This method is used by request that employ the any request that require a payload in the body of the request, such as a  POST or PUT.</para>
        /// <para>Else this method does nothing and can bew set to return NULL</para>
        /// </summary>
        /// <returns></returns>
        public abstract StringContent GetHttpRequestStringContent();
        //{
        //    StringContent stringContent = new StringContent("", Encoding.UTF8, MimeTypes.ApplicationJson);
        //    if (RequestBodyMetaData.Count > 0)
        //    {
        //        /*If any type of Request (POST,PUT,PATCH) the optioanl paramters are serilised into a Json Object.
        //         * This Json will be uploaded as part of the request body to the Api.
        //         * GET request use a query string to submit the optional parameters required.
        //         * *******************************************************************************/
        //        return new StringContent(JsonConvert.SerializeObject(RequestBodyMetaData), Encoding.UTF8, MimeTypes.ApplicationJson);
        //    }
        //    return stringContent;
        //}

        public virtual GenerateRequestSignatureResult GenerateRequestSignature()
        {


            GenerateRequestSignatureResult result = new GenerateRequestSignatureResult();
            SortedDictionary<string, string> SignaturekeyValuePairs = new SortedDictionary<string, string>();

            Type t = GetType();
            PropertyInfo[] props = t.GetProperties();

            //Model.MerchantID = payFastCompleteSettings.MerchantId;
            //Model.Version = payFastCompleteSettings.APIVersion;
            //Model.TimeStamp = DateTime.Now.GeneratePayFastApiHeaderTimeStamp();//"2020-08-15T16:25:39+02:00"

            if (!(_payFastCompleteSettings.APIPassPhrase.IsNullOrEmpty()))
            {
                SignaturekeyValuePairs.Add("passphrase", _payFastCompleteSettings.APIPassPhrase);
            }
            else
            {
                result.AddError("Pass Phrase has mot been set!");
                return result;
            }

            foreach (var prop in props)
            {
                var attrib = prop.GetCustomAttribute<PayFastApiRequestComponent>();
                if (attrib != null)
                {
                    if (attrib.RequestComponentPartOfSignature == EnumRequestComponentPartOfSignature.YES)
                    {
                        if (!(prop.GetValue(this) is null))
                        {
                            SignaturekeyValuePairs.Add(attrib.RequestKeyValue, prop.GetValue(this).ToString());
                            _logger.Error($"Key Value Pair For the API Signature - KEY - {attrib.RequestKeyValue} :  VALUE - {prop.GetValue(this).ToString()} ", null, null);
                        }
                    }
                }
            }

            try
            {
                /*Encode the required Parameters to generate the Signature to be added to the request header.
                 * *****************************************************************************************/
                Signature = SignaturekeyValuePairs.GetUrlEncodedString().GetMD5Hash();
                _logger.Error($"-------------------------------------------------------------------", null, null);
                _logger.Error($"API QUERY HEADER Signature: [ {Signature} ]", null, null);
                result.MD5Signature = Signature;
            }
            catch (Exception ex)
            {
                result.AddError($"Error Encoding the Header Signature while gnerating the MD5 Checksum. - Internal error: {ex.Message}");
            }


            return result;


        }

        public void SetRequiredProperties()
        {
            MerchantID = _payFastCompleteSettings.MerchantId;
            Version = _payFastCompleteSettings.APIVersion;
           
            TimeStamp = DateTime.Now.GeneratePayFastApiHeaderTimeStamp();//"2020-08-15T16:25:39+02:00"
            _logger.Error($"API QUERY HEADER ITEMS", null, null);
            _logger.Error($"-------------------------------------------------------------------", null, null);
            _logger.Error($"API QUERY HEADER TimeStamp: [ {TimeStamp} ]", null, null);
        }



        #endregion

    }


}
