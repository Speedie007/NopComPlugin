﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Nop.Plugin.Payments.PayFastComplete.Services.PayFastApiClientServices.Models.Api
{
    public abstract class PayFastApiRequestBaseBodySerilizationModel
    {
    }
}
