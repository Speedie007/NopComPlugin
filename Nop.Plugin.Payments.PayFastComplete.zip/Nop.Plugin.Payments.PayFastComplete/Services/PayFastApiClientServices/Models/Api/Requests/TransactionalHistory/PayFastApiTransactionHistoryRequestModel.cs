﻿using Nop.Plugin.Payments.PayFastComplete.Infrastructure.Common.Enumerations;
using Nop.Plugin.Payments.PayFastComplete.Services.PayFastApiClientServices.Components.Attributes;
using Nop.Plugin.Payments.PayFastComplete.Services.PayFastApiClientServices.Components.Enumerations;
using Nop.Plugin.Payments.PayFastComplete.Services.PayFastApiClientServices.Models.Api.Results;
using System.Net.Http;

namespace Nop.Plugin.Payments.PayFastComplete.Services.PayFastApiClientServices.Models.Api.Requests.TransactionalHistory
{
    public class PayFastApiTransactionHistoryRequestModel : PayFastApiRequestBaseModel
    {

        #region Cstor
        /// <summary>
        /// This Request will return  all transaction between a specified From and To Date.
        /// </summary>
        /// <param name="payFastCompleteSettings"></param>
        /// <param name="_DateFrom"></param>
        /// <param name="_DateTo"></param>
        public PayFastApiTransactionHistoryRequestModel(string _DateFrom = null, string _DateTo = null)
        {
            DateFrom = _DateFrom;
            DateTo = _DateTo;
        }
        #endregion


        #region Properties
        public override EnumHttpVerbs ActionType => EnumHttpVerbs.GET;

        /// <summary>
        /// Description : Body, start date for the time period. Defaults to current month.
        /// Required    : Optional
        /// Format      : YYYY-MM-DD
        /// </summary>
        [PayFastApiRequestComponent(Key: "from", AttributeIsRequired: false, ComponentUsage: EnumRequestComponentUsage.Body, ComponentPartOfSignature: EnumRequestComponentPartOfSignature.YES)]
        public string DateFrom { get; set; }

        /// <summary>
        /// Description : Body, end date for the time period. Defaults to current date.
        /// Required    : Optional
        /// Format      : YYYY-MM-DD
        /// </summary>
        [PayFastApiRequestComponent(Key: "to", AttributeIsRequired: false, ComponentUsage: EnumRequestComponentUsage.Body, ComponentPartOfSignature: EnumRequestComponentPartOfSignature.YES)]
        public string DateTo { get; set; }
        #endregion

        #region Methods
        public override GenerateRequestSignatureResult GenerateRequestSignature()
        {
            return base.GenerateRequestSignature();
        }

        public override StringContent GetHttpRequestStringContent()
        {
            return null;
        }


        #endregion

    }
}
