﻿using Nop.Plugin.Payments.PayFastComplete.Infrastructure.Common.Enumerations;
using Nop.Plugin.Payments.PayFastComplete.Services.PayFastApiClientServices.Components.Attributes;
using Nop.Plugin.Payments.PayFastComplete.Services.PayFastApiClientServices.Components.Enumerations;
using System.Net.Http;

namespace Nop.Plugin.Payments.PayFastComplete.Services.PayFastApiClientServices.Models.Api.Requests.TransactionalHistory
{
    public class PayFastApiTransactionHistoryDailyModel : PayFastApiRequestBaseModel
    {

        #region Cstor
        /// <summary>
        /// 
        /// </summary>
        /// <param name="_SelectedDay">Date of the Selected day you wish to view. Defaults automatically to current date if ommitted(not provided)</param>
        public PayFastApiTransactionHistoryDailyModel(string _SelectedDay = null)
        {

            SelectedDay = _SelectedDay;
        }
        #endregion

        #region Properties
        public override EnumHttpVerbs ActionType => EnumHttpVerbs.GET;

        /// <summary>
        /// Description : Body, date of the time period. Defaults to current date.
        /// Required    : Optional
        /// Format      : YYYY-MM-DD
        /// </summary>
        [PayFastApiRequestComponent(Key: "date", AttributeIsRequired: false, ComponentUsage: EnumRequestComponentUsage.Body, ComponentPartOfSignature: EnumRequestComponentPartOfSignature.YES)]
        public string SelectedDay { get; private set; }

      
        #endregion

        #region Methods
         public override StringContent GetHttpRequestStringContent()
        {
            return null;
        }


        #endregion
    }

}

