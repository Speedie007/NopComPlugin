﻿using Newtonsoft.Json;
using Nop.Core;
using Nop.Plugin.Payments.PayFastComplete.Infrastructure.Common.Enumerations;
using Nop.Plugin.Payments.PayFastComplete.Services.PayFastApiClientServices.Components.Attributes;
using Nop.Plugin.Payments.PayFastComplete.Services.PayFastApiClientServices.Components.Enumerations;
using Nop.Plugin.Payments.PayFastComplete.Services.PayFastApiClientServices.Models.Api.Requests.SubscriptionNormal.Serilization;
using System.Net.Http;
using System.Text;

namespace Nop.Plugin.Payments.PayFastComplete.Services.PayFastApiClientServices.Models.Api.Requests.NormalSubscription
{
    public partial class PayFastApiNormalSubscriptionPauseModel : PayFastApiRequestBaseModel
    {
   

      

        #region cstor
        public PayFastApiNormalSubscriptionPauseModel(string AmountOfCycles, string PayFastSubscriptionToken)
        {
            iAmountOfCycles = AmountOfCycles;
            SubscriptionToken = PayFastSubscriptionToken;
        }
        #endregion

        #region properties
        public string SubscriptionToken { get; set; }
        /// <summary>
        /// <para>Description : Body,  number of cycles to pause the subscription for. Default is 1 if not given.</para>
        /// <para>Required    : Optional</para>
        /// <para>Format      : numeric</para>
        /// </summary>
        [PayFastApiRequestComponent(Key: "cycles", AttributeIsRequired: true, ComponentUsage: EnumRequestComponentUsage.Body, ComponentPartOfSignature: EnumRequestComponentPartOfSignature.YES)]
        public string iAmountOfCycles { get; private set; }
        #endregion
        public override EnumHttpVerbs ActionType => EnumHttpVerbs.PUT;

        /// <summary>
        /// <para>This is the Update Call Request Body - Serilises PayFastApiNormalSubscriptionPauseSerilizationModel with the reliavant parameters</para>
        /// </summary>
        /// <returns>
        /// <para>StringContent for the Request Body which houses the following parameters:</para>
        /// <para>cycles -  number of cycles to pause the subscription for. Default is 1 if not given. </para>
        /// </returns>
        public override StringContent GetHttpRequestStringContent()
        {
            ///<summary>
            ///<para>If any type of Request (POST,PUT,PATCH) the optioanl paramters are serilised into a Json Object.</para>
            ///<para>This Json will be uploaded as part of the request body to the Api.</para>
            /// </summary>
            if(int.TryParse(iAmountOfCycles, out int iAmountOfCyclesOut))
            {
                PayFastApiNormalSubscriptionPauseSerilizationModel modelToSerilise = new PayFastApiNormalSubscriptionPauseSerilizationModel()
                {
                    AmountOfCyclesToPause = iAmountOfCyclesOut
                };
                return new StringContent(JsonConvert.SerializeObject(modelToSerilise), Encoding.UTF8, MimeTypes.ApplicationJson);
            }

            return new StringContent("", Encoding.UTF8, MimeTypes.ApplicationJson);
        }
    }
}
