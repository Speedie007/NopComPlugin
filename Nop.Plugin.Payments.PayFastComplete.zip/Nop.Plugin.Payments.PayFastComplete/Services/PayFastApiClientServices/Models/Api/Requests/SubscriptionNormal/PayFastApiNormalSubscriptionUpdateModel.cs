﻿using Newtonsoft.Json;
using Nop.Core;
using Nop.Plugin.Payments.PayFastComplete.Infrastructure.Common.Enumerations;
using Nop.Plugin.Payments.PayFastComplete.Services.PayFastApiClientServices.Components.Attributes;
using Nop.Plugin.Payments.PayFastComplete.Services.PayFastApiClientServices.Components.Enumerations;
using Nop.Plugin.Payments.PayFastComplete.Services.PayFastApiClientServices.Models.Api.Requests.SubscriptionNormal.Serilization;
using SixLabors.ImageSharp.ColorSpaces;
using System;
using System.Collections.Generic;
using System.Net.Http;
using System.Text;

namespace Nop.Plugin.Payments.PayFastComplete.Services.PayFastApiClientServices.Models.Api.Requests.NormalSubscription
{
    public partial class PayFastApiNormalSubscriptionUpdateModel : PayFastApiRequestBaseModel
    {
        #region Cstor
        public PayFastApiNormalSubscriptionUpdateModel(
            string AmountOfCycles, string Frequency, string NextRunDate, string AmountToChargeClient, string PayFastSubscriptionToken)
        {
            SubscriptionToken = PayFastSubscriptionToken;
            iAmountOfCycles = AmountOfCycles;
            iFrequency = Frequency;
            dtNextRunDate = NextRunDate;
            iAmountChargedToClient = AmountToChargeClient;
        }
        #endregion

        #region Properties
        public string SubscriptionToken { get; set; }

        /// <summary>
        /// <para>Description : Body, the number of cycles for the subscription.</para>
        /// <para>Required    : Optional</para>
        /// <para>Format      : numeric</para>
        /// </summary>
        [PayFastApiRequestComponent(Key: "cycles", AttributeIsRequired: true, ComponentUsage: EnumRequestComponentUsage.Body, ComponentPartOfSignature: EnumRequestComponentPartOfSignature.YES)]
        public string iAmountOfCycles { get; private set; }

        /// <summary>
        /// <para>Description : Body, the frequency for the subscription.</para>
        /// <para>Required    : Optional</para>
        /// <para>Format      : numeric</para>
        /// </summary>
        [PayFastApiRequestComponent(Key: "frequency", AttributeIsRequired: true, ComponentUsage: EnumRequestComponentUsage.Body, ComponentPartOfSignature: EnumRequestComponentPartOfSignature.YES)]
        public string iFrequency { get; set; }

        /// <summary>
        /// <para>Description : Body, the next run date for the subscription.</para>
        /// <para>Required    : Optional</para>
        /// <para>Format      : YYYY-MM-DD</para>
        /// </summary>
        [PayFastApiRequestComponent(Key: "run_date", AttributeIsRequired: true, ComponentUsage: EnumRequestComponentUsage.Body, ComponentPartOfSignature: EnumRequestComponentPartOfSignature.YES)]
        public string dtNextRunDate { get; private set; }

        /// <summary>
        /// <para>Description : Body, the amount which the buyer must pay, in CENTS (ZAR).</para>
        /// <para>Required    : Yes</para>
        /// <para>Format      : numeric</para>
        /// </summary>
        [PayFastApiRequestComponent(Key: "amount", AttributeIsRequired: true, ComponentUsage: EnumRequestComponentUsage.Body, ComponentPartOfSignature: EnumRequestComponentPartOfSignature.YES)]
        public string iAmountChargedToClient { get; private set; }

        #endregion
        public override EnumHttpVerbs ActionType => EnumHttpVerbs.PATCH;

        /// <summary>
        /// <para>This is the Update Call Request Body - Serilises PayFastApiNormalSubscriptionUpdateSerilizationModel with the reliavant parameters</para>
        /// </summary>
        /// <returns>
        /// <para>StringContent for the Request Body which houses the following parameters:</para>
        /// <para>cycles    - the number of cycles for the subscription. </para>
        /// <para>frequency - the frequency for the subscription.</para>
        /// <para>run_date  - the next run date for the subscription.</para>
        /// <para>amount    - the amount which the buyer must pay, in CENTS (ZAR).</para>
        /// </returns>
        public override StringContent GetHttpRequestStringContent()
        {

            ///<summary>
            ///<para>If any type of Request (POST,PUT,PATCH) the optioanl paramters are serilised into a Json Object.</para>
            ///<para>This Json will be uploaded as part of the request body to the Api.</para>
            /// </summary>
            PayFastApiNormalSubscriptionUpdateSerilizationModel modelToSerilise = null;
            if (int.TryParse(iAmountChargedToClient, out int AmountChargedToClientOut) && int.TryParse(iFrequency, out int FrequencyOut) && int.TryParse(iAmountOfCycles, out int AmountOfCyclesOut))
            {
                modelToSerilise = new PayFastApiNormalSubscriptionUpdateSerilizationModel()
                {

                    AmountChargedToClient = AmountChargedToClientOut,
                    Frequency = FrequencyOut,
                    NextRunDate = dtNextRunDate,
                    SetAmountCycles = AmountOfCyclesOut
                };
                return new StringContent(JsonConvert.SerializeObject(modelToSerilise), Encoding.UTF8, MimeTypes.ApplicationJson);
            }

            return new StringContent("", Encoding.UTF8, MimeTypes.ApplicationJson);
        }
    }
}
