﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Text;

namespace Nop.Plugin.Payments.PayFastComplete.Services.PayFastApiClientServices.Models.Api.Requests.SubscriptionNormal.Serilization
{
    [JsonObject(MemberSerialization.OptIn)]
    public partial class PayFastApiNormalSubscriptionUpdateSerilizationModel : PayFastApiRequestBaseBodySerilizationModel
    {

        /// <summary>
        /// <para>Description : Body, number of cycles to pause the subscription for. Default is 1 if not given.</para>
        /// <para>Required    : Optional</para>
        /// <para>Format      : numeric</para>
        /// </summary>
        [JsonProperty(Order = 2, PropertyName = "cycles")]
        public int SetAmountCycles { get; set; }

        /// <summary>
        /// <para>Description : Body, the frequency for the subscription.</para>
        /// <para>Required    : Optional</para>
        /// <para>Format      : numeric</para>
        /// </summary>
        [JsonProperty(Order = 3, PropertyName = "frequency")]
        public int Frequency { get; set; }

        /// <summary>
        /// <para>Description : Body, the next run date for the subscription.</para>
        /// <para>Required    : Optional</para>
        /// <para>Format      : YYYY-MM-DD</para>
        /// </summary>
        [JsonProperty(Order = 4, PropertyName = "run_date")]
        public string NextRunDate { get; set; }

        /// <summary>
        /// <para>Description : Body, the amount which the buyer must pay, in CENTS (ZAR).</para>
        /// <para>Required    : Yes</para>
        /// <para>Format      : numeric</para>
        /// </summary>
        [JsonProperty(Order = 1, PropertyName = "amount")]
        public int AmountChargedToClient { get; set; }

    }
}
