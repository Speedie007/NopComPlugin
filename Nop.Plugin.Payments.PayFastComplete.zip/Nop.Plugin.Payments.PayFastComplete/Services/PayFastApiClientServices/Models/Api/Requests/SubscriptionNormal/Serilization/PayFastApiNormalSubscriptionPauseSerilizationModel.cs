﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Text;

namespace Nop.Plugin.Payments.PayFastComplete.Services.PayFastApiClientServices.Models.Api.Requests.SubscriptionNormal.Serilization
{
    [JsonObject(MemberSerialization.OptIn)]
    public partial class PayFastApiNormalSubscriptionPauseSerilizationModel : PayFastApiRequestBaseBodySerilizationModel
    {

        /// <summary>
        /// <para>Description : Body, number of cycles to pause the subscription for. Default is 1 if not given.</para>
        /// <para>Required    : Optional</para>
        /// <para>Format      : numeric</para>
        /// </summary>
        [JsonProperty(Order = 1, PropertyName = "cycles")]
        public int AmountOfCyclesToPause { get; set; }

    }
}
