﻿using Newtonsoft.Json;
using Nop.Core;
using Nop.Plugin.Payments.PayFastComplete.Infrastructure.Common.Enumerations;
using Nop.Plugin.Payments.PayFastComplete.Services.PayFastApiClientServices.Components.Attributes;
using Nop.Plugin.Payments.PayFastComplete.Services.PayFastApiClientServices.Components.Enumerations;
using Nop.Plugin.Payments.PayFastComplete.Services.PayFastApiClientServices.Models.Api.Requests.AdHocSubscription.Serialization;
using Nop.Plugin.Payments.PayFastComplete.Services.PaymentProcessingServices.Models.FromProcessing.Components;
using System;
using System.Collections.Generic;
using System.Net.Http;
using System.Text;

namespace Nop.Plugin.Payments.PayFastComplete.Services.PayFastApiClientServices.Models.Api.Requests.AdHocSubscription
{
    [JsonObject(MemberSerialization.OptIn)]
    public class PayFastApiAdHocChargeModel : PayFastApiRequestBaseModel
    {

        #region Cstor

        /// <summary>
        /// <para>Charge an ad hoc subscription based on token.</para>
        /// <para>Example:</para> 
        /// <para><code>
        /// https://api.payfast.co.za/subscriptions/dc0521d3-55fe-269b-fa00-b647310d760f/adhoc 
        /// </code></para>
        /// <para>This Model when processed/Passed through for Processing  will send a </para>
        /// <para>POST request to the PayFast Api. this represents a new subscription Order.</para>
        /// <para>The Api will send a ITN REquest to </para>
        /// </summary>
        /// <param name="AmountToCharge">
        ///     <para>This is the order amount that must be charged.</para>
        ///     <para>Will be added to the Body of the Request.</para>
        ///     <para>The amount which the buyer must pay, in CENTS (ZAR).</para>
        /// </param>
        /// <param name="OrderNumber">This is the GUID number/Order number for the original order that was place from the system.</param>
        /// <param name="SubscriptionRemoteToken">Token used to identify an ad hoc subscription to Charge.</param>
        /// <param name="OrderNameOrShortDescription">Short Description noramlly the order number with the data.</param>
        /// <param name="OrderDescriptionOrFullDescription">Description of the order items being processed.</param>
        /// <param name="Must_ITN_BeSent">This indicates wheather or not the Api must send a ITN to the system so that it can process the next Subscrition Order.</param>
        /// <param name="SplitPayment">Split Payment details for the selected order being charged.</param>
        public PayFastApiAdHocChargeModel(
            string AmountToCharge,
            string OrderNumber,
            string SubscriptionRemoteToken,
            string OrderNameOrShortDescription = "Unknow Order Number",
            string OrderDescriptionOrFullDescription = "None To Add",
            string Must_ITN_BeSent = "1",
            string SplitPayment = null
        )
        {

            SubscriptionToken = SubscriptionRemoteToken;
            OrderName = OrderNameOrShortDescription;
            OrderDescription = OrderDescriptionOrFullDescription;
            AmountChargedToClient = AmountToCharge;
            MerchantPaymentID = OrderNumber;
            MustSendITN = Must_ITN_BeSent;
            SplitPaymentValue = SplitPayment;
        }
        #endregion

        #region Properties

        //
        public string SubscriptionToken { get; set; }
        /// <summary>
        /// <para>Description : Body, the amount which the buyer must pay, in CENTS (ZAR).</para>
        /// <para>Required    : Yes</para>
        /// <para>Format      : numeric</para>
        /// </summary>

        [PayFastApiRequestComponent(Key: "amount", AttributeIsRequired: true, ComponentUsage: EnumRequestComponentUsage.Body, ComponentPartOfSignature: EnumRequestComponentPartOfSignature.YES)]
        [JsonProperty(Order = 1, PropertyName = "amount")]
        public string AmountChargedToClient { get; private set; }


        /// <summary>
        /// <para>Description : Body, the name of the item being charged for.</para>
        /// <para>Required    : Yes</para>
        /// <para>Format      : alphanumeric</para>
        /// </summary>
        [PayFastApiRequestComponent(Key: "item_name", AttributeIsRequired: true, ComponentUsage: EnumRequestComponentUsage.Body, ComponentPartOfSignature: EnumRequestComponentPartOfSignature.YES)]
        [JsonProperty(Order = 2, PropertyName = "item_name")]
        public string OrderName { get; private set; }


        /// <summary>
        /// <para>Description : Body, the name of the item being charged for.</para>
        /// <para>Required    : No</para>
        /// <para>Format      : alphanumeric</para>
        /// </summary>
        [PayFastApiRequestComponent(Key: "item_description", AttributeIsRequired: false, ComponentUsage: EnumRequestComponentUsage.Body, ComponentPartOfSignature: EnumRequestComponentPartOfSignature.YES)]
        [JsonProperty(Order = 3, PropertyName = "item_description")]
        public string OrderDescription { get; set; }


        /// <summary>
        /// <para>Description : Body, specify whether an ITN must be sent for the ad hoc charge (1 by default).</para>
        /// <para>Required    : No</para>
        /// <para>Format      : true or false</para>
        /// </summary>
        [PayFastApiRequestComponent(Key: "itn", AttributeIsRequired: false, ComponentUsage: EnumRequestComponentUsage.Body, ComponentPartOfSignature: EnumRequestComponentPartOfSignature.YES)]
        [JsonProperty(Order = 4, PropertyName = "itn")]
        public string MustSendITN { get; set; }

        /// <summary>
        /// <para>Description : Body, unique payment ID on the merchant’s system.</para>
        /// <para>Required    : No</para>
        /// <para>Format      : alphanumeric</para>
        /// </summary>
        [PayFastApiRequestComponent(Key: "m_payment_id", AttributeIsRequired: false, ComponentUsage: EnumRequestComponentUsage.Body, ComponentPartOfSignature: EnumRequestComponentPartOfSignature.YES)]
        [JsonProperty(Order = 5, PropertyName = "m_payment_id")]
        public string MerchantPaymentID { get; set; }

        /// <summary>
        /// 
        /// </summary>
        [PayFastApiRequestComponent(Key: "split_payment", AttributeIsRequired: false, ComponentUsage: EnumRequestComponentUsage.Body, ComponentPartOfSignature: EnumRequestComponentPartOfSignature.YES)]
        [JsonProperty(Order = 6, PropertyName = "split_payment")]
        public string SplitPaymentValue { get; set; }


        #endregion
        public override EnumHttpVerbs ActionType => EnumHttpVerbs.POST;

        /// <summary>
        /// <para>This is the Charge Call Request Body - Serilises PayFastApiAdHocChargeRequestBodySerilizationModel with the reliavant parameters</para>
        /// </summary>
        /// <returns>
        /// <para>StringContent for the Request Body which houses the following parameters:</para>
        /// <para>amount            - the amount which the buyer must pay, in CENTS (ZAR). </para>
        /// <para>item_name         - the name of the item being charged for.</para>
        /// <para>itemDescription   - the description of the item being charged for.</para>
        /// <para>itn               - specify whether an ITN must be sent for the ad hoc charge (1 by default).</para>
        /// <para>m_Payment_id      - unique payment ID on the merchant’s system.</para>
        /// </returns>
        public override StringContent GetHttpRequestStringContent()
        {
            ///<summary>
            ///<para>If any type of Request (POST,PUT,PATCH) the optioanl paramters are serilised into a Json Object.</para>
            ///<para>This Json will be uploaded as part of the request body to the Api.</para>
            /// </summary>
            PayFastApiAdHocChargeRequestBodySerilizationModel modelToSerilise = null;
            if (int.TryParse(AmountChargedToClient, out int AmountChargedToClientOut))
            {
                modelToSerilise = new PayFastApiAdHocChargeRequestBodySerilizationModel()
                {
                    AmountChargedToClient = AmountChargedToClientOut,
                    MerchantPaymentID = MerchantPaymentID,
                    MustSendITN = MustSendITN.Equals("1") ? 1 : 0,
                    OrderDescription = OrderDescription,
                    OrderName = OrderName,
                    SplitPaymentValue = SplitPaymentValue is null ? null :SplitPaymentValue
                };

                string Body = "";
                foreach (KeyValuePair<string, string> item in RequestBodyMetaData)
                {
                    if (Body.Length > 0)
                    {
                        Body += "&";
                    }
                    Body += $"{item.Key}={item.Value}";
                }

                _logger.InsertLog(Core.Domain.Logging.LogLevel.Debug, "Building Body of the charge request", $"{JsonConvert.SerializeObject(modelToSerilise)}");
                _logger.InsertLog(Core.Domain.Logging.LogLevel.Debug, "Building Body of the charge request - String Content", $"{new StringContent(JsonConvert.SerializeObject(modelToSerilise), Encoding.UTF8, MimeTypes.ApplicationJson)}");
                return new StringContent(JsonConvert.SerializeObject(modelToSerilise), Encoding.UTF8, MimeTypes.ApplicationJson);
            }

            return new StringContent("", Encoding.UTF8, MimeTypes.ApplicationJson);
        }
    }
}
