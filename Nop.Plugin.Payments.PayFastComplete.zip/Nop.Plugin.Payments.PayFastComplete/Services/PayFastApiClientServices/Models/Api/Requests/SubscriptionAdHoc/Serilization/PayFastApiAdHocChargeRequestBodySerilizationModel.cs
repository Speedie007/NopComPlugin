﻿using Newtonsoft.Json;
using Nop.Plugin.Payments.PayFastComplete.Services.PaymentProcessingServices.Models.FromProcessing.Components;
using System;
using System.Collections.Generic;
using System.Text;

namespace Nop.Plugin.Payments.PayFastComplete.Services.PayFastApiClientServices.Models.Api.Requests.AdHocSubscription.Serialization
{
    [JsonObject(MemberSerialization.OptIn, ItemNullValueHandling = NullValueHandling.Ignore)]
    public class PayFastApiAdHocChargeRequestBodySerilizationModel : PayFastApiRequestBaseBodySerilizationModel
    {
        /// <summary>
        /// <para>Description : Body, the amount which the buyer must pay, in CENTS (ZAR).</para>
        /// <para>Required    : Yes</para>
        /// <para>Format      : numeric</para>
        /// </summary>
        [JsonProperty(Order = 1, PropertyName = "amount")]
        public int AmountChargedToClient { get; set; }


        /// <summary>
        /// <para>Description : Body, the name of the item being charged for.</para>
        /// <para>Required    : Yes</para>
        /// <para>Format      : alphanumeric</para>
        /// </summary>
        [JsonProperty(Order = 3, PropertyName = "item_name")]
        public string OrderName { get; set; }


        /// <summary>
        /// <para>Description : Body, the name of the item being charged for.</para>
        /// <para>Required    : No</para>
        /// <para>Format      : alphanumeric</para>
        /// </summary>
        [JsonProperty(Order = 2, PropertyName = "item_description")]
        public string OrderDescription { get; set; }


        /// <summary>
        /// <para>Description : Body, specify whether an ITN must be sent for the ad hoc charge (1 by default).</para>
        /// <para>Required    : No</para>
        /// <para>Format      : true or false</para>
        /// </summary>
        [JsonProperty(Order = 4, PropertyName = "itn")]
        public int MustSendITN { get; set; }

        /// <summary>
        /// <para>Description : Body, unique payment ID on the merchant’s system.</para>
        /// <para>Required    : No</para>
        /// <para>Format      : alphanumeric</para>
        /// </summary>
        [JsonProperty(Order = 5, PropertyName = "m_payment_id")]
        public string MerchantPaymentID { get; set; }

        [JsonProperty(Order = 6, PropertyName = "split_payment")]
        public string SplitPaymentValue { get; set; }
        //public SplitPaymentJsonValues SplitPaymentValue { get; set; }

    }
}
