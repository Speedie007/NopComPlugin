﻿using Nop.Plugin.Payments.PayFastComplete.Infrastructure.Common.Enumerations;
using Nop.Plugin.Payments.PayFastComplete.Services.PayFastApiClientServices.Models.Api.Results;
using System.Net.Http;

namespace Nop.Plugin.Payments.PayFastComplete.Services.PayFastApiClientServices.Models.Api.Requests.SubscriptionCommon
{
    public class PayFastApiPingRequestModel : PayFastApiRequestBaseModel
    {
        //private readonly PayFastCompleteSettings _payFastCompleteSettings;
        #region Fields

        #endregion

        #region Cstor


        public PayFastApiPingRequestModel() : base()
        {
           
        }

        public override EnumHttpVerbs ActionType => EnumHttpVerbs.GET;



        #endregion
        #region Properties
        //Ping Request Has No Addtional Properties.
        #endregion
        #region Methods
        public override GenerateRequestSignatureResult GenerateRequestSignature()
        {
           
            return base.GenerateRequestSignature();
        }

        public override StringContent GetHttpRequestStringContent()
        {
            return null;
        }


        #endregion
    }
}
