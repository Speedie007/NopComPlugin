﻿using Nop.Core;
using Nop.Plugin.Payments.PayFastComplete.Infrastructure.Common.Enumerations;
using System.Net.Http;
using System.Text;

namespace Nop.Plugin.Payments.PayFastComplete.Services.PayFastApiClientServices.Models.Api.Requests.SubscriptionCommon
{
    public class PayFastApiSubscriptionCommonCancelModel : PayFastApiRequestBaseModel
    {

        #region Cstor
        public PayFastApiSubscriptionCommonCancelModel(string PayFastSubscriptionToken)
        {
            SubscriptionToken = PayFastSubscriptionToken;
        }
        #endregion

        #region Properties
        public string SubscriptionToken { get; set; }
        #endregion
        public override EnumHttpVerbs ActionType => EnumHttpVerbs.PUT;

        /// <summary>
        /// <para>This is the Cancel Call Request Body</para>
        /// </summary>
        /// <returns>Empty Body as this method requires no variable to be uploaded with the request.</returns>
        public override StringContent GetHttpRequestStringContent()
        {
            return new StringContent("", Encoding.UTF8, MimeTypes.ApplicationJson);
        }
    }
}
