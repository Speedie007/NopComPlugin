﻿using Nop.Plugin.Payments.PayFastComplete.Infrastructure.Common.Results;
using System;
using System.Collections.Generic;
using System.Text;

namespace Nop.Plugin.Payments.PayFastComplete.Services.PayFastApiClientServices.Models.Api.Results
{
    public class GenerateRequestSignatureResult: Result
    {
        public GenerateRequestSignatureResult()
        {
                
        }

        public string MD5Signature { get; set; }
    }
}
