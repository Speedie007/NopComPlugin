﻿using Newtonsoft.Json;
using Nop.Plugin.Payments.PayFastComplete.Infrastructure.Common;
using Nop.Plugin.Payments.PayFastComplete.Infrastructure.Common.Results;
using Nop.Plugin.Payments.PayFastComplete.Services.PayFastApiClientServices.Models.Api.Responses;
using Nop.Plugin.Payments.PayFastComplete.Services.PayFastApiClientServices.Models.Api.Responses.SubscriptionAdHoc;

namespace Nop.Plugin.Payments.PayFastComplete.Services.PayFastApiClientServices.Models.Api.Results.SubscriptionAdHoc
{
    public partial class SubscriptionAdHocFetchSuccessFailurePayFastApiResult: Result
    {

        
        public SubscriptionAdHocFetchSuccessResponse SuccessfulResponse { get; set; }
        public StandardSuccsessFailurePayFastApiResponse UnsuccessfulResponse { get; set; }
        internal SubscriptionAdHocFetchSuccessFailurePayFastApiResult SetSuccessfulResponse(string ResponseString)
        {

            SuccessfulResponse = JsonConvert.DeserializeObject<SubscriptionAdHocFetchSuccessResponse>(ResponseString);
            if (SuccessfulResponse.HTTPStatus.Equals(PayFastCompleteDefaults.API_CALL_RESPONSE_FAILED) ||
                SuccessfulResponse.HTTPStatus.Equals(PayFastCompleteDefaults.API_CALL_RESPONSE_ERROR))
            {
                Errors.Add($"Response Successfully recieved, response Message has errors - ERROR: STATUS: " +
                    $"{SuccessfulResponse.HTTPStatus} of the response : HTTP Response Code " +
                    $"{SuccessfulResponse.HTTPResponseCode}, Error Message: " +
                    $"{JsonConvert.DeserializeObject(ResponseString)} ");
            }
            return this;
        }

        internal SubscriptionAdHocFetchSuccessFailurePayFastApiResult SetUnSuccessfulResponse(string ResponseString)
        {
            UnsuccessfulResponse = JsonConvert.DeserializeObject<StandardSuccsessFailurePayFastApiResponse>(ResponseString);
            return this;
        }

    }
}
