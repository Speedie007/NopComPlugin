﻿using Newtonsoft.Json;
using Nop.Plugin.Payments.PayFastComplete.Infrastructure.Common;
using Nop.Plugin.Payments.PayFastComplete.Infrastructure.Common.Results;
using Nop.Plugin.Payments.PayFastComplete.Services.PayFastApiClientServices.Models.Api.Responses;
using Nop.Plugin.Payments.PayFastComplete.Services.PayFastApiClientServices.Models.Api.Responses.SubscriptionNormal;
using System;
using System.Collections.Generic;
using System.Text;

namespace Nop.Plugin.Payments.PayFastComplete.Services.PayFastApiClientServices.Models.Api.Results.SubscriptionNormal
{
    public partial class SubscriptionNormalUpdateSuccessFailurePayFastApiResult : Result
    {
        public SubscriptionNormalUpdateSuccessFailurePayFastApiResult()
        {
            SuccessfulResponse = new SubscriptionNormalUpdateFetchSuccessResponse();
            UnsuccessfulResponse = new StandardSuccsessFailurePayFastApiResponse();
        }

        public SubscriptionNormalUpdateFetchSuccessResponse SuccessfulResponse { get; set; }
        public StandardSuccsessFailurePayFastApiResponse UnsuccessfulResponse { get; set; }

        internal SubscriptionNormalUpdateSuccessFailurePayFastApiResult SetSuccessfulResponse(string ResponseString)
        {

            SuccessfulResponse = JsonConvert.DeserializeObject<SubscriptionNormalUpdateFetchSuccessResponse>(ResponseString);
            if (SuccessfulResponse.HTTPStatus.Equals(PayFastCompleteDefaults.API_CALL_RESPONSE_FAILED))
            {
                Errors.Add($"Response Successfully recieved - ERROR: STATUS: " +
                   $"{SuccessfulResponse.HTTPStatus} of the response : HTTP Response Code " +
                   $"{SuccessfulResponse.HTTPResponseCode}, Error Message: " +
                   $"{JsonConvert.DeserializeObject<StandardSuccsessFailurePayFastApiResponse>(ResponseString)} "); 
            }
            return this;
        }

        internal SubscriptionNormalUpdateSuccessFailurePayFastApiResult SetUnSuccessfulResponse(string ResponseString)
        {
            UnsuccessfulResponse = JsonConvert.DeserializeObject<StandardSuccsessFailurePayFastApiResponse>(ResponseString);
            return this;
        }
    }
}
