﻿using Nop.Plugin.Payments.PayFastComplete.Infrastructure.Common.Results;
using System;
using System.Collections.Generic;
using System.Net.Http;
using System.Text;

namespace Nop.Plugin.Payments.PayFastComplete.Services.PayFastApiClientServices.Models.Api.Results
{
    /// <summary>
    /// Returns List of possible errors generated, else contains the Json serilised HTTPConent for the request body.
    /// </summary>
    public class BuildApiRequestResult: Result
    {
        /// <summary>
        /// Json serilised HTTPConent for the request body
        /// </summary>
        public StringContent RequestBody { get; set; }
    }
}
