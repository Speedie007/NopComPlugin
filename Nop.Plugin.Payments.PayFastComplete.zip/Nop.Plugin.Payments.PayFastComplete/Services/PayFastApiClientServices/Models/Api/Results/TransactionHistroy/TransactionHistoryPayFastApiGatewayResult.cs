﻿using Newtonsoft.Json;
using Nop.Plugin.Payments.PayFastComplete.Extensions;
using Nop.Plugin.Payments.PayFastComplete.Infrastructure.Common.Results;
using Nop.Plugin.Payments.PayFastComplete.Services.PayFastApiClientServices.Models.Api.Responses;
using Nop.Plugin.Payments.PayFastComplete.Services.TransactionHistoryServices.Models;
using System;
using System.Collections.Generic;

namespace Nop.Plugin.Payments.PayFastComplete.Services.PayFastApiClientServices.Models.Api.Results.TransactionHistroy
{
    public class TransactionHistoryPayFastApiGatewayResult : Result
    {

        public TransactionHistoryPayFastApiGatewayResult()
        {
            UnsuccessfulResponse = new StandardSuccsessFailurePayFastApiResponse();
            TransactionHistoryDataSet = new List<PayFastTransactionHistoryDataExtractionRecordModel>();
        }

        /// <summary>
        /// A successful history response will return comma-separated values (CSV) of required the transactions.
        /// This Stores the CSV values in one continues string.
        /// </summary>

        public List<PayFastTransactionHistoryDataExtractionRecordModel> TransactionHistoryDataSet { get; set; }
     
        public StandardSuccsessFailurePayFastApiResponse UnsuccessfulResponse { get; set; }

        internal TransactionHistoryPayFastApiGatewayResult ProcessSuccessfulResponse(string ResponseString)
        {
            try
            {
                TransactionHistoryDataSet.PopulateTransactionalHistoryRecords(ResponseString.ExtractTransactionalHistoryData());
            }
            catch (Exception ex)
            {
                AddError($"Histroical Data successfully returned retrieved from the PayFast Api." +
                    $"Failed to generate the Transactional History Data Set from the returned Meta-Data: " +
                    $" Internal error:{ex.Message}");
            }


            return this;
        }

        internal TransactionHistoryPayFastApiGatewayResult SetUnSuccessfulResponse(string ResponseString)
        {
            //StandardFailurePayFastApiResponse
            UnsuccessfulResponse = JsonConvert.DeserializeObject<StandardSuccsessFailurePayFastApiResponse>(ResponseString);
            return this;
        }
    }
}
