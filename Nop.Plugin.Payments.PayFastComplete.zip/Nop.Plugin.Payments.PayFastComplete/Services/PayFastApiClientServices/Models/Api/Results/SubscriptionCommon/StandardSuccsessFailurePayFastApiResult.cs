﻿using Newtonsoft.Json;
using Nop.Plugin.Payments.PayFastComplete.Infrastructure.Common;
using Nop.Plugin.Payments.PayFastComplete.Infrastructure.Common.Results;
using Nop.Plugin.Payments.PayFastComplete.Services.PayFastApiClientServices.Models.Api.Responses;
using System;


namespace Nop.Plugin.Payments.PayFastComplete.Services.PayFastApiClientServices.Models.Api.Results.SubscriptionCommon
{
    public class StandardSuccsessFailurePayFastApiResult : Result
    {

        public StandardSuccsessFailurePayFastApiResult()
        {
            SuccessfulResponse = new StandardSuccsessFailurePayFastApiResponse();
            UnsuccessfulResponse = new StandardSuccsessFailurePayFastApiResponse();
        }

        public StandardSuccsessFailurePayFastApiResponse SuccessfulResponse { get; set; }
        public object UnsuccessfulResponse { get; set; }

        internal StandardSuccsessFailurePayFastApiResult SetSuccessfulResponse(string ResponseString)
        {

            SuccessfulResponse = JsonConvert.DeserializeObject<StandardSuccsessFailurePayFastApiResponse>(ResponseString);
            if (SuccessfulResponse.HTTPStatus.Equals(PayFastCompleteDefaults.API_CALL_RESPONSE_FAILED) ||
                SuccessfulResponse.HTTPStatus.Equals(PayFastCompleteDefaults.API_CALL_RESPONSE_ERROR))
            {
                Errors.Add($"Response Successfully recieved - ERROR: STATUS: " +
                    $"{SuccessfulResponse.HTTPStatus} of the response : HTTP Response Code " +
                    $"{SuccessfulResponse.HTTPResponseCode}, Error Message: " +
                    $"{JsonConvert.DeserializeObject<StandardSuccsessFailurePayFastApiResponse>(ResponseString)} ");
            }
            return this;
        }

        internal StandardSuccsessFailurePayFastApiResult SetUnSuccessfulResponse(string ResponseString)
        {
            //{"code":401,"status":"failed","data":{"response":"Merchant authorization failed.","message":false}}
            UnsuccessfulResponse = JsonConvert.DeserializeObject(ResponseString);
            return this;
        }
    }
}