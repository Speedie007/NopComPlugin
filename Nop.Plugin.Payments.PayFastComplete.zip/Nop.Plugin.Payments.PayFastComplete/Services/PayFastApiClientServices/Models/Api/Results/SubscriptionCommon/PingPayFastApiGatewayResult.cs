﻿using Newtonsoft.Json;
using Nop.Plugin.Payments.PayFastComplete.Infrastructure.Common.Results;
using Nop.Plugin.Payments.PayFastComplete.Services.PayFastApiClientServices.Models.Api.Responses;

namespace Nop.Plugin.Payments.PayFastComplete.Services.PayFastApiClientServices.Models.Api.Results.SubscriptionCommon
{

    public class PingPayFastApiGatewayResult : Result
    {

        public PingPayFastApiGatewayResult()
        {
           
        }

        public string SuccessfulResponse { get; set; }
        public StandardSuccsessFailurePayFastApiResponse UnsuccessfulResponse { get; set; }

        internal PingPayFastApiGatewayResult SetSuccessfulResponse(string ResponseString)
        {
            SuccessfulResponse = JsonConvert.DeserializeObject<string>(ResponseString);
            return this;
        }

        internal PingPayFastApiGatewayResult SetUnSuccessfulResponse(string ResponseString)
        {
            UnsuccessfulResponse = JsonConvert.DeserializeObject<StandardSuccsessFailurePayFastApiResponse>(ResponseString);
            return this;
        }
    }
}
