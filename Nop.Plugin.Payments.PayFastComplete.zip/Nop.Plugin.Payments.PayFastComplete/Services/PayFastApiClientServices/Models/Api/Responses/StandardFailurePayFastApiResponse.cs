﻿using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Text;


namespace Nop.Plugin.Payments.PayFastComplete.Services.PayFastApiClientServices.Models.Api.Responses
{
    public class StandardSuccsessFailurePayFastApiResponse
    {
        [JsonProperty("code")]
        public string HTTPResponseCode { get; set; }

        [JsonProperty("status")]
        public string HTTPStatus { get; set; }

        [JsonProperty("data")]
        public HttpData HttpErrorData { get; set; }

        public class HttpData
        {
            [JsonProperty("response")]
            public string HttpResponse { get; set; }

            [JsonProperty("message")]
            public string Message { get; set; }
        }
    }
}
