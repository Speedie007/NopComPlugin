﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Text;

namespace Nop.Plugin.Payments.PayFastComplete.Services.PayFastApiClientServices.Models.Api.Responses.SubscriptionAdHoc
{
    public partial class SubscriptionAdHocFetchSuccessResponse
    {
        [JsonProperty("code")]
        public string HTTPResponseCode { get; set; }

        [JsonProperty("status")]
        public string HTTPStatus { get; set; }

        [JsonProperty("data")]
        public HttpData DataReturned { get; set; }

        public class HttpData
        {
            [JsonProperty("response")]
            public ResponseData ApiResponse { get; set; }

            public class ResponseData
            {
                [JsonProperty("token")]
                public string SubscriptionToken { get; set; }

                [JsonProperty("status")]
                public string SubscriptionStatus { get; set; }
            }
        }

       
    }
}
