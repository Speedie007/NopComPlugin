﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Text;
using System.Text.Json.Serialization;
using Ubiety.Dns.Core;

namespace Nop.Plugin.Payments.PayFastComplete.Services.PayFastApiClientServices.Models.Api.Responses.SubscriptionCommon
{
    public class SuccessfulPingResponse
    {
        [JsonProperty("code")]
        public string SuccessMessage { get; set; }
    }
   
}
