﻿using Nop.Core;
using Nop.Core.Infrastructure.Mapper;
using Nop.Data;
using Nop.Plugin.Payments.PayFastComplete.Domain.TransactionalHistory;
using Nop.Plugin.Payments.PayFastComplete.Infrastructure.Common.Results;
using Nop.Plugin.Payments.PayFastComplete.Services.TransactionHistoryServices.Models;
using Nop.Plugin.Payments.PayFastComplete.Services.TransactionHistoryServices.Results;
using Nop.Plugin.Payments.PayFastComplete.Services.IPayFastApiClientServices;
using Nop.Services.Logging;
using Nop.Services.Orders;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Linq.Dynamic.Core;
using Nop.Plugin.Payments.PayFastComplete.Services.PayFastApiClientServices.Models.Api.Results.TransactionHistroy;

namespace Nop.Plugin.Payments.PayFastComplete.Services.TransactionHistoryServices
{
    public interface IPayFastTransactionHistoryService
    {
        #region Local Database Cache  Methods
        CRUDResult<PayFastTransactionHistoryRecord> AddTransactionHistoryRecord_LocalDbCache(PayFastTransactionHistoryRecord record);
        CRUDResult<PayFastTransactionHistoryRecord> AddTransactionHistoryRecords_LocalDbCache(List<PayFastTransactionHistoryRecord> records);

        CRUDResult<PayFastTransactionHistoryRecord> GetPayFastTransactionHistoryRecord_LocalDbCache_BySearchCriteria(TransactionalSearchCritearia SearchCritearia);
        CRUDResult<PayFastTransactionHistoryRecord> GetPayFastTransactionHistoryRecord_LocalDbCache_ById(int ID);
        CRUDResult<PayFastTransactionHistoryRecord> GetPayFastTransactionHistoryRecord_LocalDbCache_ByIDandOrderGuid(int ID, Guid OrderGuid);
        CRUDResult<PayFastTransactionHistoryRecord> GetPayFastTransactionHistoryRecord_LocalDbCache_ByOrderGuid(Guid OrderGuid);

        #endregion

        #region Utility Methods
        List<string> GetTransactionTypesFromTransactionHistoryRecords_LocalDbCache();
        List<string> GetYearsFromTransactionHistoryRecords_LocalDbCache();
        #endregion

        IPagedList<PayFastTransactionHistoryRecord> ListAllPayFastTransactionHistoryRecords(
             DateTime? TransactionDateTimeStamp = null,
            string TransactionWithinSpecifiedYear = null,
            string TransactionWithinSpecifiedMonth = null,
            string TransactionOnSpecifiedDay = null,
            string TransactionType = null,
            string TransactionFundingSource = null,
            int OrderID = 0,
            string MerchantTranactionReference = null,
            string PayFastTranactionReference = null,
            int pageIndex = 0, int pageSize = int.MaxValue, bool getOnlyTotalCount = false);

        #region Archive Transaction Methods
        
        TransactionHistoryResult ArchiveTransactionHistoryByPeriod(string FromDate, string ToDate);
        TransactionHistoryResult ArchiveTransactionHistoryByDay(string Date = null);
        TransactionHistoryResult ArchiveTransactionHistoryByWeek(string Date);
        TransactionHistoryResult ArchiveTransactionHistoryByMonth(string Date);
        //PayFastTransactionHistoryRecordModel GetTodaysPayFastTransactionalHistoryFromApi();

        #endregion
    }
    public class PayFastTransactionHistoryService : IPayFastTransactionHistoryService
    {
        private readonly IPayFastApiClientService _payFastApiClientServices;
        private readonly ILogger _logger;
        private readonly IOrderService _orderService;


        #region Fields
        private readonly IRepository<PayFastTransactionHistoryRecord> _payFastTransactionHistoryRecordRepository;
       
        #endregion

        #region Cstor
        public PayFastTransactionHistoryService(
            IRepository<PayFastTransactionHistoryRecord> payFastTransactionHistoryRecordRepository,
            IPayFastApiClientService   payFastApiClientServices,
             IOrderService orderService,
             ILogger logger
            )
        {
            _payFastApiClientServices = payFastApiClientServices;
            _logger = logger;
            _orderService = orderService;
            _payFastTransactionHistoryRecordRepository = payFastTransactionHistoryRecordRepository;
          
        }

        #endregion

        #region Methods

        #region Transaction History Archining Methods
        public TransactionHistoryResult ArchiveTransactionHistoryByDay(string Date = null)
        {
            TransactionHistoryResult Rtn = new TransactionHistoryResult();
            //IF Api Active.
            var pingResult = _payFastApiClientServices.PingPayFastApiGateway();
            if (pingResult.Success)
            {
                //cause no date is supplied it defaults to todays date.
                TransactionHistoryPayFastApiGatewayResult result = _payFastApiClientServices
                    .GetTransactionHistoryBySelectedDailyPeriod(Date: Date);


                if (result.Success)
                {
                    ArchiveTransactionHistoryRecords(result.TransactionHistoryDataSet, result);

                }
                else
                {
                    Rtn.CombineError(result.Errors);
                    foreach (var item in result.Errors)
                    {
                        _logger.Error($"Error Archiving Daily transaction history records: [{DateTime.Now}], Internal Errors :[{item}]", null, null);
                    }
                }
            }
            else
            { 
                Rtn.CombineError(pingResult.Errors);
            }
            return Rtn;
        }
        
        public TransactionHistoryResult ArchiveTransactionHistoryByPeriod(string FromDate, string ToDate)
        {
            TransactionHistoryResult Rtn = new TransactionHistoryResult();
            //IF Api Active.
            var pingResult = _payFastApiClientServices.PingPayFastApiGateway();
            if (pingResult.Success)
            {
                //cause no date is supplied it defaults to todays date.
                TransactionHistoryPayFastApiGatewayResult result = _payFastApiClientServices
                    .GetTransactionHistoryBySelectedToAndFromPeriod(FromDate: FromDate, ToDate: ToDate);

                if (result.Success)
                {
                    ArchiveTransactionHistoryRecords(result.TransactionHistoryDataSet, result);

                }
                else
                {
                    Rtn.CombineError(result.Errors);
                    foreach (var item in result.Errors)
                    {

                        _logger.Error($"Error Archiving transaction history records From Period Between {FromDate} and {ToDate}: [{DateTime.Now}], Internal Errors :[{item}]", null, null);
                    }
                }
            }
            else
            {
                
                Rtn.CombineError(pingResult.Errors);
            }
            return Rtn;
        }
        public TransactionHistoryResult ArchiveTransactionHistoryByWeek(string Date)
        {
            TransactionHistoryResult Rtn = new TransactionHistoryResult();
            //IF Api Active.
            var pingResult = _payFastApiClientServices.PingPayFastApiGateway();
            if (pingResult.Success)
            {
                //cause no date is supplied it defaults to todays date.
                TransactionHistoryPayFastApiGatewayResult result = _payFastApiClientServices
                    .GetTransactionHistoryBySelectedWeekPeriod(Date: Date);

                if (result.Success)
                {
                    ArchiveTransactionHistoryRecords(result.TransactionHistoryDataSet, result);

                }
                else
                {
                    Rtn.CombineError(result.Errors);
                    foreach (var item in result.Errors)
                    {

                        _logger.Error($"Error Archiving Weekly transaction history records for period {Date}: [{DateTime.Now}], Internal Errors :[{item}]", null, null);
                    }
                }
            }
            else
            {
                Rtn.CombineError(pingResult.Errors);
            }
            return Rtn;
        }

        public TransactionHistoryResult ArchiveTransactionHistoryByMonth(string Date)
        {
            TransactionHistoryResult Rtn = new TransactionHistoryResult();
            //IF Api Active.
            var pingResult = _payFastApiClientServices.PingPayFastApiGateway();
            if (pingResult.Success)
            {
                //cause no date is supplied it defaults to todays date.
                TransactionHistoryPayFastApiGatewayResult result = _payFastApiClientServices
                    .GetTransactionHistoryBySelectedMonthPeriod(Date: Date);

                if (result.Success)
                {
                    ArchiveTransactionHistoryRecords(result.TransactionHistoryDataSet, result);

                }
                else
                {
                    Rtn.CombineError(result.Errors);
                    foreach (var item in result.Errors)
                    {

                        _logger.Error($"Error Archiving the selected Months transaction history records Period : {Date}: [{DateTime.Now}], Internal Errors :[{item}]", null, null);
                    }
                }
            }
            else
            {
                Rtn.CombineError(pingResult.Errors);
            }
            return Rtn;
        }
        #endregion

        #region Insert Methods
        public CRUDResult<PayFastTransactionHistoryRecord> AddTransactionHistoryRecord_LocalDbCache(PayFastTransactionHistoryRecord record)
        {
            CRUDResult<PayFastTransactionHistoryRecord> result = new CRUDResult<PayFastTransactionHistoryRecord>();
            try
            {
                _payFastTransactionHistoryRecordRepository.Insert(record);
            }
            catch (Exception ex)
            {
                result.AddError($"Error adding transaction history record. Internal Error Message: [{ex.Message}]");
            }

            return result;
        }

        public CRUDResult<PayFastTransactionHistoryRecord> AddTransactionHistoryRecords_LocalDbCache(List<PayFastTransactionHistoryRecord> records)
        {
            CRUDResult<PayFastTransactionHistoryRecord> result = new CRUDResult<PayFastTransactionHistoryRecord>();
            try
            {
                _payFastTransactionHistoryRecordRepository.Insert(records);
            }
            catch (Exception ex)
            {
                result.AddError($"Error adding transaction history records. Internal Error Message: [{ex.Message}]");
            }

            return result;
        }

      


        public CRUDResult<PayFastTransactionHistoryRecord> GetPayFastTransactionHistoryRecord_LocalDbCache_BySearchCriteria(TransactionalSearchCritearia SearchCritearia)
        {
            CRUDResult<PayFastTransactionHistoryRecord> result = new CRUDResult<PayFastTransactionHistoryRecord>();
            try
            {
                var query = _payFastTransactionHistoryRecordRepository.Table;

                query = query.Where(x => x.PayFastTranactionReference == SearchCritearia.PayFastTranactionReference);
                query = query.Where(x => x.MerchantTranactionReference == SearchCritearia.MerchantTranactionReference.ToUpper());
                query = query.Where(x => x.TransactionType == SearchCritearia.TransactionType);
                query = query.Where(x => x.TransactionDateTimeStamp == SearchCritearia.TransactionDateTimeStamp);

                result.ProccesedCRUDEntity = query.FirstOrDefault();
            }
            catch (Exception ex)
            {
                result.AddError($"Error adding transaction history record. Internal Error Message: [{ex.Message}]");
            }

            return result;
        }
        #endregion

        #region Read Methods
        public CRUDResult<PayFastTransactionHistoryRecord> GetPayFastTransactionHistoryRecord_LocalDbCache_ById(int ID)
        {
            CRUDResult<PayFastTransactionHistoryRecord> result = new CRUDResult<PayFastTransactionHistoryRecord>();
            try
            {
                result.ProccesedCRUDEntity = _payFastTransactionHistoryRecordRepository.Table.Where(x => x.Id == ID).FirstOrDefault();
            }
            catch (Exception ex)
            {
                result.AddError($"Error adding transaction history record. Internal Error Message: [{ex.Message}]");
            }

            return result;
        }

        public CRUDResult<PayFastTransactionHistoryRecord> GetPayFastTransactionHistoryRecord_LocalDbCache_ByIDandOrderGuid(int ID, Guid OrderGuid)
        {
            CRUDResult<PayFastTransactionHistoryRecord> result = new CRUDResult<PayFastTransactionHistoryRecord>();
            try
            {
                result.ProccesedCRUDEntity = _payFastTransactionHistoryRecordRepository.Table
                    .Where(x => x.Id == ID && x.MerchantTranactionReference == OrderGuid.ToString().ToUpper())
                    .FirstOrDefault();
            }
            catch (Exception ex)
            {
                result.AddError($"Error adding transaction history record. Internal Error Message: [{ex.Message}]");
            }

            return result;
        }


        /// <summary>
        /// 
        /// </summary>
        /// <param name="TransactionDateTimeStamp"></param>
        /// <param name="TransactionType"></param>
        /// <param name="TransactionMethod"></param>
        /// <param name="TransactionFundingSource"></param>
        /// <param name="OrderNumber"></param>
        /// <param name="MerchantTranactionReference"></param>
        /// <param name="PayFastTranactionReference"></param>
        /// <param name="pageIndex">Page index</param>
        /// <param name="pageSize">Page size</param>
        /// <param name="getOnlyTotalCount">A value in indicating whether you want to load only total number of records. Set to "true" if you don't want to load data from database</param>
        /// <returns></returns>
        public virtual IPagedList<PayFastTransactionHistoryRecord> ListAllPayFastTransactionHistoryRecords(
            DateTime? TransactionDateTimeStamp = null,
            string TransactionWithinSpecifiedYear = null,
            string TransactionWithinSpecifiedMonth = null,
            string TransactionOnSpecifiedDay = null,
            string TransactionType = null,
            string TransactionFundingSource = null,
            int OrderID = 0,
            string MerchantTranactionReference = null,
            string PayFastTranactionReference = null,
            int pageIndex = 0, int pageSize = int.MaxValue, bool getOnlyTotalCount = false)
        {

            var query = _payFastTransactionHistoryRecordRepository.Table;

            if (TransactionDateTimeStamp.HasValue)
                query = query.Where(c => TransactionDateTimeStamp.Value <= c.TransactionDateTimeStamp);

            if (!string.IsNullOrWhiteSpace(TransactionType) && !TransactionType.Equals("0"))
                query = query.Where(c => c.TransactionType.Contains(TransactionType));

            if (!string.IsNullOrWhiteSpace(TransactionWithinSpecifiedYear) && !TransactionWithinSpecifiedYear.Equals("0"))
                query = query.Where(c => c.TransactionDateTimeStamp.Year.ToString().Contains(TransactionWithinSpecifiedYear));

            if (!string.IsNullOrWhiteSpace(TransactionWithinSpecifiedMonth) && !TransactionWithinSpecifiedMonth.Equals("0"))
                query = query.Where(c => c.TransactionDateTimeStamp.Month.ToString().Contains(TransactionWithinSpecifiedMonth));

            if (!string.IsNullOrWhiteSpace(TransactionOnSpecifiedDay) && !TransactionOnSpecifiedDay.Equals("0"))
                query = query.Where(c => c.TransactionDateTimeStamp.Day.ToString().Contains(TransactionOnSpecifiedDay));

            if (!string.IsNullOrWhiteSpace(TransactionFundingSource))
                query = query.Where(c => c.TransactionFundingSource.Contains(TransactionFundingSource));


            if (!string.IsNullOrWhiteSpace(MerchantTranactionReference))
                query = query.Where(x => x.MerchantTranactionReference.ToUpper().Equals(MerchantTranactionReference.ToString().ToUpper()));

            if (!string.IsNullOrWhiteSpace(PayFastTranactionReference))
                query = query.Where(x => x.PayFastTranactionReference.Contains(PayFastTranactionReference));

            if (OrderID > 0)
            {
                Guid OrderGuid = _orderService.GetOrderById(OrderID).OrderGuid;

                query = query.Where(x => x.MerchantTranactionReference.ToUpper().Equals(OrderGuid.ToString().ToUpper()));

            }

            var TransactionHistoryRecords = new PagedList<PayFastTransactionHistoryRecord>(query, pageIndex, pageSize, getOnlyTotalCount);

            return TransactionHistoryRecords;

        }

        public CRUDResult<PayFastTransactionHistoryRecord> GetPayFastTransactionHistoryRecord_LocalDbCache_ByOrderGuid(Guid OrderGuid)
        {
            CRUDResult<PayFastTransactionHistoryRecord> result = new CRUDResult<PayFastTransactionHistoryRecord>();
            try
            {
                result.ProccesedCRUDEntity = _payFastTransactionHistoryRecordRepository.Table
                    .Where(x => x.MerchantTranactionReference == OrderGuid.ToString().ToUpper())
                    .FirstOrDefault();
            }
            catch (Exception ex)
            {
                result.AddError($"Error adding transaction history record. Internal Error Message: [{ex.Message}]");
            }

            return result;
        }


        #endregion

        #region Api Calls

        #endregion

        #region Utility Methods
        private void ArchiveTransactionHistoryRecords(
           List<PayFastTransactionHistoryDataExtractionRecordModel> ArchiveSet,
           TransactionHistoryPayFastApiGatewayResult result)
        {
            foreach (PayFastTransactionHistoryDataExtractionRecordModel ExtractedItem in ArchiveSet)
            {
                //Check if this record has already been inserted with the critera from the extracted record. 
                CRUDResult<PayFastTransactionHistoryRecord> PFTHR_Result = GetPayFastTransactionHistoryRecord_LocalDbCache_BySearchCriteria(
                    AutoMapperConfiguration.Mapper.Map<TransactionalSearchCritearia>(ExtractedItem));
                //If no record found and the test was successful in sert the record.
                if (PFTHR_Result.ProccesedCRUDEntity is null && PFTHR_Result.Success)
                {
                    AddTransactionHistoryRecord_LocalDbCache(AutoMapperConfiguration.Mapper.Map<PayFastTransactionHistoryRecord>(ExtractedItem));
                }
                else
                {
                    foreach (var GetRecordError in result.Errors)
                    {
                        _logger.Error($"Encounter error getting record form the database to check if the record exists: [{DateTime.Now}], Internal Errors :[{GetRecordError}]", null, null);
                    }
                }
            }
        }
        public List<string> GetYearsFromTransactionHistoryRecords_LocalDbCache()
        {
            List<string> result = new List<string>();

            result = (from Years in _payFastTransactionHistoryRecordRepository.Table
                      select Years.TransactionDateTimeStamp.Year.ToString()).Distinct<string>().ToList<string>();
            if (result.Count == 0)
            {
                result.Add(DateTime.Now.Year.ToString());
            }

            return result;
        }
        public List<string> GetTransactionTypesFromTransactionHistoryRecords_LocalDbCache()
        {
            List<string> result = new List<string>();

            result = (from TranactionTypes in _payFastTransactionHistoryRecordRepository.Table
                      select TranactionTypes.TransactionType).Distinct().ToList();
            if (result.Count == 0)
            {
                result.Add("None Avaialble!");
            }

            return result;
        }



        #endregion
        #endregion
    }
}
