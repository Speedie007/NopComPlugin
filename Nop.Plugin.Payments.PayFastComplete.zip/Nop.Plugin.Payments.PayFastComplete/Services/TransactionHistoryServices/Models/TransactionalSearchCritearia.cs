﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Nop.Plugin.Payments.PayFastComplete.Services.TransactionHistoryServices.Models
{
    public partial class TransactionalSearchCritearia
    {
        public DateTime TransactionDateTimeStamp { get; set; }
        public string TransactionType { get; set; }
        public string MerchantTranactionReference { get; set; }
        public string PayFastTranactionReference { get; set; }
    }
}
