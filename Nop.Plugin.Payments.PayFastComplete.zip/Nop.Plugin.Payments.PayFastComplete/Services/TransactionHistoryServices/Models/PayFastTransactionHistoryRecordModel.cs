﻿using Nop.Web.Framework.Models;
using System;
using System.Collections.Generic;
using System.Reflection.Metadata.Ecma335;
using System.Text;

namespace Nop.Plugin.Payments.PayFastComplete.Services.TransactionHistoryServices.Models
{
    public class PayFastTransactionHistoryDataExtractionRecordModel : BaseNopModel
    {
        public DateTime TransactionDateTimeStamp { get; set; }//Date -0 
        public string TransactionType { get; set; }//Type - 1
        public string TransactionMethod { get; set; }//Sign - 2
        public string TransactionUserReference { get; set; }//Party - 3
        public string TransactionName { get; set; }//Name - 4
        public string TransactionDescription { get; set; }//Description - 5
        public string TransactionCurrency { get; set; }//Currency - 6
        public string TransactionFundingSource { get; set; }//Funding Type - 7
        public decimal TransactionGrossAmount { get; set; }//Gross - 8
        public decimal TransactionFee { get; set; }//Fee - 9
        public decimal TransactionNetAmount { get; set; }//Net - 10
        public decimal TranactionAccountBalance { get; set; }//Balance - 11
        public string MerchantTranactionReference { get; set; }//M Payment ID -12
        public string PayFastTranactionReference { get; set; }//PF Payment ID -13

        public string CustomStringProperty1 { get; set; }// - 14
        public int CustomIntegerProperty1 { get; set; } // -15
        public string CustomStringProperty2 { get; set; }// - 16
        public int CustomIntegerProperty2 { get; set; } //1- 17
        public string CustomStringProperty3 { get; set; } //-18
        public string CustomStringProperty4 { get; set; }//-19
        public string CustomStringProperty5 { get; set; }//-20
        public int CustomIntegerProperty3 { get; set; }//-21
        public int CustomIntegerProperty4 { get; set; }//-22
        public int CustomIntegerProperty5 { get; set; }//-23

    }
}

/*
Date - 2020-08-15 14:31:46,
Type - FUNDS_RECEIVED,
Sign - CREDIT,
Party - Test User 01,
Name - Order #3044,
Description - none,
Currency -ZAR,
"Funding Type" - WALLET,
Gross - 400.00,
Fee,
Net,
Balance,
"M Payment ID",
"PF Payment ID",
"custom str1",
"custom int1",
"custom str2",
"custom int2",
"custom str3",
"custom str4",
"custom str5",
"custom int3",
"custom int4",
"custom int5"
*/