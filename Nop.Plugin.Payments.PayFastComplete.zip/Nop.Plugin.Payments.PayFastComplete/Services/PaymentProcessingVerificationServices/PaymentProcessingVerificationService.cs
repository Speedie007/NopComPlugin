﻿using LinqToDB.Common;
using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.Primitives;
using Nop.Core;
using Nop.Plugin.Payments.PayFastComplete.Extensions;
using Nop.Plugin.Payments.PayFastComplete.Infrastructure.Common;
using Nop.Plugin.Payments.PayFastComplete.Services.PaymentProcessingVerificationServices.Results;
using Nop.Plugin.Payments.PayFastComplete.Settings;
using Nop.Plugin.Payments.PayFastComplete.WebHooks.Models;
using Nop.Services.Logging;
using Nop.Services.Orders;
using OfficeOpenXml.FormulaParsing.Utilities;
using System;
using System.Collections.Generic;
using System.Collections.Specialized;
using System.Linq;
using System.Net;
using System.Text;

namespace Nop.Plugin.Payments.PayFastComplete.Services.PaymentProcessingVerificationServices
{
    public partial interface IPaymentProcessingVerificationService
    {
        void ConductSecurityCheckOne_VerifySignature(PaymentProcessVerificationResult result, IFormCollection form);
        void ConductSecurityCheckTwo_VerifyComminicationWithPayFastEngine(PaymentProcessVerificationResult result);
        void ConductSecurityCheckThree_VerifyProcessedAmountFromPayFast(PaymentProcessVerificationResult result, IpnModel model);
        void ConductSecurityCheckFour_ValidateDataRecievedFromPayFast(PaymentProcessVerificationResult result, IpnModel model);
    }
    public partial class PaymentProcessingVerificationService : IPaymentProcessingVerificationService
    {


        #region Fields
        private readonly PayFastCompleteSettings _payFastCompleteSettings;
        private readonly IOrderService _orderService;
        private readonly ILogger _logger;
        private readonly IWebHelper _webHelper;
        #endregion

        #region Cstor
        public PaymentProcessingVerificationService(
            PayFastCompleteSettings payFastCompleteSettings,
            IWebHelper webHelper,
            ILogger logger,
            IOrderService orderService)
        {
            _orderService = orderService;
            _logger = logger;
            _webHelper = webHelper;
            _payFastCompleteSettings = payFastCompleteSettings;
        }

        #endregion

        #region Security Checks
        /// <summary>
        /// Verify the security signature in the data retruned./n
        /// This is done in a similar way that the signature that you generated for stage one of the user payment flow./n
        /// It is to ensure that there hasn’t been any middle man attacks and changing of values within the received data./n
        /// The string that gets created needs to include all fields posted from PayFast./n
        /// IF A PASSPHRASE MUST HAVE BEEN SET IN THE PAYFAST SETTINGS, THEN IT NEEDS TO BE INCLUDED IN THE SIGNATURE STRING.
        /// </summary>
        /// <param name="form">
        /// Fields supplied by the PayFsat System after the payment was completed by the Customer
        /// </param>
        /// <returns>
        /// Verification result contianing ant errors that may have been encountered.'/n
        /// If Successfully contains cache of the fields that must be posted for verification in Stage Four.
        /// </returns>
        public void ConductSecurityCheckOne_VerifySignature(PaymentProcessVerificationResult result, IFormCollection form)
        {

            string SignatureToEncode = "";
            string PayFastSignature = "";
            foreach (KeyValuePair<string, StringValues> pair in form)
            {
                if (SignatureToEncode.Length > 0)
                {
                    SignatureToEncode += "&";
                }

                if (!pair.Key.ToString().TrimEnd().TrimStart().Equals(PayFastCompleteDefaults.SignatureFormFieldKey, StringComparison.InvariantCultureIgnoreCase))
                {
                    //Generates the encoded string to chek the signature.
                    SignatureToEncode += $"{pair.Key}={pair.Value.ToString().UrlEncodeString()}";
                    //Adds the fields to be submited and verified in a later step.
                    result.postData.Add(pair.Key, pair.Value);
                }
                else
                {
                    //Gets the Signature that was supplied from PayFst After the Payment was Processed.
                    PayFastSignature = pair.Value.FirstOrDefault();
                }
            }
            //Adds the PassPhrase to "Salt" the Encode String Paramters.
            if (!(_payFastCompleteSettings.APIPassPhrase.IsNullOrEmpty()))
            {
                SignatureToEncode += $"{PayFastCompleteDefaults.SecurityPassPhraseKey}={_payFastCompleteSettings.APIPassPhrase.UrlEncodeString()}";
            }
            else
            {
                //Signature Failed
                result.AddError("Pass Phrase has not been set!");
            }


            if (!SignatureToEncode.GetMD5Hash().Equals(PayFastSignature))
            {
                result.AddError($"Failed to Verify the Signature that was provided by the payfast System. PayFast Hash:{PayFastSignature} - Verification Hash Generated:{SignatureToEncode.GetMD5Hash()}");
            }
        }

        /// <summary>
        /// With this test you will be checking to ensure that your application is communicating with a valid PayFast payment engine./n
        /// The following is a list of valid domains:/n
        /// www.payfast.co.za/n
        /// or/n
        /// w1w.payfast.co.za/n
        /// or/n
        /// w2w.payfast.co.za/n
        /// or/n
        /// sandbox.payfast.co.za
        /// </summary>
        /// <returns></returns>
        public void ConductSecurityCheckTwo_VerifyComminicationWithPayFastEngine(PaymentProcessVerificationResult result)
        {
            //Get the IP Address Of the current incomming connection.
            if (!IPAddress.TryParse(_webHelper.GetCurrentIpAddress(), out IPAddress ipAddress))
            {
                result.AddError("PayFast ITN error: IP address is empty");
            }
            //Gets List of IP Address Used by PayFast.
            IEnumerable<IPAddress> validIPs = new string[4]
            {
                "www.payfast.co.za",
                "sandbox.payfast.co.za",
                "w1w.payfast.co.za",
                "w2w.payfast.co.za"
            }.SelectMany(Dns.GetHostAddresses);

            /*Verifies the IP Address obtained from the current connection with the 
            * Valid Payfast Defined IP Addresses.
            *************************************************************************/
            if (!validIPs.Contains(ipAddress))
            {
                result.AddError($"PayFast ITN error: IP address {ipAddress} is not valid PayFast IP Address.");
            }
        }

        /// <summary>
        /// Check payment data against the merchant’s order./n 
        /// This can be determined by comparing the amount processed for payment and the amount of the cart,/n
        /// in your application and seeing if they match.
        /// </summary>
        /// <param name="result">Current Result Status generated for the current Verification Step.</param>
        /// <param name="model">Different Fields retruned from the PayFast System</param>
        public void ConductSecurityCheckThree_VerifyProcessedAmountFromPayFast(PaymentProcessVerificationResult result, IpnModel model)
        {

            if (!Guid.TryParse(model.MerchantPaymentID, out Guid orderGuid))
            {
                result.AddError("Unable to obtain the Merchant Panyment ID from the values returned from Payfast during the verification process.");
            }

            result.CurrentOrderBeingProcessed = _orderService.GetOrderByGuid(orderGuid);
            if (result.CurrentOrderBeingProcessed != null)
            {
                //Only Comlete this check if the validating a new order. else will fail when Canceled subscriptions pass through. 
                if (model.PaymentStatus.Equals(PayFastCompleteDefaults.OrderProcessing_COMPLETE))
                    if (model.TotalPaidByTheBuyer != null)
                    {
                        var TotalToCompare = model.TotalPaidByTheBuyer.IsNumeric() ? Convert.ToDouble(model.TotalPaidByTheBuyer) : 0;


                        if (Convert.ToDouble(string.Format("{0:0.00}", result.CurrentOrderBeingProcessed.OrderTotal)) != Convert.ToDouble(string.Format("{0:0.00}", model.TotalPaidByTheBuyer.Replace(".", ","))))
                        {
                            //Means that its not a payment miss match its an recuring Ad Hoc Payment with a difffernt payment ammount.
                            //Only Miss match if the order hasnt been paid yet.
                            if (!(result.CurrentOrderBeingProcessed.PaymentStatus == Core.Domain.Payments.PaymentStatus.Paid))
                            {
                                result.AddError($"PayFast ITN error: Value miss match between the PayFast Payment Verification Value and the current Customers Order. Order Total From the System is : {result.CurrentOrderBeingProcessed.OrderTotal}, Total provided by the PayFast System: {model.TotalPaidByTheBuyer}");
                            }

                        }
                    }
                    else
                    {
                        result.AddError("PayFast ITN error: Order Total not returned from thePayfast System. Unbale to Validate!");
                    }
            }
            else
            {
                result.AddError($"PayFast ITN error: Order with guid {orderGuid} is not found");
            }

        }

        /// <summary>
        /// Validate the data that you have received from PayFast by contacting our server and confirming the order details.
        /// </summary>
        /// <param name="result">Current Result Status generated for the current Verification Step.</param>
        /// <param name="model">Different Fields retruned from the PayFast System</param>
        public void ConductSecurityCheckFour_ValidateDataRecievedFromPayFast(PaymentProcessVerificationResult result, IpnModel model)
        {
            try
            {
                //Only Comlete this check if the validating a new order. else will fail when Canceled subscriptions pass through. 
                if (model.PaymentStatus.Equals(PayFastCompleteDefaults.OrderProcessing_COMPLETE))
                {
                    
                    string site = (_payFastCompleteSettings.UseSandbox ? $"https://{PayFastCompleteDefaults.FormSubnissionTestingUri}" : $"https://{PayFastCompleteDefaults.FormSubmissionBaseUri}") + "/eng/query/validate";
                    WebClient webClient = new WebClient();

                    try
                    {
                        byte[] response = webClient.UploadValues(site, result.postData);
                        string VerificationResult = Encoding.ASCII.GetString(response);
                        if (!VerificationResult.StartsWith("VALID", StringComparison.InvariantCulture))
                        {
                            result.AddError("PayFast ITN error: Data sent to PayFast For verification has returned as INVALID.");
                        }
                    }
                    finally
                    {
                        ((IDisposable)webClient)?.Dispose();
                    }
                }
            }
            catch (WebException ex)
            {
                result.AddError($"PayFast ITN error: Possible connection Error with PayFast while attempting to validiate the payment datails. Internal Error {ex.Message}");
            }

        
        }
        #endregion
    }
}
