﻿using Nop.Core.Domain.Orders;
using Nop.Plugin.Payments.PayFastComplete.Infrastructure.Common.Results;
using System;
using System.Collections.Generic;
using System.Collections.Specialized;
using System.Text;

namespace Nop.Plugin.Payments.PayFastComplete.Services.PaymentProcessingVerificationServices.Results
{
    public partial class PaymentProcessVerificationResult : Result
    {
       #region Cstor
        public PaymentProcessVerificationResult()
        {
             postData = new NameValueCollection();
        }
        #endregion

        #region properties
        public NameValueCollection postData { get; set; }
        public Order CurrentOrderBeingProcessed { get; set; }
        #endregion
    }
}
