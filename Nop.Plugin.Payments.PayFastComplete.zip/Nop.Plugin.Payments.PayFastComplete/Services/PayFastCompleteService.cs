﻿using Nop.Core;
using Nop.Core.Domain.Orders;
using Nop.Core.Infrastructure.Mapper;
using Nop.Plugin.Payments.PayFastComplete.Areas.Admin.Models.Configuration;
using Nop.Plugin.Payments.PayFastComplete.Factories;
using Nop.Plugin.Payments.PayFastComplete.Infrastructure.Common.Results;
using Nop.Plugin.Payments.PayFastComplete.Services.HttpClientServices.Models.FromProcessing;
using Nop.Plugin.Payments.PayFastComplete.Services.PaymentProcessingServices.Models.FromProcessing.Requests;
using Nop.Plugin.Payments.PayFastComplete.Settings;
using Nop.Services.Configuration;
using Nop.Services.Messages;
using System;
using System.Collections.Generic;
using System.Text;
using System.util.collections;

namespace Nop.Plugin.Payments.PayFastComplete.Services
{
    public interface IPayFastCompleteService
    {
        SettingsResult UpdateConfigurationSettings(ConfigurationViewModel model);

        //void ProcessOrderPayment(Order order);

        bool IsTestModeSet();
    }

    public class PayFastCompleteService : IPayFastCompleteService
    {
        private readonly IMessageTemplateService _messageTemplateService;
        private readonly IPayFastFormPaymentProcessorService _payFastFormPaymentProcessorService;
        private readonly IPayFastPaymentConfigurationFactory _payFastPaymentConfigurationFactory;
        private readonly ISettingService _settingService;
        private readonly IStoreContext _storeContext;
        private readonly PayFastCompleteSettings _payFastCompleteSettings;

        public PayFastCompleteService(
            PayFastCompleteSettings payFastCompleteSettings,
            IStoreContext storeContext,
            ISettingService settingService,
            IPayFastPaymentConfigurationFactory payFastPaymentConfigurationFactory,
            IPayFastFormPaymentProcessorService payFastFormPaymentProcessorService,
            IMessageTemplateService messageTemplateService
            )
        {
            _messageTemplateService = messageTemplateService;
            _payFastFormPaymentProcessorService = payFastFormPaymentProcessorService;
            _payFastPaymentConfigurationFactory = payFastPaymentConfigurationFactory;
            _settingService = settingService;
            _storeContext = storeContext;
            _payFastCompleteSettings = payFastCompleteSettings;
        }

        public bool IsTestModeSet()
        {
            return _payFastCompleteSettings.UseSandbox ? true : false;
        }

     

        public SettingsResult UpdateConfigurationSettings(ConfigurationViewModel model)
        {
            SettingsResult Rtn = new SettingsResult();

            try
            {
                Rtn.SettingsProcessed = (PayFastCompleteSettings)AutoMapperConfiguration.Mapper.Map(model, _payFastCompleteSettings, typeof(ConfigurationViewModel), typeof(PayFastCompleteSettings));
                _settingService.ClearCache();
                _settingService.SaveSetting<PayFastCompleteSettings>(Rtn.SettingsProcessed, _storeContext.CurrentStore.Id);

            }
            catch (Exception ex)
            {

                Rtn.AddError($"Error Updating Configuration Settings : Error Message: {ex.Message}");
            }
            return Rtn;
        }
    }
}
