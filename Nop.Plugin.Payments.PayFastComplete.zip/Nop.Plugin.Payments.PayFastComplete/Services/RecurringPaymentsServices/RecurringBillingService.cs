﻿using Nop.Data;
using Nop.Plugin.Payments.PayFastComplete.Domain.RecurringBilling;
using Nop.Plugin.Payments.PayFastComplete.Infrastructure.Common.Results;
using System;
using System.Collections.Generic;
using System.Text;

namespace Nop.Plugin.Payments.PayFastComplete.Services.RecurringPaymentsServices
{
    public partial interface IRecurringBillingService
    {
        CRUDResult<RecurringBillingFailedLog> LogFailedRecurringBillingCharge(RecurringBillingFailedLog logEntry);
        CRUDResult<RecurringBillingFailedLog> UpdateFailedRecurringBillingEntry(RecurringBillingFailedLog logEntry);

        CRUDResult<RecurringBillingFailedLogNotes> AddFailedRecurringBillingEnteryNote(RecurringBillingFailedLogNotes EntryNote);
    }
    public partial class RecurringBillingService : IRecurringBillingService
    {


        #region Fields
        private readonly IRepository<RecurringBillingFailedLog> _recurringBillingFailedLogRepository;
        private readonly IRepository<RecurringBillingFailedLogNotes> _recurringBillingFailedLogNotesRepository;
        #endregion

        #region ctor
        public RecurringBillingService(
            IRepository<RecurringBillingFailedLog> recurringBillingFailedLogRepository,
            IRepository<RecurringBillingFailedLogNotes> recurringBillingFailedLogNotesRepository
            )
        {
            _recurringBillingFailedLogNotesRepository = recurringBillingFailedLogNotesRepository;
            _recurringBillingFailedLogRepository = recurringBillingFailedLogRepository;
        }

        public CRUDResult<RecurringBillingFailedLogNotes> AddFailedRecurringBillingEnteryNote(RecurringBillingFailedLogNotes EntryNote)
        {
            CRUDResult<RecurringBillingFailedLogNotes> result = new CRUDResult<RecurringBillingFailedLogNotes>();
            try
            {
                _recurringBillingFailedLogNotesRepository.Insert(EntryNote);
                result.ProccesedCRUDEntity = EntryNote;
            }
            catch (Exception ex)
            {
                result.AddError($"Error Encountered while adding Note to Log Entry for Log - {EntryNote.RecurringBillingFailedLogID} Inertanl Error: {ex.Message}");
            }
            return result;
        }


        public CRUDResult<RecurringBillingFailedLog> LogFailedRecurringBillingCharge(RecurringBillingFailedLog logEntry)
        {
            CRUDResult<RecurringBillingFailedLog> result = new CRUDResult<RecurringBillingFailedLog>();
            try
            {

                _recurringBillingFailedLogRepository.Insert(logEntry);
                result.ProccesedCRUDEntity = logEntry;
            }
            catch (Exception ex)
            {
                result.AddError($"Error Encountered while adding failed Recurring Billing charge For order - {logEntry.IntialOrderID} Inertanl Error: {ex.Message}");
            }
            return result;
        }

        public CRUDResult<RecurringBillingFailedLog> UpdateFailedRecurringBillingEntry(RecurringBillingFailedLog logEntry)
        {
            CRUDResult<RecurringBillingFailedLog> result = new CRUDResult<RecurringBillingFailedLog>();
            try
            {

                _recurringBillingFailedLogRepository.Update(logEntry);
                result.ProccesedCRUDEntity = logEntry;
            }
            catch (Exception ex)
            {
                result.AddError($"Error Encountered while updating failed Recurring Billing charge For order - {logEntry.IntialOrderID} - Log Entry : {logEntry.Id} Inertanl Error: {ex.Message}");
            }
            return result;
        }
        #endregion

        #region Methods

        #endregion
    }
}
