﻿using System;
using LinqToDB.Common;
using Newtonsoft.Json;
using Nop.Core.Domain.Orders;
using Nop.Plugin.Payments.PayFastComplete.Domain.RecurringBilling;
using Nop.Plugin.Payments.PayFastComplete.Extensions;
using Nop.Plugin.Payments.PayFastComplete.Factories;
using Nop.Plugin.Payments.PayFastComplete.Infrastructure.Common;
using Nop.Plugin.Payments.PayFastComplete.Services.IPayFastApiClientServices;
using Nop.Plugin.Payments.PayFastComplete.Services.PayFastApiClientServices.Models.Api.Results.SubscriptionCommon;
using Nop.Plugin.Payments.PayFastComplete.Services.PaymentProcessingServices.Models.FromProcessing.Components;
using Nop.Services.Customers;
using Nop.Services.Logging;

namespace Nop.Plugin.Payments.PayFastComplete.Services.RecurringPaymentsServices
{
    public partial interface IRecurringPaymentTaskService
    {
        void ProcessRecurringPayment(Order Standingorder);

    }
    public partial class RecurringPaymentTaskService : IRecurringPaymentTaskService
    {

        #region Fields
        private readonly IPayFastApiClientService _payFastApiClientService;
        private readonly ILogger _logger;
        private readonly IPayFastPaymentConfigurationFactory _payFastPaymentConfigurationFactory;
        private readonly IRecurringBillingService _recurringBillingService;
        private readonly ICustomerService _customerService;

        #endregion

        #region Ctor
        public RecurringPaymentTaskService(
            ILogger logger,
            IPayFastApiClientService payFastApiClientService,
             ICustomerService customerService,
             IRecurringBillingService recurringBillingService,
             IPayFastPaymentConfigurationFactory payFastPaymentConfigurationFactory)
        {
            _logger = logger;
            _payFastPaymentConfigurationFactory = payFastPaymentConfigurationFactory;
            _recurringBillingService = recurringBillingService;
            _customerService = customerService;
            _payFastApiClientService = payFastApiClientService;
        }


        #endregion

        #region Methods
        public void ProcessRecurringPayment(Order Standingorder)
        {
            _logger.InsertLog(Core.Domain.Logging.LogLevel.Debug, $"Recurring Billing - Started. {DateTime.Now}", "Started");


            PayFastFormProcessingSplitPaymentDetailModel SplitPaymentDetails = _payFastPaymentConfigurationFactory.PrepareSplitPaymentDetails(Standingorder);


            var t = SplitPaymentDetails.splitPaymentObject is null ? "NOT SET" : "IS SET";
          _logger.InsertLog(Core.Domain.Logging.LogLevel.Debug, $"Recurring Billing Split Payment - Value {t}", t);

            var sOrderName = Standingorder.CustomOrderNumber is string ? Standingorder.CustomOrderNumber : Standingorder.Id.ToString();

            _logger.InsertLog(Core.Domain.Logging.LogLevel.Debug, "Recurring Billing - Starting API Request", "Starting API Request");
            _logger.InsertLog(Core.Domain.Logging.LogLevel.Debug, "Recurring Billing - split payment value", SplitPaymentDetails.splitPaymentObject is SplitPaymentObject ? JsonConvert.SerializeObject(SplitPaymentDetails.splitPaymentObject.SplitPaymentItems) : null);
            _logger.InsertLog(Core.Domain.Logging.LogLevel.Debug, "Recurring Billing - Token Value", Standingorder.SubscriptionTransactionId);

            StandardSuccsessFailurePayFastApiResult result = _payFastApiClientService.ChargeAdHocRecurringPayment(
                AmountToCharge: Convert.ToInt32(Standingorder.OrderTotal * 100).ToString(),
                OrderNumber: Standingorder.OrderGuid.ToString(),
                SubscriptionRemoteToken: Standingorder.SubscriptionTransactionId,
                OrderNameOrShortDescription: $"Order Number #{sOrderName} Date:[{DateTime.Now.GenerateTransactionalTimeStamp()}]",
                OrderDescriptionOrFullDescription: $"Order is for customer :[{Standingorder.CustomerId}] : Email Address {_customerService.GetCustomerById(Standingorder.CustomerId).Email} - Date and Time Placed : [{DateTime.UtcNow}]",
                Must_ITN_BeSent: "1",
                SplitPayment: SplitPaymentDetails.splitPaymentObject is SplitPaymentObject ? JsonConvert.SerializeObject(SplitPaymentDetails.splitPaymentObject.SplitPaymentItems) : null);

            _logger.InsertLog(Core.Domain.Logging.LogLevel.Debug, "Recurring Billing - Finished requested API Request", "Finished requested API Request");
            _logger.InsertLog(Core.Domain.Logging.LogLevel.Debug, "Recurring Billing - Finished requested API Request Result", $"REquest Result : {result.SuccessfulResponse.HTTPStatus}");

            if (!result.Success)
            {
                 _logger.InsertLog(Core.Domain.Logging.LogLevel.Debug, "Recurring Billing - strated interting failed log", $"Error processing payment - Started the ");
                foreach (var item in result.Errors)
                {
                    _logger.InsertLog(Core.Domain.Logging.LogLevel.Debug, item);
                }

                _logger.InsertLog(Core.Domain.Logging.LogLevel.Debug, "Recurring Billing - before interting failed log", $"REquest Result message : {result.SuccessfulResponse.HttpErrorData.Message}");
                _recurringBillingService.LogFailedRecurringBillingCharge(new RecurringBillingFailedLog
                {
                    HasBeenResolved = false,
                    IntialOrderID = Standingorder.OrderStatusId,
                    LogDateTimeStamp = DateTime.Now
                });
            }

            _logger.InsertLog(Core.Domain.Logging.LogLevel.Debug, "Recurring Billing - Ended the process", $"Ended the process : {result.SuccessfulResponse.HTTPStatus}");
        }
        #endregion
    }
}
