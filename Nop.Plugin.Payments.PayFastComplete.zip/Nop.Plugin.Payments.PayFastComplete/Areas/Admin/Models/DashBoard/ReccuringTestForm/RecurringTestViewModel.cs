﻿using Nop.Web.Framework.Models;
using System;
using System.Collections.Generic;
using System.Text;

namespace Nop.Plugin.Payments.PayFastComplete.Areas.Admin.Models.DashBoard.ReccuringTestForm
{
    public class RecurringTestViewModel : BaseNopModel
    {
       
        public int AmountToCharge { get; set; } = 15000;
        public string OrderNumber { get; set; }
        public string SubscriptionRemoteToken { get; set; }
        public string OrderNameOrShortDescription { get; set; }
        public string OrderDescriptionOrFullDescription { get; set; }
        public string Must_ITN_BeSent { get; set; } = "1";
    }
}
