﻿using Nop.Web.Framework.Models;
using System;
using System.Collections.Generic;
using System.Text;

namespace Nop.Plugin.Payments.PayFastComplete.Areas.Admin.Models.TransactionalHistory
{
    public partial class TransactionHistoryListModel: BasePagedListModel<TransactionHistoryViewModel>
    {
    }
}
