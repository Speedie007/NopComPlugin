﻿using Microsoft.AspNetCore.Mvc.Rendering;
using Nop.Plugin.Payments.PayFastComplete.Infrastructure.Common;
using Nop.Plugin.Payments.PayFastComplete.Infrastructure.Common.Enumerations;
using Nop.Web.Framework.Models;
using Nop.Web.Framework.Mvc.ModelBinding;
using System;
using System.Collections.Generic;
using System.Globalization;
using System.Text;

namespace Nop.Plugin.Payments.PayFastComplete.Areas.Admin.Models.TransactionalHistory
{
    public partial class TransactionHistroyMaintenanceViewModel : BaseNopModel
    {
        public DateTime StartDatetime { get; set; }
        public DateTime EndDatetime { get; set; }
       
    }
}
//PeriodStartMonthNames = new List<SelectListItem>() { new SelectListItem("Select Start Month", "0") };
//PeriodStartYearValues = new List<SelectListItem>() { new SelectListItem("Select Start Year", "0") };

//PeriodEndMonthNames = new List<SelectListItem>() { new SelectListItem("Select End Month", "0") };
//PeriodEndYearValues = new List<SelectListItem>() { new SelectListItem("Select End Year", "0") };

//int startingYear = DateTime.Now.Year;
//int iAmountOfYearback = 3;
//for (int i = startingYear; i < startingYear - iAmountOfYearback; i--)
//{
//    PeriodStartYearValues.Add(new SelectListItem(i.ToString(CultureInfo.InvariantCulture), i.ToString(CultureInfo.InvariantCulture)));
//    PeriodEndYearValues.Add(new SelectListItem(i.ToString(CultureInfo.InvariantCulture), i.ToString(CultureInfo.InvariantCulture)));
//}


//foreach (int MonthValue in Enum.GetValues(typeof(EnumMonthNames)))
//{
//    PeriodStartMonthNames.Add(new SelectListItem(Enum.GetName(typeof(EnumMonthNames), MonthValue).ToString(CultureInfo.InvariantCulture), MonthValue.ToString(CultureInfo.InvariantCulture)));
//    PeriodEndMonthNames.Add(new SelectListItem(Enum.GetName(typeof(EnumMonthNames), MonthValue).ToString(CultureInfo.InvariantCulture), MonthValue.ToString(CultureInfo.InvariantCulture)));
//}

//foreach (int DayValue in Enum.GetValues(typeof(EnumDayNames)))
//{
//    PeriodStartMonthNames.Add(new SelectListItem(Enum.GetName(typeof(EnumDayNames), DayValue).Replace("_", "").ToString(CultureInfo.InvariantCulture), DayValue.ToString(CultureInfo.InvariantCulture)));
//    PeriodEndMonthNames.Add(new SelectListItem(Enum.GetName(typeof(EnumDayNames), DayValue).Replace("_","").ToString(CultureInfo.InvariantCulture), DayValue.ToString(CultureInfo.InvariantCulture)));
//}
//EnumDayNames

//public DateTime EndDatetime { get; set; }
////Start Period
//[NopResourceDisplayName("Plugins." + PayFastCompleteDefaults.SystemName + ".TansactionHistorySearchFields.DayOfTranaction")]
//public string PeriodStartSearchByDayOfTransaction { get; set; }


//[NopResourceDisplayName("Plugins." + PayFastCompleteDefaults.SystemName + ".TansactionHistorySearchFields.MonthOfTranaction")]
//public string PeriodStartSearchByMonthOfTranaction { get; set; }


//[NopResourceDisplayName("Plugins." + PayFastCompleteDefaults.SystemName + ".TansactionHistorySearchFields.YearOfTranaction")]
//public string PeriodStartSearchByYearOfTranaction { get; set; }

//public List<SelectListItem> PeriodStartMonthNames { get; set; }
//public List<SelectListItem> PeriodStartYearValues { get; set; }

////End Period
//[NopResourceDisplayName("Plugins." + PayFastCompleteDefaults.SystemName + ".TansactionHistorySearchFields.DayOfTranaction")]
//public string PeriodEndSearchByDayOfTransaction { get; set; }


//[NopResourceDisplayName("Plugins." + PayFastCompleteDefaults.SystemName + ".TansactionHistorySearchFields.MonthOfTranaction")]
//public string PeriodEndSearchByMonthOfTranaction { get; set; }


//[NopResourceDisplayName("Plugins." + PayFastCompleteDefaults.SystemName + ".TansactionHistorySearchFields.YearOfTranaction")]
//public string PeriodendSearchByYearOfTranaction { get; set; }

//public List<SelectListItem> PeriodEndMonthNames { get; set; }
//public List<SelectListItem> PeriodEndYearValues { get; set; }