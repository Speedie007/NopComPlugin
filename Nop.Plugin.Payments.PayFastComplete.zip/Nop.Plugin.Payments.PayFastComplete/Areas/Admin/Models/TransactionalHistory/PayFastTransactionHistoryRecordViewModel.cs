﻿using Nop.Web.Framework.Models;
using System;
using System.Collections.Generic;
using System.Text;

namespace Nop.Plugin.Payments.PayFastComplete.Areas.Admin.Models.TransactionalHistory
{
    public class PayFastTransactionHistoryRecordModel : BaseNopEntityModel
    {
        public DateTime TransactionDate { get; set; }
        public string TransactionType { get; set; }
        public string TransactionParty { get; set; }
        public string TransactionCustomerName { get; set; }
        public string TransactionDesctiption { get; set; }

        public string TransactionCurrency { get; set; }
        public string TransactionFundingType { get; set; }
        public decimal TransactionGrossCostToCustomer { get; set; }
        public decimal PayFastTransactionFee { get; set; }
        public decimal AmountPaidOverToMerchant { get; set; }
        public string MerchantPaymentID { get; set; }
        public string PayFastPaymentID { get; set; }

        public string CustomStringProperty1 { get; set; }
        public int CustomIntegerProperty1 { get; set; }
        public string CustomStringProperty2 { get; set; }
        public int CustomIntegerProperty2 { get; set; }
        public string CustomStringProperty3 { get; set; }
        public int CustomIntegerProperty3 { get; set; }
        public string CustomStringProperty4 { get; set; }
        public int CustomIntegerProperty4 { get; set; }
        public string CustomStringProperty5 { get; set; }
        public int CustomIntegerProperty5 { get; set; }

    }
}

/*
Date - 2020-08-15 14:31:46,
Type - FUNDS_RECEIVED,
Sign - CREDIT,
Party - Test User 01,
Name - Order #3044,
Description - none,
Currency -ZAR,
"Funding Type" - WALLET,
Gross - 400.00,
Fee,
Net,
Balance,
"M Payment ID",
"PF Payment ID",
"custom str1",
"custom int1",
"custom str2",
"custom int2",
"custom str3",
"custom str4",
"custom str5",
"custom int3",
"custom int4",
"custom int5"
*/