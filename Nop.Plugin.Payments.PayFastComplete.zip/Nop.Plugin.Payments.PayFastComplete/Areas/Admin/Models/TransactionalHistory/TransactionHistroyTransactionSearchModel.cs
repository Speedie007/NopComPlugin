﻿using Microsoft.AspNetCore.Mvc.Rendering;
using Nop.Plugin.Payments.PayFastComplete.Infrastructure.Common;
using Nop.Plugin.Payments.PayFastComplete.Infrastructure.Common.Enumerations;
using Nop.Web.Framework.Models;
using Nop.Web.Framework.Mvc.ModelBinding;
using System;
using System.Collections.Generic;
using System.Linq;

namespace Nop.Plugin.Payments.PayFastComplete.Areas.Admin.Models.TransactionalHistory
{
    public partial class TransactionHistroyTransactionSearchModel : BaseSearchModel
    {

        #region Ctor
        public TransactionHistroyTransactionSearchModel()
        {
            MonthNames = new List<SelectListItem>();
            YearValues = new List<SelectListItem>();
            PayFastTransacionTypes = new List<SelectListItem>();

        }
        #endregion


        #region Properties
        [NopResourceDisplayName("Plugins." + PayFastCompleteDefaults.SystemName + ".TansactionHistorySearchFields.DayOfTranaction")]
        public string SearchByDayOfTransaction { get; set; }

        
        [NopResourceDisplayName("Plugins." + PayFastCompleteDefaults.SystemName + ".TansactionHistorySearchFields.MonthOfTranaction")]
        public string SearchByMonthOfTranaction { get; set; }

        
        [NopResourceDisplayName("Plugins." + PayFastCompleteDefaults.SystemName + ".TansactionHistorySearchFields.YearOfTranaction")]
        public string SearchByYearOfTranaction { get; set; }

        public List<SelectListItem> MonthNames { get; set; }
        public List<SelectListItem> YearValues { get; set; }

        
        [NopResourceDisplayName("Plugins." + PayFastCompleteDefaults.SystemName + ".TansactionHistorySearchFields.PayFastTransacionReference")]
        public string SearchByPayFastTranactionReference { get; set; }//M Payment ID -12

        [NopResourceDisplayName("Plugins." + PayFastCompleteDefaults.SystemName + ".TansactionHistorySearchFields.NopCommerceOrderNumber")]
        public string SearchByOrderNumber { get; set; }//PF Payment ID -13

        
        [NopResourceDisplayName("Plugins." + PayFastCompleteDefaults.SystemName + ".TansactionHistorySearchFields.PayFastTransacionType")]
        public string SearchByPayFastTransacionType { get; set; }

        public List<SelectListItem> PayFastTransacionTypes { get; set; }

        #endregion
    }
}
