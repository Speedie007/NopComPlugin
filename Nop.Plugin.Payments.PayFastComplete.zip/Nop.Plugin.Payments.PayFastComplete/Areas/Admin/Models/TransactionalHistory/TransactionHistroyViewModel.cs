﻿using Nop.Plugin.Payments.PayFastComplete.Infrastructure.Common;
using Nop.Web.Framework.Models;
using Nop.Web.Framework.Mvc.ModelBinding;
using System;
using System.Collections.Generic;
using System.Text;

namespace Nop.Plugin.Payments.PayFastComplete.Areas.Admin.Models.TransactionalHistory
{
    public partial class TransactionHistoryViewModel : BaseNopEntityModel
    {
        [NopResourceDisplayName("Plugins." + PayFastCompleteDefaults.SystemName + ".TansactionHistoryFields.TransactionDateTimeStamp")]
        public DateTime TransactionDateTimeStamp { get; set; }

        
        [NopResourceDisplayName("Plugins." + PayFastCompleteDefaults.SystemName + ".TansactionHistoryFields.TransactionType")]
        public string TransactionType { get; set; }

        [NopResourceDisplayName("Plugins." + PayFastCompleteDefaults.SystemName + ".TansactionHistoryFields.TransactionMethod")]
        public string TransactionMethod { get; set; }

        
        [NopResourceDisplayName("Plugins." + PayFastCompleteDefaults.SystemName + ".TansactionHistoryFields.TransactionUserReference")]
        public string TransactionUserReference { get; set; }

        [NopResourceDisplayName("Plugins." + PayFastCompleteDefaults.SystemName + ".TansactionHistoryFields.TransactionName")]
        public string TransactionName { get; set; }

        
        [NopResourceDisplayName("Plugins." + PayFastCompleteDefaults.SystemName + ".TansactionHistoryFields.TransactionDescription")]
        public string TransactionDescription { get; set; }

        [NopResourceDisplayName("Plugins." + PayFastCompleteDefaults.SystemName + ".TansactionHistoryFields.TransactionCurrency")]
        public string TransactionCurrency { get; set; }

        [NopResourceDisplayName("Plugins." + PayFastCompleteDefaults.SystemName + ".TansactionHistoryFields.TransactionFundingSource")]
        public string TransactionFundingSource { get; set; }

        [NopResourceDisplayName("Plugins." + PayFastCompleteDefaults.SystemName + ".TansactionHistoryFields.TransactionGrossAmount")]
        public decimal TransactionGrossAmount { get; set; }
        
        [NopResourceDisplayName("Plugins." + PayFastCompleteDefaults.SystemName + ".TansactionHistoryFields.TransactionFee")]
        public decimal TransactionFee { get; set; }

        [NopResourceDisplayName("Plugins." + PayFastCompleteDefaults.SystemName + ".TansactionHistoryFields.TransactionNetAmount")]
        public decimal TransactionNetAmount { get; set; }

        [NopResourceDisplayName("Plugins." + PayFastCompleteDefaults.SystemName + ".TansactionHistoryFields.TranactionAccountBalance")]
        public decimal TranactionAccountBalance { get; set; }

        [NopResourceDisplayName("Plugins." + PayFastCompleteDefaults.SystemName + ".TansactionHistoryFields.MerchantTranactionReference")]
        public string MerchantTranactionReference { get; set; }

        [NopResourceDisplayName("Plugins." + PayFastCompleteDefaults.SystemName + ".TansactionHistoryFields.PayFastTranactionReference")]
        public string PayFastTranactionReference { get; set; }

        [NopResourceDisplayName("Plugins." + PayFastCompleteDefaults.SystemName + ".TansactionHistoryFields.CustomStringProperty1")]
        public string CustomStringProperty1 { get; set; }

        [NopResourceDisplayName("Plugins." + PayFastCompleteDefaults.SystemName + ".TansactionHistoryFields.CustomIntegerProperty1")]
        public int CustomIntegerProperty1 { get; set; }

        [NopResourceDisplayName("Plugins." + PayFastCompleteDefaults.SystemName + ".TansactionHistoryFields.CustomStringProperty2")]
        public string CustomStringProperty2 { get; set; }

        [NopResourceDisplayName("Plugins." + PayFastCompleteDefaults.SystemName + ".TansactionHistoryFields.CustomIntegerProperty2")]
        public int CustomIntegerProperty2 { get; set; }

        [NopResourceDisplayName("Plugins." + PayFastCompleteDefaults.SystemName + ".TansactionHistoryFields.CustomStringProperty3")]
        public string CustomStringProperty3 { get; set; }


        [NopResourceDisplayName("Plugins." + PayFastCompleteDefaults.SystemName + ".TansactionHistoryFields.CustomIntegerProperty3")]
        public int CustomIntegerProperty3 { get; set; }

        [NopResourceDisplayName("Plugins." + PayFastCompleteDefaults.SystemName + ".TansactionHistoryFields.CustomStringProperty4")]
        public string CustomStringProperty4 { get; set; }

        [NopResourceDisplayName("Plugins." + PayFastCompleteDefaults.SystemName + ".TansactionHistoryFields.CustomIntegerProperty4")]
        public int CustomIntegerProperty4 { get; set; }

        [NopResourceDisplayName("Plugins." + PayFastCompleteDefaults.SystemName + ".TansactionHistoryFields.CustomStringProperty5")]
        public string CustomStringProperty5 { get; set; }

        [NopResourceDisplayName("Plugins." + PayFastCompleteDefaults.SystemName + ".TansactionHistoryFields.CustomIntegerProperty5")]
        public int CustomIntegerProperty5 { get; set; }
    }
}
