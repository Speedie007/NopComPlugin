﻿using Nop.Web.Framework.Models;
using Nop.Web.Framework.Mvc.ModelBinding;
using System;
using System.Collections.Generic;
using System.Text;

namespace Nop.Plugin.Payments.PayFastComplete.Areas.Admin.Models.Configuration
{
    public partial class ConfigurationTestingViewModel : BaseNopModel
    {
        [NopResourceDisplayName("Plugins.Payments.PayFastComplete.Fields.ApiTimeOutValue")]
        public int ApiTimeOutValue { get; set; }

        [NopResourceDisplayName("Plugins.Payments.PayFastComplete.Fields.UseSandbox")]
        public bool UseSandbox { get; set; }

        [NopResourceDisplayName("Plugins.Payments.PayFastComplete.Fields.ApiSubmissionTestingUrl")]
        public string ApiSubmissionTestingUrl { get; set; }

        [NopResourceDisplayName("Plugins.Payments.PayFastComplete.Fields.FormSubnissionTestingUri")]
        public string FormSubmissionTestingUri { get; set; }
    }
}
