﻿using Nop.Web.Framework.Models;
using Nop.Web.Framework.Mvc.ModelBinding;
using System;
using System.Collections.Generic;
using System.Text;

namespace Nop.Plugin.Payments.PayFastComplete.Areas.Admin.Models.Configuration
{
    public partial class SecuritySettingsViewModel : BaseNopModel
    {

        [NopResourceDisplayName("Plugins.Payments.PayFastComplete.Fields.MerchantId")]
        public string MerchantId { get; set; }

        [NopResourceDisplayName("Plugins.Payments.PayFastComplete.Fields.MerchantKey")]
        public string MerchantKey { get; set; }

        [NopResourceDisplayName("Plugins.Payments.PayFastComplete.Fields.APIPassPhrase")]
        public string APIPassPhrase { get; set; }

        [NopResourceDisplayName("Plugins.Payments.PayFastComplete.Fields.APIVersion")]
        public string APIVersion { get; set; }
    }
}
