﻿using Nop.Web.Framework.Models;
using Nop.Web.Framework.Mvc.ModelBinding;

namespace Nop.Plugin.Payments.PayFastComplete.Areas.Admin.Models.Configuration
{
    public partial class SpiltPaymentsViewModel : BaseNopModel
    {

        /// <summary>
        ///<para>Description : Merchant_id - The receiving merchant PayFast ID that must be paid.</para>
        ///<para>Required    : Yes</para>
        ///<para>Format      : numeric, 8 char</para>
        ///</summary>
        [NopResourceDisplayName("Plugins.Payments.PayFastComplete.Fields.SplitRecievingMerchantId")]
        public string RecievingMerchantId { get; set; }

        /// <summary>
        ///<para>Description : The amount in cents (ZAR), that will go to the receiving merchant.</para>
        ///<para>Required    : Yes* (unless only percentage is used)</para>
        ///<para>Format      : numeric</para>
        ///</summary>
        [NopResourceDisplayName("Plugins.Payments.PayFastComplete.Fields.SplitAmount")]
        public decimal Amount { get; set; }

        /// <summary>
        ///<para>Description : The percentage allocated to the receiving merchant.</para>
        ///<para>Required    : Yes* (unless only amount is used)</para>
        ///<para>Format      : numeric, 2 char</para>
        ///</summary>
        [NopResourceDisplayName("Plugins.Payments.PayFastComplete.Fields.SplitPercentage")]
        public decimal Percentage { get; set; }

        /// <summary>
        ///<para>Description : The minimum amount that will be split, in cents (ZAR).</para>
        ///<para>Required    : Optional</para>
        ///<para>Format      : numeric</para>
        ///</summary>
        [NopResourceDisplayName("Plugins.Payments.PayFastComplete.Fields.SplitMinimumAmount")]
        public decimal MinimumAmount { get; set; }

        /// <summary>
        ///<para>Description : The maximum amount that will be split, in cents (ZAR).</para>
        ///<para>Required    : Optional</para>
        ///<para>Format      : numeric</para>
        ///</summary>
        [NopResourceDisplayName("Plugins.Payments.PayFastComplete.Fields.SplitMaximumAmount")]
        public decimal MaximumAmount { get; set; }

        /// <summary>
        ///<para>Description : Defines if the split payment is used.</para>
        ///<para>Required    : Optional</para>
        ///<para>Format      : bool</para>
        ///</summary>
        [NopResourceDisplayName("Plugins.Payments.PayFastComplete.Fields.IsSplitPaymentActive")]
        public bool IsSplitPaymentActive { get; set; }

        /// <summary>
        ///<para>Description : Defines if the split payment trasfered must include the shipping.</para>
        ///<para>Required    : Optional</para>
        ///<para>Format      : bool</para>
        ///</summary>
        [NopResourceDisplayName("Plugins.Payments.PayFastComplete.Fields.SplitMustIncludeShippingCosts")]
        public bool MustIncludeShippingCosts { get; set; }
    }
}
