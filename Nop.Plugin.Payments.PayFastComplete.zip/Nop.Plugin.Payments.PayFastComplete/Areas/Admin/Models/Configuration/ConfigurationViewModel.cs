﻿using Nop.Plugin.Payments.PayFastComplete.Infrastructure.Common;
using Nop.Web.Framework.Models;
using Nop.Web.Framework.Mvc.ModelBinding;
using System;
using System.Collections.Generic;
using System.Text;

namespace Nop.Plugin.Payments.PayFastComplete.Areas.Admin.Models.Configuration
{
    public class ConfigurationViewModel : BaseNopModel
    {
        /// <summary>
        /// Constructor
        /// </summary>
        public ConfigurationViewModel()
        {
        }

        [NopResourceDisplayName("Plugins.Payments.PayFastComplete.Fields.MerchantId")]
        public string MerchantId { get; set; }

        [NopResourceDisplayName("Plugins.Payments.PayFastComplete.Fields.MerchantKey")]
        public string MerchantKey { get; set; }

        [NopResourceDisplayName("Plugins.Payments.PayFastComplete.Fields.UseSandbox")]
        public bool UseSandbox { get; set; }

        [NopResourceDisplayName("Plugins.Payments.PayFastComplete.Fields.AdditionalFee")]
        public decimal AdditionalFee { get; set; }

        [NopResourceDisplayName("Plugins.Payments.PayFastComplete.Fields.AdditionalFeePercentage")]
        public bool AdditionalFeePercentage { get; set; }
        //new
        [NopResourceDisplayName("Plugins.Payments.PayFastComplete.Fields.APIBaseUri")]
        public string APIBaseUri { get; set; }

        [NopResourceDisplayName("Plugins.Payments.PayFastComplete.Fields.APIVersion")]
        public string APIVersion { get; set; }

        [NopResourceDisplayName("Plugins.Payments.PayFastComplete.Fields.FormBaseUri")]
        public string FormBaseUri { get; set; }

        #region Url Properties
        [NopResourceDisplayName("Plugins.Payments.PayFastComplete.Fields.ApiPingUrl")]
        public string ApiPingUrl { get; set; }

        [NopResourceDisplayName("Plugins.Payments.PayFastComplete.Fields.ApiTransactionHistoryForPeriodUrl")]
        public string ApiTransactionHistoryForPeriodUrl { get; set; }

        [NopResourceDisplayName("Plugins.Payments.PayFastComplete.Fields.ApiTransactionHistoryForDailyUrl")]
        public string ApiTransactionHistoryForDailyUrl { get; set; }

        [NopResourceDisplayName("Plugins.Payments.PayFastComplete.Fields.ApiTransactionHistoryForWeeklyUrl")]
        public string ApiTransactionHistoryForWeeklyUrl { get; set; }

        [NopResourceDisplayName("Plugins.Payments.PayFastComplete.Fields.ApiTransactionHistoryForMonthlyUrl")]
        public string ApiTransactionHistoryForMonthlyUrl { get; set; }

        [NopResourceDisplayName("Plugins.Payments.PayFastComplete.Fields.ApiTransactionDetailsUrl")]
        public string ApiTransactionDetailsUrl { get; set; }

        #endregion

        [NopResourceDisplayName("Plugins.Payments.PayFastComplete.Fields.APIPassPhrase")]
        public string APIPassPhrase { get; set; }

        #region Testing links
        [NopResourceDisplayName("Plugins.Payments.PayFastComplete.Fields.ApiSubmissionTestingUrl")]
        public string ApiSubmissionTestingUrl { get; set; }
       
        [NopResourceDisplayName("Plugins.Payments.PayFastComplete.Fields.FormSubnissionTestingUri")]
        public string FormSubnissionTestingUri { get; set; }
        #endregion


    }
}