﻿using Nop.Web.Framework.Models;
using Nop.Web.Framework.Mvc.ModelBinding;
using System;
using System.Collections.Generic;
using System.Drawing;
using System.Text;

namespace Nop.Plugin.Payments.PayFastComplete.Areas.Admin.Models.Configuration
{
    public partial class UrlConfigurationViewModel : BaseNopModel
    {

        [NopResourceDisplayName("Plugins.Payments.PayFastComplete.Fields.APIBaseUri")]
        public string APIBaseUri { get; set; }

        

        [NopResourceDisplayName("Plugins.Payments.PayFastComplete.Fields.FormBaseUri")]
        public string FormBaseUri { get; set; }

      
        [NopResourceDisplayName("Plugins.Payments.PayFastComplete.Fields.ApiPingUrl")]
        public string ApiPingUrl { get; set; }

        [NopResourceDisplayName("Plugins.Payments.PayFastComplete.Fields.ApiTransactionHistoryForPeriodUrl")]
        public string ApiTransactionHistoryForPeriodUrl { get; set; }

        [NopResourceDisplayName("Plugins.Payments.PayFastComplete.Fields.ApiTransactionHistoryForDailyUrl")]
        public string ApiTransactionHistoryForDailyUrl { get; set; }

        [NopResourceDisplayName("Plugins.Payments.PayFastComplete.Fields.ApiTransactionHistoryForWeeklyUrl")]
        public string ApiTransactionHistoryForWeeklyUrl { get; set; }

        [NopResourceDisplayName("Plugins.Payments.PayFastComplete.Fields.ApiTransactionHistoryForMonthlyUrl")]
        public string ApiTransactionHistoryForMonthlyUrl { get; set; }

        [NopResourceDisplayName("Plugins.Payments.PayFastComplete.Fields.ApiTransactionDetailsUrl")]
        public string ApiTransactionDetailsUrl { get; set; }
        //----------------

        [NopResourceDisplayName("Plugins.Payments.PayFastComplete.Fields.ApiRecurringBillingAdHocChargeUrl")]
        public string ApiRecurringBillingAdHocChargeUrl { get; set; }

        
        [NopResourceDisplayName("Plugins.Payments.PayFastComplete.Fields.ApiRecurringBillingCommonFetchUrl")]
        public string ApiRecurringBillingCommonFetchUrl { get; set; }

        
        [NopResourceDisplayName("Plugins.Payments.PayFastComplete.Fields.ApiRecurringBillingCommonCancelUrl")]
        public string ApiRecurringBillingCommonCancelUrl { get; set; }

        
        [NopResourceDisplayName("Plugins.Payments.PayFastComplete.Fields.ApiRecurringBillingNormalPauseUrl")]
        public string ApiRecurringBillingNormalPauseUrl { get; set; }

        
        [NopResourceDisplayName("Plugins.Payments.PayFastComplete.Fields.ApiRecurringBillingNormalUnpauseUrl")]
        public string ApiRecurringBillingNormalUnpauseUrl { get; set; }

        
        [NopResourceDisplayName("Plugins.Payments.PayFastComplete.Fields.ApiRecurringBillingNormalUpdateUrl")]
        public string ApiRecurringBillingNormalUpdateUrl { get; set; }
    }
}
