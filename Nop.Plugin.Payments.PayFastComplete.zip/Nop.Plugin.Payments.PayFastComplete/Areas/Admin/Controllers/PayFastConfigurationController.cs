﻿using FluentValidation;
using Microsoft.AspNetCore.Mvc;
using Nop.Plugin.Payments.PayFastComplete.Areas.Admin.Models.Configuration;
using Nop.Plugin.Payments.PayFastComplete.Factories;
using Nop.Plugin.Payments.PayFastComplete.Infrastructure.Common.Results;
using Nop.Plugin.Payments.PayFastComplete.Services;
using Nop.Plugin.Payments.PayFastComplete.Services.PayFastConfigurationServices;
using Nop.Plugin.Payments.PayFastComplete.Validators;
using Nop.Services.Localization;
using Nop.Services.Messages;
using Nop.Services.Security;
using Nop.Web.Framework;
using Nop.Web.Framework.Controllers;
using Nop.Web.Framework.Mvc.Filters;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Text;

namespace Nop.Plugin.Payments.PayFastComplete.Areas.Admin.Controllers
{
    [Area(AreaNames.Admin)]
    [AuthorizeAdmin]
    public partial class PayFastConfigurationController : BasePaymentController
    {


        #region Fields
        private readonly IPayFastConfigurationFactory _payFastConfigurationFactory;
        private readonly IPayFastConfigurationService _payFastConfigurationService;
        private readonly ILocalizationService _localizationService;
        private readonly IPayFastCompleteService _payFastCompleteService;
        private readonly INotificationService _notificationService;
        private readonly IPermissionService _permissionService;
        #endregion

        #region cstr

        public PayFastConfigurationController(
            ILocalizationService localizationService,
            IPayFastConfigurationFactory payFastConfigurationFactory,
            IPermissionService permissionService,
            INotificationService notificationService,
            IPayFastCompleteService payFastCompleteService,
            IPayFastConfigurationService payFastConfigurationService)
        {
            _payFastConfigurationService = payFastConfigurationService;
            _localizationService = localizationService;
            _payFastCompleteService = payFastCompleteService;
            _notificationService = notificationService;
            _permissionService = permissionService;
            _payFastConfigurationFactory = payFastConfigurationFactory;
        }

        #endregion

        #region Action Methods

        [HttpGet]
        public IActionResult ListSecuritySettings()
        {
            var model = _payFastConfigurationFactory.PrepareSecuritySettingsViewModel();
            return View(model);
        }
        [HttpPost]
        public IActionResult ListSecuritySettings(SecuritySettingsViewModel model)
        {
            if (!_permissionService.Authorize(StandardPermissionProvider.ManagePaymentMethods))
            {
                return this.AccessDeniedView();
            }
            if (!base.ModelState.IsValid)
            {
                _notificationService.ErrorNotification("Error Validating the the values that you provided.", true);
                RedirectToAction(nameof(ListSecuritySettings));
            }


            SettingsResult Rtn = _payFastConfigurationService.UpdateConfigurationSettings(model);
            if (Rtn.Success)
            {
                _notificationService.SuccessNotification(_localizationService.GetResource("Admin.Plugins.Saved"), true);
            }
            else
            {
                foreach (var item in Rtn.Errors)
                {
                    _notificationService.ErrorNotification(item, true);
                }
            }


            return RedirectToAction(nameof(ListSecuritySettings));
        }
        public IActionResult ListAdditionalCharges()
        {
            var model = _payFastConfigurationFactory.PrepareAdditionalChargesViewModel();
            return View(model);
        }
        [HttpPost]
        public IActionResult ListAdditionalCharges(AdditionalChargesViewModel model)
        {
            if (!_permissionService.Authorize(StandardPermissionProvider.ManagePaymentMethods))
            {
                return this.AccessDeniedView();
            }
            if (!base.ModelState.IsValid)
            {
                _notificationService.ErrorNotification("Error Validating the the values that you provided.", true);
                RedirectToAction(nameof(ListAdditionalCharges));
            }


            SettingsResult Rtn = _payFastConfigurationService.UpdateAdditionalCharges(model);
            if (Rtn.Success)
            {
                _notificationService.SuccessNotification(_localizationService.GetResource("Admin.Plugins.Saved"), true);
            }
            else
            {
                foreach (var item in Rtn.Errors)
                {
                    _notificationService.ErrorNotification(item, true);
                }
            }

            return RedirectToAction(nameof(ListAdditionalCharges));
        }
        public IActionResult ListConfigurationTesting()
        {

            var model = _payFastConfigurationFactory.PrepareConfigurationTestingViewModel();
            return View(model);
        }

        [HttpPost]
        public IActionResult ListConfigurationTesting(ConfigurationTestingViewModel model)
        {
            if (!_permissionService.Authorize(StandardPermissionProvider.ManagePaymentMethods))
            {
                return this.AccessDeniedView();
            }
            if (!base.ModelState.IsValid)
            {
                _notificationService.ErrorNotification("Error Validating the the values that you provided.", true);
                RedirectToAction(nameof(ListConfigurationTesting));
            }


            SettingsResult Rtn = _payFastConfigurationService.UpdateConfigurationTesting(model);
            if (Rtn.Success)
            {
                _notificationService.SuccessNotification(_localizationService.GetResource("Admin.Plugins.Saved"), true);
            }
            else
            {
                foreach (var item in Rtn.Errors)
                {
                    _notificationService.ErrorNotification(item, true);
                }
            }

            return RedirectToAction(nameof(ListConfigurationTesting));
        }

        [HttpGet]
        public IActionResult ListURLConfiguration()
        {
            var model = _payFastConfigurationFactory.PrepareUrlConfigurationViewModel();
            return View(model);

        }

        [HttpPost]
        public IActionResult ListURLConfiguration(UrlConfigurationViewModel model)
        {
            if (!_permissionService.Authorize(StandardPermissionProvider.ManagePaymentMethods))
            {
                return this.AccessDeniedView();
            }
            if (!base.ModelState.IsValid)
            {
                _notificationService.ErrorNotification("Error Validating the the values that you provided.", true);
                RedirectToAction(nameof(ListURLConfiguration));
            }


            SettingsResult Rtn = _payFastConfigurationService.UpdateUrlCpnfiguration(model);
            if (Rtn.Success)
            {
                _notificationService.SuccessNotification(_localizationService.GetResource("Admin.Plugins.Saved"), true);
            }
            else
            {
                foreach (var item in Rtn.Errors)
                {
                    _notificationService.ErrorNotification(item, true);
                }
            }

            return RedirectToAction(nameof(ListURLConfiguration));
        }

        [HttpGet]
        public IActionResult ListSplitPayments()
        {
            var model = _payFastConfigurationFactory.PrepareSpiltPaymentsViewModel();
            return View(model);
        }

        [HttpPost]
        public IActionResult ListSplitPayments(SpiltPaymentsViewModel model)
        {
            if (!_permissionService.Authorize(StandardPermissionProvider.ManagePaymentMethods))
            {
                return this.AccessDeniedView();
            }

            if (!base.ModelState.IsValid)
            {
                model.IsSplitPaymentActive = false;
                _notificationService.ErrorNotification("Settings NOT Been Saved. Please esure that all the require propertiess are set correctly, such as the merchant ID.", true);
                return View(model);
            }


            SettingsResult Rtn = _payFastConfigurationService.UpdateSplitPaymentOptions(model);
            if (Rtn.Success)
            {
                _notificationService.SuccessNotification(_localizationService.GetResource("Admin.Plugins.Saved"), true);
            }
            else
            {
                foreach (var item in Rtn.Errors)
                {
                    _notificationService.ErrorNotification(item, true);
                }
            }

            return RedirectToAction(nameof(ListSplitPayments));
        }
        #endregion
    }
}
