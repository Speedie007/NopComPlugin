﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Primitives;
using Nop.Core;
using Nop.Core.Domain.Catalog;
using Nop.Core.Domain.Localization;
using Nop.Core.Domain.Orders;
using Nop.Core.Domain.Payments;
using Nop.Core.Infrastructure;
using Nop.Plugin.Payments.PayFastComplete.Infrastructure.Common;
using Nop.Plugin.Payments.PayFastComplete.Services.PaymentProcessingVerificationServices;
using Nop.Plugin.Payments.PayFastComplete.Services.PaymentProcessingVerificationServices.Results;
using Nop.Plugin.Payments.PayFastComplete.Settings;
using Nop.Plugin.Payments.PayFastComplete.WebHooks.Models;
using Nop.Services.Customers;
using Nop.Services.Localization;
using Nop.Services.Logging;
using Nop.Services.Messages;
using Nop.Services.Orders;
using Nop.Services.Payments;
using Nop.Web.Framework.Controllers;
using System;
using System.Collections.Generic;
using System.Linq;

namespace Nop.Plugin.Payments.PayFastComplete.Areas.Admin.Controllers
{

    public class PayFastPaymentProcessingController : BasePaymentController
    {



        #region Fields
        private readonly IPaymentProcessingVerificationService _paymentProcessingVerificationService;
        private readonly IWebHelper _webHelper;
        private readonly ILogger _logger;
        private readonly IOrderProcessingService _orderProcessingService;
        private readonly IOrderService _orderService;
        private readonly PayFastCompleteSettings _payfastCompleteSettings;
        private readonly IStoreContext _storeContext;
        private readonly IWorkContext _workContext;
        private readonly IHttpContextAccessor _httpContextAccessor;
        private readonly ICustomerService _customerService;
        private readonly LocalizationSettings _localizationSettings;
        private readonly IWorkflowMessageService _workflowMessageService;
        private readonly IPaymentService _paymentService;

        #endregion

        #region cstor
        public PayFastPaymentProcessingController(
                IWebHelper webHelper,
                ILogger logger,
                IOrderProcessingService orderProcessingService,
                IOrderService orderService,
                PayFastCompleteSettings payfastCompleteSettings,
                IStoreContext storeContext,
                IWorkContext workContext,
                IPaymentProcessingVerificationService paymentProcessingVerificationService,
                IPaymentService paymentService,
                IWorkflowMessageService workflowMessageService,
                LocalizationSettings localizationSettings,
             IHttpContextAccessor httpContextAccessor,
             ICustomerService customerService

            )
        {
            _customerService = customerService;
            _localizationSettings = localizationSettings;
            _workflowMessageService = workflowMessageService;
            _paymentService = paymentService;
            _paymentProcessingVerificationService = paymentProcessingVerificationService;
            _webHelper = webHelper;
            _logger = logger;
            _orderProcessingService = orderProcessingService;
            _orderService = orderService;
            _payfastCompleteSettings = payfastCompleteSettings;
            _storeContext = storeContext;
            _workContext = workContext;
            _httpContextAccessor = httpContextAccessor;
        }
        #endregion


        #region Action Methods
        /// <summary>
        /// Last updated: 31 Aug 2020
        /// Author: Brendan Wood
        /// Email: brendan@inspecserv.co.za
        /// </summary>
        /// <param name="IpnModel">Class model that the parameters passed through from Payfast are bound to.</param>
        /// <param name="form">FORM Collection of the Key/Value pairs of all the values passed back from Payfast after the payment was completed.</param>
        /// <returns></returns>
        public IActionResult PayFastResultHandler(IpnModel IpnModel, IFormCollection form)
        {
            //_logger.Error($"HTTP HEADER ITEMS", null, null);
            //_logger.Error($"-------------------------------------------------------------------", null, null);
            //foreach (var kvp in _httpContextAccessor.HttpContext.Request.Headers)
            //{
            //    _logger.Error($"Property KEY[{kvp.Key}] = Property VALUE[{kvp.Value}]", null, null);
            //}
            //_logger.Error($"HTTP QUERYSTRING ITEMS", null, null);
            //_logger.Error($"-------------------------------------------------------------------", null, null);
            //_logger.Error($"{_httpContextAccessor.HttpContext.Request.QueryString.Value}", null, null);
            //_logger.Error($"-------------------------------------------------------------------", null, null);

            //_logger.Error($"PayFast ITN error[{1}] :PayFasy Values Returned After Payment Attempt: SEE ABOVE.", null, null);
            //foreach (var item in form)
            //{

            //    _logger.Error($"Property KEY[{item.Key}] = Property VALUE[{item.Value}]", null, null);
            //}
            /*Step 1-2 -Conduct four security checks to ensure that the data you are receiving is correct, 
             * from the correct source and hasn’t been altered; 
             * you should not continue the process if a test fails!
             * *******************************************************/
            PaymentProcessVerificationResult result = new PaymentProcessVerificationResult();
            _paymentProcessingVerificationService.ConductSecurityCheckOne_VerifySignature(result, form);
            if (!result.Success)
                return ProcessErrors(result.Errors, "VerifySignature"); //Stops Here and returns StatusOk HTTP200 to the Payfast System.
            _paymentProcessingVerificationService.ConductSecurityCheckTwo_VerifyComminicationWithPayFastEngine(result);
            if (!result.Success)
                return ProcessErrors(result.Errors, "VerifyComminicationWithPayFastEngine"); //Stops Here and returns StatusOk HTTP200 to the Payfast System.
            _paymentProcessingVerificationService.ConductSecurityCheckThree_VerifyProcessedAmountFromPayFast(result, IpnModel);
            if (!result.Success)
                return ProcessErrors(result.Errors, "VerifyProcessedAmountFromPayFast"); //Stops Here and returns StatusOk HTTP200 to the Payfast System.
            _paymentProcessingVerificationService.ConductSecurityCheckFour_ValidateDataRecievedFromPayFast(result, IpnModel);
            if (!result.Success)
                return ProcessErrors(result.Errors, "ValidateDataRecievedFromPayFast"); //Stops Here and returns StatusOk HTTP200 to the Payfast System.

            // Step Three - Query your database and compare the pf_payment_id in order to verify that the order hasn’t already been processed on your system.
            //Step Four -Once you have completed these tests and the data received is valid, check the payment status and handle appropriately.
            switch (IpnModel.PaymentStatus)
            {
                case PayFastCompleteDefaults.OrderProcessing_COMPLETE:
                    // If complete, update your application
                    try
                    {
                        if (_orderProcessingService.CanMarkOrderAsPaid(result.CurrentOrderBeingProcessed))
                        {
                            //Settings Subscription Token if avaiable - Means its a recurring Payment Setup on the PayFast Sysytem.
                            if (IpnModel.SubscriptionToken != null)
                                if (IpnModel.SubscriptionToken.Length > 0)
                                {
                                    result.CurrentOrderBeingProcessed.SubscriptionTransactionId = IpnModel.SubscriptionToken;
                                }

                            result.CurrentOrderBeingProcessed.PaidDateUtc = DateTime.UtcNow;
                            result.CurrentOrderBeingProcessed.AuthorizationTransactionId = IpnModel.PayFastPaymentID;
                            result.CurrentOrderBeingProcessed.AuthorizationTransactionResult = IpnModel.PaymentStatus;
                            _orderService.UpdateOrder(result.CurrentOrderBeingProcessed);
                            _orderProcessingService.MarkOrderAsPaid(result.CurrentOrderBeingProcessed);
                            //If new recurring payment add ititial Order Confirtmation of this payment to the PaymentHistory
                            // RecurringPayment rp = _orderService.SearchRecurringPayments(initialOrderId: result.CurrentOrderBeingProcessed.Id).FirstOrDefault();
                            if (_orderService.SearchRecurringPayments(initialOrderId: result.CurrentOrderBeingProcessed.Id)
                                .FirstOrDefault() is RecurringPayment rp)
                            {
                                var recurringPaymentHistory = _orderService.GetRecurringPaymentHistory(rp);
                                if (!recurringPaymentHistory.Any())
                                {
                                    rp.StartDateUtc = rp.CyclePeriod switch
                                    {
                                        RecurringProductCyclePeriod.Days => rp.StartDateUtc.AddDays(rp.CycleLength),
                                        RecurringProductCyclePeriod.Weeks => rp.StartDateUtc.AddDays(7 * rp.CycleLength),
                                        RecurringProductCyclePeriod.Months => rp.StartDateUtc.AddMonths(rp.CycleLength),
                                        RecurringProductCyclePeriod.Years => rp.StartDateUtc.AddYears(rp.CycleLength),
                                        _ => throw new NopException("Not supported cycle period"),
                                    };
                                    //_logger.Error($"strat date = {rp.StartDateUtc }", null, null);
                                    _orderService.UpdateRecurringPayment(rp);

                                }
                            }

                        }
                        else
                        {
                            //This order already exists. Check if it is a recurring order, if so process the next recurring order.
                            if (Guid.TryParse(IpnModel.MerchantPaymentID, out Guid IntialNewOrderGuid))
                            {
                                ProcessPaymentResult processPaymentResult = new ProcessPaymentResult()
                                {
                                    AuthorizationTransactionId = IpnModel.PayFastPaymentID,
                                    AuthorizationTransactionResult = IpnModel.PaymentStatus,
                                    NewPaymentStatus = PaymentStatus.Paid,
                                    RecurringPaymentFailed = false,
                                    SubscriptionTransactionId = IpnModel.SubscriptionToken
                                };
                                //Its a recurring order
                                Order InitialOrder = _orderService.GetOrderByGuid(IntialNewOrderGuid);
                                RecurringPayment recurringPayment = _orderService.SearchRecurringPayments(initialOrderId: InitialOrder.Id).Where(x => x.IsActive).FirstOrDefault();
                                if (recurringPayment != null)
                                {
                                    foreach (string PossibleErrorsEncountered in _orderProcessingService.ProcessNextRecurringPayment(recurringPayment, processPaymentResult))
                                    {
                                        result.AddError($"Error Process New Recurring Order : internal error: {PossibleErrorsEncountered}");
                                    }
                                    if (processPaymentResult.Success)
                                    {

                                        if (_orderProcessingService.GetCyclesRemaining(recurringPayment) == 0)
                                        {
                                            //if (_orderProcessingService.CanCancelRecurringPayment(_customerService.GetCustomerById(InitialOrder.CustomerId), recurringPayment))
                                            //{
                                                foreach (string PossibleErrorsEncountered in _orderProcessingService.CancelRecurringPayment(recurringPayment))
                                                {
                                                    result.AddError($"Error Cancelling Recurring Order : internal error: {PossibleErrorsEncountered}");
                                                }

                                                _orderService.InsertOrderNote(new OrderNote
                                                {
                                                    OrderId = InitialOrder.Id,
                                                    Note = $"Recurring payment for order {InitialOrder.Id} have been completed and Canceled on the PayFast System. {DateTime.UtcNow}",
                                                    DisplayToCustomer = true,
                                                    CreatedOnUtc = DateTime.UtcNow
                                                });
                                            //}
                                        }
                                    }
                                }
                                else
                                    result.AddError($"Error Locating the Recurring Payment to process based on the orignal order : internal error: None.");

                            }
                        }
                    }
                    catch (Exception ex)
                    {
                        result.AddError($"ErrorUpdating the Order Details : internal error: {ex.Message}");
                    }
                    break;
                case PayFastCompleteDefaults.OrderProcessing_CANCELED:


                    // If cancel, then cancel subscription, This will process cancelations that are initilise by the user via there payfast account.
                    CancelRecurringPaymentResult cancelRecurringPaymentResult = new CancelRecurringPaymentResult();
                    //_logger.Error($"CANCEL-1 :-------------------------------------", null, null);
                    if (Guid.TryParse(IpnModel.MerchantPaymentID, out Guid InitialOrderID))
                    {
                        // Order InitialOrder = _orderService.GetOrderByGuid(InitialOrderID);
                        if (_orderService.GetOrderByGuid(InitialOrderID) is Order InitialOrder)
                        {
                            if (_orderService.SearchRecurringPayments(initialOrderId: InitialOrder.Id).FirstOrDefault() is RecurringPayment recurringPayment)
                            {
                                if (_orderProcessingService.CanCancelRecurringPayment(_customerService.GetCustomerById(InitialOrder.CustomerId), recurringPayment))
                                {
                                    //update recurring payment
                                    recurringPayment.IsActive = false;
                                    _orderService.UpdateRecurringPayment(recurringPayment);
                                    //add a note
                                    _orderService.InsertOrderNote(new OrderNote
                                    {
                                        OrderId = InitialOrder.Id,
                                        Note = $"Recurring payment has been cancelled From the PayFast System. {DateTime.UtcNow}",
                                        DisplayToCustomer = true,
                                        CreatedOnUtc = DateTime.UtcNow
                                    });
                                    //notify a store owner
                                    _workflowMessageService
                                        .SendRecurringPaymentCancelledStoreOwnerNotification(recurringPayment,
                                        _localizationSettings.DefaultAdminLanguageId);
                                }

                            }
                            else
                            {
                                cancelRecurringPaymentResult.AddError($"Error Locating the Recurring Payment to process based on the orignal order : internal error: None.");
                            }
                        }

                    }
                    else
                    {
                        cancelRecurringPaymentResult.AddError($"Error Unable to extract the orignial order number from the Data recieved from PafyFast to Extranct the Recurring Payment To Cancel : internal error: None.");
                    }
                    result.CombineError(cancelRecurringPaymentResult.Errors);
                    break;
                default:
                    // If unknown status, do nothing (which is the safest course of action)

                    //TODO:Notifiy Addmin vai eamil
                    break;
            }
            if (!result.Success)
                return ProcessErrors(result.Errors, "5"); //Stops Here and returns StatusOk HTTP200 to the Payfast System.
            else
            {
                /*TODO: Write the SuccessFullTransaction To the Database.(Custom PayFast Tables)
            /* If We Got This Far Means The Payment Was Successfully Completed By the PayFast System 
            * and Validated on NopCommerce Side.
            * *********************************************************************************/
                return new StatusCodeResult(200);

            }


            //Inner Method To Handel Any Errors
            StatusCodeResult ProcessErrors(IList<string> AllErrors, string SectionThatFailed)
            {
                _logger.Error($"PayFast ITN error[{SectionThatFailed}] :PayFasy Values Returned After Payment Attempt: SEE ABOVE.", null, null);
                foreach (var item in form)
                {
                    _logger.Error($"Property KEY[{item.Key}] = Property VALUE[{item.Value}]", null, null);
                }
                foreach (string ErrorItem in AllErrors)
                {
                    _logger.Error($"PayFast ITN error[{SectionThatFailed}] : { DateTime.Now } : {ErrorItem}", null, null);
                }

                /*TODO: Build Message Service Funcrtion to Email the System Administration that 
             * the payment was not validate automatically and requires manuall intervention to 
             * success complete the order validation.
             * THIS MUST HAPPEN HERE....
             * ************************************************************************************/
                return new StatusCodeResult(200);
            }
        }
        #endregion
    }
}
