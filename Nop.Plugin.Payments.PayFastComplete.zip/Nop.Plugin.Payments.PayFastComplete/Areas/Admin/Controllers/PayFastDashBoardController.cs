﻿using Microsoft.AspNetCore.Mvc;
using Nop.Plugin.Payments.PayFastComplete.Areas.Admin.Models.DashBoard.ReccuringTestForm;
using Nop.Plugin.Payments.PayFastComplete.Extensions;
using Nop.Plugin.Payments.PayFastComplete.Services.IPayFastApiClientServices;
using Nop.Plugin.Payments.PayFastComplete.Services.PayFastApiClientServices.Models.Api.Requests.AdHocSubscription;
using Nop.Plugin.Payments.PayFastComplete.Services.PayFastApiClientServices.Models.Api.Requests.SubscriptionCommon;
using Nop.Plugin.Payments.PayFastComplete.Services.PayFastApiClientServices.Models.Api.Requests.TransactionalHistory;
using Nop.Plugin.Payments.PayFastComplete.Services.PayFastApiClientServices.Models.Api.Results.SubscriptionCommon;
using Nop.Plugin.Payments.PayFastComplete.Services.PayFastApiClientServices.Models.Api.Results.TransactionHistroy;
using Nop.Plugin.Payments.PayFastComplete.Settings;
using Nop.Services.Messages;
using Nop.Web.Framework;
using Nop.Web.Framework.Controllers;
using System;

namespace Nop.Plugin.Payments.PayFastComplete.Areas.Admin.Controllers
{
    [Area(AreaNames.Admin)]
    public class PayFastDashBoardController : BasePluginController
    {
        private readonly PayFastCompleteSettings _payFastCompleteSettings;

        #region Fields
        private readonly IPayFastApiClientService _payFastApiClientService;
        private readonly INotificationService _notificationService;
        #endregion

        #region Cstor
        public PayFastDashBoardController(IPayFastApiClientService  payFastApiClientService,
             INotificationService notificationService,
             PayFastCompleteSettings payFastCompleteSettings)
        {
            _payFastCompleteSettings = payFastCompleteSettings;
            _payFastApiClientService = payFastApiClientService;
            _notificationService = notificationService;
        }
        #endregion

        #region Action Methods
        public IActionResult Display()
        {
            return View();
        }

        [HttpGet]
        public IActionResult RecurringTest()
        {
            return View(new RecurringTestViewModel());
        }

        public void AllLinks()
        {
            #region Ping Request
            _payFastApiClientService.PingPayFastApiGateway();
            #endregion

            #region Recurring Billing Ad Hoc

            //Api Ad Hoc Charge
            //StandardSuccsessFailurePayFastApiResult buildApiRequestResult = new StandardSuccsessFailurePayFastApiResult();
            //PayFastApiAdHocChargeModel AdHocChargeModel = new PayFastApiAdHocChargeModel("Parameters"});
            //_payFastApiClientService.ProcessRequestToApiGateway(AdHocChargeModel, buildApiRequestResult);
            #endregion
        }
        [HttpPost]
        public IActionResult RecurringTest(RecurringTestViewModel model)
        {

            StandardSuccsessFailurePayFastApiResult buildApiRequestResult=  _payFastApiClientService.ChargeAdHocRecurringPayment(AmountToCharge: model.AmountToCharge.ToString(),
                   OrderNumber: model.OrderNumber,
                   SubscriptionRemoteToken: model.SubscriptionRemoteToken,
                   OrderNameOrShortDescription: model.OrderNameOrShortDescription,
                   OrderDescriptionOrFullDescription: model.OrderDescriptionOrFullDescription,
                   Must_ITN_BeSent: model.Must_ITN_BeSent);

            if (buildApiRequestResult.Success)
            {
                _notificationService.SuccessNotification("It works been charged", false);
            }
            else
            {
                foreach (var item in buildApiRequestResult.Errors)
                {
                    _notificationService.ErrorNotification(item, false);
                }

            }
            return RedirectToAction(nameof(RecurringTest));
        }
        [HttpPost]
        public IActionResult testApi()
        {
           
           

            if (_payFastApiClientService.PingPayFastApiGateway().Success)
            {
                _notificationService.SuccessNotification("It works", false);
            }
            else
            {
                foreach (var item in _payFastApiClientService.PingPayFastApiGateway().Errors)
                {
                    _notificationService.ErrorNotification(item, false);
                }
            }

            return RedirectToAction(nameof(Display));
        }

        [HttpPost]
        public void testFormpPaymentMethod()
        {
           
        }
        [HttpPost]
        public IActionResult testHistoryApi()
        {
            _payFastApiClientService.CancelReccuringPayment("");



            if (_payFastApiClientService.GetTransactionHistoryBySelectedDailyPeriod(DateTime.Now.GenerateTransactionalTimeStamp()).Success)
            {
                _notificationService.SuccessNotification("It works", false);
            }
            else
            {
                foreach (var item in _payFastApiClientService.GetTransactionHistoryBySelectedDailyPeriod(DateTime.Now.GenerateTransactionalTimeStamp()).Errors)
                {
                    _notificationService.ErrorNotification(item, false);
                }
            }

            var dt1 = new DateTime(2020, 09, 12);
            

            if (_payFastApiClientService.GetTransactionHistoryBySelectedToAndFromPeriod(DateTime.Now.GenerateTransactionalTimeStamp(), dt1.GenerateTransactionalTimeStamp()).Success)
            {
                _notificationService.SuccessNotification("It works", false);
            }
            else
            {
                foreach (var item in _payFastApiClientService.GetTransactionHistoryBySelectedToAndFromPeriod(DateTime.Now.GenerateTransactionalTimeStamp(), dt1.GenerateTransactionalTimeStamp()).Errors)
                {
                    _notificationService.ErrorNotification(item, false);
                }
            }

           

            return RedirectToAction(nameof(Display));
        }
        #endregion
    }
}
