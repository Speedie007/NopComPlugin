﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Nop.Core;
using Nop.Core.Configuration;
using Nop.Core.Domain.Orders;
using Nop.Plugin.Payments.PayFastComplete.Areas.Admin.Models.Configuration;
using Nop.Plugin.Payments.PayFastComplete.Factories;
using Nop.Plugin.Payments.PayFastComplete.Infrastructure.Common.Results;
using Nop.Plugin.Payments.PayFastComplete.Services;
using Nop.Plugin.Payments.PayFastComplete.Settings;
using Nop.Plugin.Payments.PayFastComplete.WebHooks.Models;
using Nop.Services.Configuration;
using Nop.Services.Localization;
using Nop.Services.Messages;
using Nop.Services.Orders;
using Nop.Services.Security;
using Nop.Web.Framework;
using Nop.Web.Framework.Controllers;
using Nop.Web.Framework.Mvc.Filters;
using System;
using Nop.Services.Logging;
using System.Collections.Generic;
using System.Drawing;
using System.Text;
using System.util.collections;
using System.Net;
using System.Linq;
using System.Collections.Specialized;
using Microsoft.Extensions.Primitives;

namespace Nop.Plugin.Payments.PayFastComplete.Areas.Admin.Controllers
{
    [Area(AreaNames.Admin)]
    public class PayFastCompleteConfigurationController : BasePaymentController
    {
        #region Fields
        private readonly IPayFastConfigurationFactory _payfastConfigurationFactory;
        private readonly IOrderProcessingService _orderProcessingService;
        private readonly IOrderService _orderService;
        private readonly IPayFastCompleteService _payFastCompleteService;
        private readonly ILocalizationService _localizationService;
        private readonly ISettingService _settingService;
        private readonly IStoreContext _storeContext;
        private readonly PayFastCompleteSettings _payfastCompleteSettings;
        private readonly INotificationService _notificationService;
        private readonly IPermissionService _permissionService;
        private readonly ILogger _logger;
        private readonly IWorkContext _workContext;
        private readonly IWebHelper _webHelper;

        #endregion

        #region Cstor
        public PayFastCompleteConfigurationController(
                INotificationService notificationService,
                IPermissionService permissionService,
                IPayFastConfigurationFactory payfastConfigurationFactory,
                PayFastCompleteSettings payfastCompleteSettings,
                IStoreContext storeContext,
                ISettingService settingService,
                ILocalizationService localizationService,
                IPayFastCompleteService payFastCompleteService,
                IOrderProcessingService orderProcessingService,
                IOrderService orderService,
                ILogger logger,
                IWorkContext workContext,
                IWebHelper webHelper)
        {
            _payFastCompleteService = payFastCompleteService;
            _localizationService = localizationService;
            _settingService = settingService;
            _storeContext = storeContext;
            _payfastCompleteSettings = payfastCompleteSettings;
            _notificationService = notificationService;
            _permissionService = permissionService;
            _payfastConfigurationFactory = payfastConfigurationFactory;
            _orderProcessingService = orderProcessingService;
            _orderService = orderService;
            _logger = logger;
            _workContext = workContext;
            _webHelper = webHelper;
        }
        #endregion

        [HttpGet]
        #region Plugin Details
        public IActionResult PayFastDocumentation() => View();

        #endregion

        #region Plugin Configuration
        [AuthorizeAdmin]
        public IActionResult List()
        {
            if (!_permissionService.Authorize(StandardPermissionProvider.ManagePaymentMethods))
            {
                return this.AccessDeniedView();
            }

            return View();
        }
        [HttpPost]
        [AuthorizeAdmin]
        public IActionResult UpdateConfigurationSettings(ConfigurationViewModel model)
        {

            if (!_permissionService.Authorize(StandardPermissionProvider.ManagePaymentMethods))
            {
                return this.AccessDeniedView();
            }
            if (!base.ModelState.IsValid)
            {
                _notificationService.ErrorNotification("Error Validating the the values that you provided.", true);
                return RedirectToAction(nameof(List));
            }

            //_payfastCompleteSettings.MerchantId = model.MerchantId;
            //_payfastCompleteSettings.MerchantKey = model.MerchantKey;
            //_payfastCompleteSettings.UseSandbox = model.UseSandbox;
            //_payfastCompleteSettings.AdditionalFee = model.AdditionalFee;
            //_payfastCompleteSettings.AdditionalFeePercentage = model.AdditionalFeePercentage;
            //_payfastCompleteSettings.APIBaseUri = model.APIBaseUri;
            //_payfastCompleteSettings.APIPassPhrase = model.APIPassPhrase;
            //_payfastCompleteSettings.ApiPingUrl = model.ApiPingUrl;
            //_payfastCompleteSettings.ApiTransactionDetailsUrl = model.ApiTransactionDetailsUrl;
            //_payfastCompleteSettings.ApiTransactionHistoryForDailyUrl = model.ApiTransactionHistoryForDailyUrl;
            //_payfastCompleteSettings.ApiTransactionHistoryForMonthlyUrl = model.ApiTransactionHistoryForMonthlyUrl;
            //_payfastCompleteSettings.ApiTransactionHistoryForPeriodUrl = model.ApiTransactionHistoryForPeriodUrl;
            //_payfastCompleteSettings.ApiTransactionHistoryForWeeklyUrl = model.ApiTransactionHistoryForWeeklyUrl;
            //_payfastCompleteSettings.APIVersion = model.APIVersion;
            //_payfastCompleteSettings.FormBaseUri = model.FormBaseUri;
            //_payfastCompleteSettings.FormSubnissionTestingUri = model.FormSubnissionTestingUri;
            //_payfastCompleteSettings.ApiSubmissionTestingUrl = model.ApiSubmissionTestingUrl;

            //_settingService.SaveSetting<PayFastCompleteSettings>(_payfastCompleteSettings, _storeContext.CurrentStore.Id);

            SettingsResult Rtn = _payFastCompleteService.UpdateConfigurationSettings(model);
            if (Rtn.Success)
            {
                _notificationService.SuccessNotification(_localizationService.GetResource("Admin.Plugins.Saved"), true);
            }
            else
            {
                foreach (var item in Rtn.Errors)
                {
                    _notificationService.ErrorNotification(item, true);
                }
            }


            return RedirectToAction(nameof(List));
        }
        #endregion

        #region PaymentVerification

        #endregion

    }
}
