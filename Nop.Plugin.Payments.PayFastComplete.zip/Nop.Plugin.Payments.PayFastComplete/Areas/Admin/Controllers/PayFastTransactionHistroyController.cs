﻿using Microsoft.AspNetCore.Mvc;
using Nop.Plugin.Payments.PayFastComplete.Areas.Admin.Models.TransactionalHistory;
using Nop.Plugin.Payments.PayFastComplete.Extensions;
using Nop.Plugin.Payments.PayFastComplete.Factories;
using Nop.Plugin.Payments.PayFastComplete.Infrastructure.Common.Results;
using Nop.Plugin.Payments.PayFastComplete.Services.TransactionHistoryServices;
using Nop.Plugin.Payments.PayFastComplete.Services.TransactionHistoryServices.Results;
using Nop.Services.Localization;
using Nop.Services.Messages;
using Nop.Services.Security;
using Nop.Web.Framework;
using Nop.Web.Framework.Controllers;
using System;

namespace Nop.Plugin.Payments.PayFastComplete.Areas.Admin.Controllers
{
    [Area(AreaNames.Admin)]
    public partial class PayFastTransactionHistroyController : BasePaymentController
    {
        #region Fields
        private readonly IPermissionService _permissionService;
        private readonly IPayFastTransactionHistoryService _payFastTransactionHistoryService;
        private readonly ILocalizationService _localizationService;
        private readonly INotificationService _notificationService;
        private readonly ITransactionHistoryFactory _transactionHistoryFactory;
        #endregion

        #region Cstor
        public PayFastTransactionHistroyController(
            IPermissionService permissionService,
            ITransactionHistoryFactory transactionHistoryFactory,
             INotificationService notificationService,
             ILocalizationService localizationService,
              IPayFastTransactionHistoryService payFastTransactionHistoryService
            )
        {
            _payFastTransactionHistoryService = payFastTransactionHistoryService;
            _localizationService = localizationService;
            _notificationService = notificationService;
            _transactionHistoryFactory = transactionHistoryFactory;
            _permissionService = permissionService;
        }
        #endregion

        #region Action Methods
        public virtual IActionResult List()
        {
            if (!_permissionService.Authorize(StandardPermissionProvider.ManageCustomers))
                return AccessDeniedView();

            //prepare model
            var model = _transactionHistoryFactory.PrepareTransactionHistorySearchModel(new TransactionHistroyTransactionSearchModel());

            return View(model);
        }

        [HttpPost]
        public virtual IActionResult TransactionHistroyList(TransactionHistroyTransactionSearchModel searchModel)
        {
            if (!_permissionService.Authorize(StandardPermissionProvider.ManageCustomers))
                return AccessDeniedDataTablesJson();

            //prepare model
            var model = _transactionHistoryFactory.PrepareTransactionHistoryListModel(searchModel);

            return Json(model);
        }

        [HttpGet]
        public IActionResult TransactionFullDetails(int id)
        {
            var model = _transactionHistoryFactory.PrepareTransactionHistoryFullDetails(id);
            if (model is TransactionHistoryViewModel)
            {
                return View(model);
            }
            else
            {
                _notificationService.ErrorNotification($"Error loading the Transaction Details");
                return RedirectToAction(nameof(List));
            }

        }

        public IActionResult TransactionMaintenence()
        {

            return View(new TransactionHistroyMaintenanceViewModel() { EndDatetime = DateTime.Now });
        }

        [HttpPost]
        public IActionResult TransactionMaintenence(TransactionHistroyMaintenanceViewModel model)
        {
            if (!_permissionService.Authorize(StandardPermissionProvider.ManagePaymentMethods))
            {
                return this.AccessDeniedView();
            }

            if (!base.ModelState.IsValid)
            {
                
                _notificationService.ErrorNotification("Settings NOT Been Saved. Please esure that all the require propertiess are set correctly, such as the merchant ID.", true);
                return View(model);
            }
            TransactionHistoryResult Rtn = _payFastTransactionHistoryService.ArchiveTransactionHistoryByPeriod(model.StartDatetime.GenerateTransactionalTimeStamp(), model.EndDatetime.GenerateTransactionalTimeStamp());
            if (Rtn.Success)
            {

                _notificationService.SuccessNotification(_localizationService.GetResource("Admin.Plugins.Saved"), true);
            }
            else
            {
                foreach (var item in Rtn.Errors)
                {
                    _notificationService.ErrorNotification(item, true);
                }
            }

            return RedirectToAction(nameof(List));
        }
        #endregion
    }
}
