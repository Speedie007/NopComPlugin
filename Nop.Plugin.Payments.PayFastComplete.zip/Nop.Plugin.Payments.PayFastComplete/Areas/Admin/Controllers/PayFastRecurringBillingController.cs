﻿using Microsoft.AspNetCore.Mvc;
using Nop.Services.Security;
using Nop.Web.Framework;
using Nop.Web.Framework.Controllers;
using System;
using System.Collections.Generic;
using System.Text;

namespace Nop.Plugin.Payments.PayFastComplete.Areas.Admin.Controllers
{
    [Area(AreaNames.Admin)]
    public partial class PayFastRecurringBillingController : BasePaymentController
    {

        #region Fields

        #endregion

        #region Cstor
        public PayFastRecurringBillingController()
        {

        }
        #endregion

        #region Action Methods

        public IActionResult ListSubscriptionPayments()
        {
            return View();
        }

        public IActionResult ListAdHocPayments()
        {
            return View();
        }
        #endregion
    }
}
