﻿using Microsoft.AspNetCore.Mvc;
using Nop.Web.Framework;
using Nop.Web.Framework.Components;
using System;
using System.Collections.Generic;
using System.Text;

namespace Nop.Plugin.Payments.PayFastComplete.Areas.Admin.Components
{
    public class PayFastPaymentRedirectionViewComponent : NopViewComponent
    {

        public IViewComponentResult Invoke()
        {
            return View();
        }

        public PayFastPaymentRedirectionViewComponent()
        {

        }


    }
}
