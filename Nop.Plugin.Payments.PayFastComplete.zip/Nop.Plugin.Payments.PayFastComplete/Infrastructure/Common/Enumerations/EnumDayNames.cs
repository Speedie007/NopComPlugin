﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Nop.Plugin.Payments.PayFastComplete.Infrastructure.Common.Enumerations
{
    public enum EnumDayNames
    {
        _1st = 1,
        _2nd = 2,
        _3rd = 3,
        _4th = 4,
        _5th = 5,
        _6th = 6,
        _7th = 7,
        _8th = 8,
        _9th = 9,
        _10th = 10,
        _11th = 11,
        _12th = 12,
        _13th = 13,
        _14th = 14,
        _15th = 15,
        _16th = 16,
        _17th = 17,
        _18th = 18,
        _19th = 19,
        _20th = 20,
        _21st = 21,
        _22nd = 22,
        _23rd = 23,
        _24th = 24,
        _25th = 25,
        _26th = 26,
        _27th = 27,
        _28th = 28,
        _29th = 29,
        _30th = 30,
        _31st = 31

    }
}
