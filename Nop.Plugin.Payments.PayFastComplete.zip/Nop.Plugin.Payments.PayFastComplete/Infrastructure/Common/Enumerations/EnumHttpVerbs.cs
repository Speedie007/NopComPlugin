﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Nop.Plugin.Payments.PayFastComplete.Infrastructure.Common.Enumerations
{
    public enum EnumHttpVerbs
    {
        GET,
        POST,
        PUT,
        DELETE,
        PATCH
    }
}
