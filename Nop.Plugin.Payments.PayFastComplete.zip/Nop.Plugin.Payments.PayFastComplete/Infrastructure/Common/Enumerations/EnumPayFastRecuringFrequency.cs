﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Nop.Plugin.Payments.PayFastComplete.Infrastructure.Common.Enumerations
{
    public enum EnumPayFastRecuringFrequency
    {
        UnDefinedFrequency = 0,
        Monthly = 3,
        Quarterly = 4,
        Biannual = 5,
        Annual = 6
    }
}
