﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Nop.Plugin.Payments.PayFastComplete.Infrastructure.Common.Results
{
    public interface IResult
    {
        void AddError(string error);
        IList<string> Errors { get; set; }
    }
}
