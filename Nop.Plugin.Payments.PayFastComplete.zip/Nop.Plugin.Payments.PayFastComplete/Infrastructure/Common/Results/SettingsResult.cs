﻿using Nop.Plugin.Payments.PayFastComplete.Settings;
using System;
using System.Collections.Generic;
using System.Text;

namespace Nop.Plugin.Payments.PayFastComplete.Infrastructure.Common.Results
{
    public class SettingsResult : Result
    {
        public PayFastCompleteSettings SettingsProcessed { get; set; }
    }
}
