﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.Json;

namespace Nop.Plugin.Payments.PayFastComplete.Infrastructure.Common.Results
{
    public abstract class Result : IResult
    {
        public JsonSerializerOptions JsonSerializerOptions { get; } = new JsonSerializerOptions
        {
            IgnoreNullValues = true,
            // WriteIndented = true,
            PropertyNameCaseInsensitive = true,
           // PropertyNamingPolicy = JsonNamingPolicy.CamelCase,
            AllowTrailingCommas = true
        };

        public Result()
        {
            Errors = new List<string>();
        }
        /// <summary>
        /// Gets a value indicating whether request has been completed successfully
        /// </summary>
        public bool Success => !Errors.Any();

        /// <summary>
        /// Add error
        /// </summary>
        /// <param name="error">Error</param>
        public virtual void AddError(string error)
        {
            Errors.Add(error);
        }

        /// <summary>
        /// Errors
        /// </summary>
        public virtual IList<string> Errors { get; set; }

        /// <summary>
        /// TRansfers any other Errors that may have been Encountered else in the application logic with any that already exist in this result.
        /// </summary>
        /// <param name="OtherErrors"></param>
        public virtual void CombineError(IList<string> OtherErrors)
        {
            foreach (var error in OtherErrors)
            {
                Errors.Add(error);
            }
        }

    }
}
