﻿using Nop.Core;
using Nop.Web.Framework.Models;
using System;
using System.Collections.Generic;
using System.Text;

namespace Nop.Plugin.Payments.PayFastComplete.Infrastructure.Common.Results
{
    public class CRUDResult<TEntity> : Result where TEntity : BaseEntity
    {
        public TEntity ProccesedCRUDEntity { get; set; }
        public List<TEntity> ProccesedCRUDEntities { get; set; }
    }
}
