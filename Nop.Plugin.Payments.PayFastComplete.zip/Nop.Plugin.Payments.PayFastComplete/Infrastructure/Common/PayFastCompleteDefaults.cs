﻿

using System;

namespace Nop.Plugin.Payments.PayFastComplete.Infrastructure.Common
{
    public static class PayFastCompleteDefaults
    {
        public const string SystemName = "Payments.PayFastComplete";

        public static int   ApiTimeOutValue = 60;
        public static string SignatureFormFieldKey = "signature";
        public static string SecurityPassPhraseKey = "passphrase";

        public const string OrderProcessing_COMPLETE = "COMPLETE";
        public const string OrderProcessing_CANCELED = "CANCELLED";

        public static string FormSubmissionBaseUri = "www.payfast.co.za";
        public static string FormSubnissionTestingUri = "sandbox.payfast.co.za";
        public static string ApiSubmissionBaseUri = "api.payfast.co.za";
        public static string ApiSubmissionTestingUrl = "testing=true";
        public static string ApiVersion = "v1";

        public static string ApiPingUrl = "/ping";
        public static string ApiTransactionHistoryForPeriodUrl = "/transactions/history";
        public static string ApiTransactionHistoryForDailyUrl = "/transactions/history/daily";
        public static string ApiTransactionHistoryForWeeklyUrl = "/transactions/history/weekly";
        public static string ApiTransactionHistoryForMonthlyUrl = "/transactions/history/monthly";
        public static string ApiTransactionDetailsUrl = "/process/query";

        #region Recurring Bill Ad Hoc API End Points
        public static string ApiRecurringBilling_ADHOC_CHARGE_SubscriptionUrlDefault = "/subscriptions/{0}/adhoc";
        public static string ApiRecurringBilling_COMMON_FETCH_SubscriptionUrlDefault = "/subscriptions/{0}/fetch";
        public static string ApiRecurringBilling_COMMON_CANCEL_SubscriptionUrlDefault = "/subscriptions/{0}/cancel";
        public static string ApiRecurringBilling_NORMAL_PAUSE_SubscriptionUrlDefault = "/subscriptions/{0}/pause";
        public static string ApiRecurringBilling_NORMAL_UNPAUSE_SubscriptionUrlDefault = "/subscriptions/{0}/unpause";
        public static string ApiRecurringBilling_NORMAL_UPDATE_SubscriptionUrlDefault = "/subscriptions/{0}/update";
        #endregion


        #region Processing Form Defaults
        public static string FormProcessingReturnUrl = "";
        public static string FormProcessingCancelUrl = "";
        public static string FormProcessingNotifyUrl = "PaymentGateway/PayFastInstantTransactionNotification";
        #endregion

        public static decimal SplitPaymentMinimum = 15;
        public static decimal SplitPaymentMaximum = 500;
        public static decimal SplitPaymentAboveThresholdPercentage = Convert.ToDecimal(1.75);
        public static decimal SplitPaymentAboveThresholdAmount = 500;
        public static bool SplitPaymentIsSplitPaymentActive = false;
        public static bool SplitPaymentMustIncludeShippingCosts = false;

        #region HTTP API Call Statuses
        /// <summary>
        /// <para>Constant value = "success", used to compare the status field on the returned data from an Api Call made  to PayFast.</para>
        /// </summary>
        public const string API_CALL_RESPONSE_SUCCESS = "success";
        /// <summary>
        /// <para>Constant value = "failed", used to compare the status field on the returned data from an Api Call made  to PayFast.</para>
        /// </summary>
        public const string API_CALL_RESPONSE_FAILED = "failed";
        #endregion
        /// <summary>
        /// <para>Constant value = "failed", used to compare the status field on the returned data from an Api Call made  to PayFast.</para>
        /// </summary>
        public const string API_CALL_RESPONSE_ERROR = "error";

        #region Task Scheduler
        public static string TaskSchedulerNameSpace = "Nop.Plugin.Payments.PayFastComplete.TaskScheduler";
        public static string SystemPackageName = "Nop.Plugin.Payments.PayFastComplete";
        public static string TransactionHistoryTaskClassName = "SyncTransactionHistoryTask";
        public static string RecurringPaymentTaskClassName = "RecurringPaymentTask";
        #endregion

    }
}
