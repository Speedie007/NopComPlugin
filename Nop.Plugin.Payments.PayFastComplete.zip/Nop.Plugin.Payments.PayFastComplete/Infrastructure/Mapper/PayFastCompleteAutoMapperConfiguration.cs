﻿using AutoMapper;
using Nop.Core.Infrastructure.Mapper;
using Nop.Plugin.Payments.PayFastComplete.Areas.Admin.Models.Configuration;
using Nop.Plugin.Payments.PayFastComplete.Areas.Admin.Models.TransactionalHistory;
using Nop.Plugin.Payments.PayFastComplete.Domain.TransactionalHistory;
using Nop.Plugin.Payments.PayFastComplete.Services.TransactionHistoryServices.Models;
using Nop.Plugin.Payments.PayFastComplete.Settings;

namespace Nop.Plugin.Payments.PayFastComplete.Infrastructure.Mapper
{
    public class PayFastCompleteAutoMapperConfiguration : Profile, IOrderedMapperProfile
    {

        public PayFastCompleteAutoMapperConfiguration()
        {
            CreateEventConfigurationMaps();
        }

        protected virtual void CreateEventConfigurationMaps()
        {
            //CreateMap<,PayFastTransactionHistoryRecord >
            #region Transactional History Extraction
            CreateMap<PayFastTransactionHistoryDataExtractionRecordModel, PayFastTransactionHistoryRecord>();
            CreateMap<PayFastTransactionHistoryDataExtractionRecordModel, TransactionalSearchCritearia>();
            CreateMap<PayFastTransactionHistoryRecord, TransactionHistoryViewModel>();
            #endregion

            CreateMap<SecuritySettingsViewModel, PayFastCompleteSettings>();
            CreateMap<AdditionalChargesViewModel, PayFastCompleteSettings>();
            CreateMap<ConfigurationTestingViewModel, PayFastCompleteSettings>();
            CreateMap<UrlConfigurationViewModel, PayFastCompleteSettings>()
                .ForMember(x => x.ApiRecurringBilling_ADHOC_CHARGE_SubscriptionUrl, options => options.MapFrom(x => x.ApiRecurringBillingAdHocChargeUrl))
                .ForMember(x => x.ApiRecurringBilling_COMMON_CANCEL_SubscriptionUrl, options => options.MapFrom(x => x.ApiRecurringBillingCommonCancelUrl))
                .ForMember(x => x.ApiRecurringBilling_COMMON_FETCH_SubscriptionUrl, options => options.MapFrom(x => x.ApiRecurringBillingCommonFetchUrl))
                .ForMember(x => x.ApiRecurringBilling_NORMAL_PAUSE_SubscriptionUrl, options => options.MapFrom(x => x.ApiRecurringBillingNormalPauseUrl))
                .ForMember(x => x.ApiRecurringBilling_NORMAL_UNPAUSE_SubscriptionUrl, options => options.MapFrom(x => x.ApiRecurringBillingNormalUnpauseUrl))
                .ForMember(x => x.ApiRecurringBilling_NORMAL_UPDATE_SubscriptionUrl, options => options.MapFrom(x => x.ApiRecurringBillingNormalUpdateUrl));
            CreateMap<SpiltPaymentsViewModel, PayFastCompleteSettings>()
                .ForMember(x=>x.SplitPayment_RecievingMerchantId, options => options.MapFrom(x=>x.RecievingMerchantId))
                .ForMember(x => x.SplitPayment_Percentage, options => options.MapFrom(x => x.Percentage))
                .ForMember(x => x.SplitPayment_MustIncludeShippingCosts, options => options.MapFrom(x => x.MustIncludeShippingCosts))
                .ForMember(x => x.SplitPayment_MinimumAmount, options => options.MapFrom(x => x.MinimumAmount))
                .ForMember(x => x.SplitPayment_MaximumAmount, options => options.MapFrom(x => x.MaximumAmount))
                .ForMember(x => x.SplitPayment_Amount, options => options.MapFrom(x => x.Amount))
                .ForMember(x => x.SplitPayment_IsSplitPaymentActive, options => options.MapFrom(x => x.IsSplitPaymentActive));
        }
        public int Order => 2;
    }
}
