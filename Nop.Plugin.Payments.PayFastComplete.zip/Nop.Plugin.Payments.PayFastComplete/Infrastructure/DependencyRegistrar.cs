﻿using Autofac;
using Nop.Core.Configuration;
using Nop.Core.Infrastructure;
using Nop.Core.Infrastructure.DependencyManagement;
using Nop.Plugin.Payments.PayFastComplete.Factories;
using Nop.Plugin.Payments.PayFastComplete.Services;
using Nop.Plugin.Payments.PayFastComplete.Services.HttpClientServices.Models.FromProcessing;
using Nop.Plugin.Payments.PayFastComplete.Services.PayFastConfigurationServices;
using Nop.Plugin.Payments.PayFastComplete.Services.PaymentProcessingVerificationServices;
using Nop.Plugin.Payments.PayFastComplete.Services.RecurringPaymentsServices;
using Nop.Plugin.Payments.PayFastComplete.Services.TransactionHistoryServices;
using System;
using System.Collections.Generic;
using System.Text;

namespace Nop.Plugin.Payments.PayFastComplete.Infrastructure
{
    public class DependencyRegistrar : IDependencyRegistrar
    {
        public void Register(ContainerBuilder builder, ITypeFinder typeFinder, NopConfig config)
        {
            ////Services
            builder.RegisterType<PayFastCompleteService>().As<IPayFastCompleteService>().InstancePerLifetimeScope();
            builder.RegisterType<PayFastFormPaymentProcessorService>().As<IPayFastFormPaymentProcessorService>().InstancePerLifetimeScope();
            builder.RegisterType<PaymentProcessingVerificationService>().As<IPaymentProcessingVerificationService>().InstancePerLifetimeScope();
            builder.RegisterType<PayFastConfigurationService>().As<IPayFastConfigurationService>().InstancePerLifetimeScope();
            builder.RegisterType<PayFastTransactionHistoryService>().As<IPayFastTransactionHistoryService>().InstancePerLifetimeScope();
            builder.RegisterType<RecurringPaymentTaskService>().As<IRecurringPaymentTaskService>().InstancePerLifetimeScope();
            builder.RegisterType<RecurringBillingService>().As<IRecurringBillingService>().InstancePerLifetimeScope();
            //IRecurringBillingService

            ////Factories
            builder.RegisterType<PayFastConfigurationFactory>().As<IPayFastConfigurationFactory>().InstancePerLifetimeScope();
            builder.RegisterType<PayFastPaymentConfigurationFactory>().As<IPayFastPaymentConfigurationFactory>().InstancePerLifetimeScope();
            builder.RegisterType<TransactionHistoryFactory>().As<ITransactionHistoryFactory>().InstancePerLifetimeScope();
            //




        }

        public int Order => 101;
    }
}
