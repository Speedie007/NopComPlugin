﻿using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Routing;
using Nop.Plugin.Payments.PayFastComplete.Infrastructure.Common;
using Nop.Web.Framework;
using Nop.Web.Framework.Mvc.Routing;

namespace Nop.Plugin.Payments.PayFastComplete.Infrastructure.Startup
{
    public class PayFastCompleteRouteProvider : IRouteProvider
    {
        public int Priority => 0;

        public void RegisterRoutes(IEndpointRouteBuilder endpointRouteBuilder)
        {
            endpointRouteBuilder.MapControllerRoute($"Plugin.{PayFastCompleteDefaults.SystemName}.PayFastInstantTransactionNotification",
                "PaymentGateway/PayFastInstantTransactionNotification",
                new { controller = "PayFastPaymentProcessing", action = "PayFastResultHandler" });

            //endpointRouteBuilder.MapAreaControllerRoute(
            //    name: $"Plugin.{PayFastCompleteDefaults.SystemName}.Documentation",
            //    areaName: AreaNames.Admin,
            //    pattern: "Admin/Plugin/List",
            //    defaults: new
            //    {
            //        controller = "PayFastCompleteConfiguration",
            //        action = "PayFastResultHandler"
            //    });

        }
    }
}
