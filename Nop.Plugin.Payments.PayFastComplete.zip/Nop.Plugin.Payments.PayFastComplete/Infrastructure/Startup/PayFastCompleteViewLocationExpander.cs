﻿using Microsoft.AspNetCore.Mvc.Razor;
using Nop.Plugin.Payments.PayFastComplete.Infrastructure.Common;
using System.Collections.Generic;
using System.Linq;

namespace Nop.Plugin.Payments.PayFastComplete.Infrastructure.Startup
{
    public class PayFastCompleteViewLocationExpander : IViewLocationExpander
    {
        public void PopulateValues(ViewLocationExpanderContext context)
        {
        }

        public IEnumerable<string> ExpandViewLocations(ViewLocationExpanderContext context, IEnumerable<string> viewLocations)
        {
            if (context.AreaName == "Admin")
            {
                viewLocations = new[] { $"/Plugins/{PayFastCompleteDefaults.SystemName}/Areas/Admin/Views/{context.ControllerName}/{context.ViewName}.cshtml" }.Concat(viewLocations);
                viewLocations = new[] { $"/Plugins/{PayFastCompleteDefaults.SystemName}/Areas/Admin/Views/Shared/Components/{context.ControllerName}/{context.ViewName}.cshtml" }.Concat(viewLocations);
                viewLocations = new[] { $"/Plugins/{PayFastCompleteDefaults.SystemName}/Areas/Admin/Views/Shared/{context.ViewName}.cshtml" }.Concat(viewLocations);
            }
            else
            {
                viewLocations = new[] { $"/Plugins/{PayFastCompleteDefaults.SystemName}/Views/{context.ControllerName}/{context.ViewName}.cshtml" }.Concat(viewLocations);
                viewLocations = new[] { $"/Plugins/{PayFastCompleteDefaults.SystemName}/Views/Shared/Components/{context.ControllerName}/{context.ViewName}.cshtml" }.Concat(viewLocations);
                viewLocations = new[] { $"/Plugins/{PayFastCompleteDefaults.SystemName}/Views/Shared/{context.ViewName}.cshtml" }.Concat(viewLocations);
            }

            return viewLocations;
        }
    }
}