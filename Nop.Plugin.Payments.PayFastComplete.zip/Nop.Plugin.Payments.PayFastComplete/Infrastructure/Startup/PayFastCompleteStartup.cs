﻿using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Razor;
using Microsoft.AspNetCore.Server.Kestrel.Core;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Nop.Core.Infrastructure;
using Nop.Plugin.Payments.PayFastComplete.Services.HttpClientServices;
using Nop.Plugin.Payments.PayFastComplete.Services.IPayFastApiClientServices;

namespace Nop.Plugin.Payments.PayFastComplete.Infrastructure.Startup
{
    public class PayFastCompleteStartup : INopStartup
    {
        public int Order => 205;

        public void Configure(IApplicationBuilder application)
        {

        }

        public void ConfigureServices(IServiceCollection services, IConfiguration configuration)
        {
            
            //services.AddControllers()
            //        .ConfigureApiBehaviorOptions(options =>
            //        {
            //            options.SuppressConsumesConstraintForFormFileParameters = true;
            //            options.SuppressInferBindingSourcesForParameters = true;
            //            options.SuppressModelStateInvalidFilter = true;
            //            options.SuppressMapClientErrors = true;
            //            options.ClientErrorMapping[StatusCodes.Status404NotFound].Link =
            //                "https://httpstatuses.com/404";
            //        });
            services.Configure(delegate (KestrelServerOptions options)
            {
                options.AllowSynchronousIO = true;
            });
            services.Configure(delegate (IISServerOptions options)
            {
                options.AllowSynchronousIO = true;
            });

            services.Configure<RazorViewEngineOptions>(options =>
            {
                options.ViewLocationExpanders.Add(new PayFastCompleteViewLocationExpander());
            });

            services.AddHttpClient<IPayFastApiClientService, PayFastApiClientService>();
        }
    }
}
