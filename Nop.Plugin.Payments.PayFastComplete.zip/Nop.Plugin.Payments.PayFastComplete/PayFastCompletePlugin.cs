﻿using LinqToDB.Common;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Routing;
using Nop.Core;
using Nop.Core.Domain.Orders;
using Nop.Core.Domain.Tasks;
using Nop.Plugin.Payments.PayFastComplete.Infrastructure.Common;
using Nop.Plugin.Payments.PayFastComplete.Services.HttpClientServices.Models.FromProcessing;
using Nop.Plugin.Payments.PayFastComplete.Services.IPayFastApiClientServices;
using Nop.Plugin.Payments.PayFastComplete.Services.PayFastApiClientServices.Models.Api.Results.SubscriptionCommon;
using Nop.Plugin.Payments.PayFastComplete.Settings;
using Nop.Services.Configuration;
using Nop.Services.Localization;
using Nop.Services.Payments;
using Nop.Services.Plugins;
using Nop.Services.Tasks;
using Nop.Web.Framework;
using Nop.Web.Framework.Menu;
using System;
using System.Collections.Generic;

namespace Nop.Plugin.Payments.PayFastComplete
{

    /// <summary>
    /// 
    /// </summary>
    public class PayFastCompletePlugin : BasePlugin, IAdminMenuPlugin, IPaymentMethod
    {
        #region Fields
        private readonly ILocalizationService _localizationService;
        private readonly IPaymentService _paymentService;
        private readonly ISettingService _settingService;
        private readonly IWebHelper _webHelper;
        private readonly PayFastCompleteSettings _payFastCompleteSettings;
        private readonly IStoreContext _storeContext;
        private readonly IScheduleTaskService _scheduleTaskService;
        private readonly IPayFastFormPaymentProcessorService _payFastFormPaymentProcessorService;
        private readonly IPayFastApiClientService _payFastApiClientService;
        #endregion

        #region Cstor

        /// <summary>
        /// 
        /// </summary>
        /// <param name="localizationService"></param>
        /// <param name="paymentService"></param>
        /// <param name="settingService"></param>
        /// <param name="webHelper"></param>
        /// <param name="payFastCompleteSettings"></param>
        /// <param name="workContext"></param>
        /// <param name="storeContext"></param>
        /// <param name="httpContextAccessor"></param>
        /// <param name="payFastPaymentConfigurationFactory"></param>
        /// <param name="payFastCompleteService"></param>
        public PayFastCompletePlugin(
            ILocalizationService localizationService,
            IPaymentService paymentService,
            ISettingService settingService,
            IWebHelper webHelper,
            PayFastCompleteSettings payFastCompleteSettings,
            IStoreContext storeContext,
            IPayFastApiClientService payFastApiClientService,
            IPayFastFormPaymentProcessorService payFastFormPaymentProcessorService,
            IScheduleTaskService scheduleTaskService
            )
        {
            _scheduleTaskService = scheduleTaskService;
            _payFastFormPaymentProcessorService = payFastFormPaymentProcessorService;
            _payFastApiClientService = payFastApiClientService;
            _localizationService = localizationService;
            _paymentService = paymentService;
            _settingService = settingService;
            _webHelper = webHelper;
            _payFastCompleteSettings = payFastCompleteSettings;
            _storeContext = storeContext;


        }
        #endregion

        #region Payment Methods

        /// <summary>
        /// Process a payment
        /// </summary>
        /// <param name="processPaymentRequest">Payment info required for an order processing</param>
        /// <returns>Process payment result</returns>
        public ProcessPaymentResult ProcessPayment(ProcessPaymentRequest processPaymentRequest)
        {

            return new ProcessPaymentResult();
        }

        /// <summary>
        /// Post process payment (used by payment gateways that require redirecting to a third-party URL)
        /// </summary>
        /// <param name="postProcessPaymentRequest">Payment info required for an order processing</param>
        public void PostProcessPayment(PostProcessPaymentRequest postProcessPaymentRequest)
        {

            //_genericAttributeService.SaveAttribute<string>(
            //    postProcessPaymentRequest.Order, 
            //    postProcessPaymentRequest.Order.Id.ToString(),"", _storeContext.CurrentStore.Id);

            _payFastFormPaymentProcessorService.ProcessOnceOffOrInitialRecurringOrderPayment(postProcessPaymentRequest.Order);

        }

        /// <summary>
        /// Returns a value indicating whether payment method should be hidden during checkout
        /// </summary>
        /// <param name="cart">Shoping cart</param>
        /// <returns>true - hide; false - display.</returns>
        public bool HidePaymentMethod(IList<ShoppingCartItem> cart)
        {
            //you can put any logic here
            //for example, hide this payment method if all products in the cart are downloadable
            //or hide this payment method if current customer is from certain country
            return false;
        }

        /// <summary>
        /// Gets additional handling fee
        /// </summary>
        /// <returns>Additional handling fee</returns>
        public decimal GetAdditionalHandlingFee(IList<ShoppingCartItem> cart)
        {

            return _paymentService.CalculateAdditionalFee(cart,
                _payFastCompleteSettings.AdditionalFee, _payFastCompleteSettings.AdditionalFeePercentage);
        }

        /// <summary>
        /// Captures payment
        /// </summary>
        /// <param name="capturePaymentRequest">Capture payment request</param>
        /// <returns>Capture payment result</returns>
        public CapturePaymentResult Capture(CapturePaymentRequest capturePaymentRequest)
        {
            var result = new CapturePaymentResult();
            //result.AddError("Capture method not supported");
            return result;
        }

        /// <summary>
        /// Refunds a payment
        /// </summary>
        /// <param name="refundPaymentRequest">Request</param>
        /// <returns>Result</returns>
        public RefundPaymentResult Refund(RefundPaymentRequest refundPaymentRequest)
        {

            var result = new RefundPaymentResult();
            result.AddError("Refund method not supported");
            return result;
        }


        /// <summary>
        /// Voids a payment
        /// </summary>
        /// <param name="voidPaymentRequest">Request</param>
        /// <returns>Result</returns>
        public VoidPaymentResult Void(VoidPaymentRequest voidPaymentRequest)
        {
            var result = new VoidPaymentResult();
            result.AddError("Void method not supported");
            return result;
        }

        /// <summary>
        /// Process recurring payment
        /// </summary>
        /// <param name="processPaymentRequest">Payment info required for an order processing</param>
        /// <returns>Process payment result</returns>
        public ProcessPaymentResult ProcessRecurringPayment(ProcessPaymentRequest processPaymentRequest)
        {

            var result = new ProcessPaymentResult();
            //result.AddError("Recurring Payment method not supported");
            ///processPaymentRequest.
            return result;
        }

        /// <summary>
        /// Cancels a recurring payment
        /// </summary>
        /// <param name="cancelPaymentRequest">Request</param>
        /// <returns>Result</returns>
        public CancelRecurringPaymentResult CancelRecurringPayment(CancelRecurringPaymentRequest cancelPaymentRequest)
        {
            //always success
            CancelRecurringPaymentResult result = new CancelRecurringPaymentResult();

            if (!cancelPaymentRequest.Order.SubscriptionTransactionId.IsNullOrEmpty())
            {

                StandardSuccsessFailurePayFastApiResult Rtn = _payFastApiClientService.CancelReccuringPayment(cancelPaymentRequest.Order.SubscriptionTransactionId);

                if (!Rtn.Success)
                {
                    foreach (var item in Rtn.Errors)
                    {
                        result.AddError(item);
                    }
                }

            }
            else
            {
                result.AddError($"Unable to retirieve the Subscription Token for order number : {cancelPaymentRequest.Order.Id}, cancel on PayFast System unsuccessful.");
            }
            return result;
        }

        /// <summary>
        /// Gets a value indicating whether customers can complete a payment after order is placed but not completed (for redirection payment methods)
        /// </summary>
        /// <param name="order">Order</param>
        /// <returns>Result</returns>
        public bool CanRePostProcessPayment(Order order)
        {
            if (order == null)
                throw new ArgumentNullException("order");

            return order.OrderStatus == OrderStatus.Pending;
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="form"></param>
        /// <returns></returns>
        public IList<string> ValidatePaymentForm(IFormCollection form)
        {
            return new List<string>();
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="form"></param>
        /// <returns></returns>
        public ProcessPaymentRequest GetPaymentInfo(IFormCollection form)
        {
            return new ProcessPaymentRequest();
        }

        /// <summary>
        /// 
        /// </summary>
        /// <returns></returns>
        public string GetPublicViewComponentName()
        {
            return "PayFastPaymentRedirection";
        }
        #endregion

        #region Payment Properties
        /// <summary>
        /// Gets a value indicating whether capture is supported
        /// </summary>
        public bool SupportCapture
        {
            get { return false; }
        }

        /// <summary>
        /// Gets a value indicating whether partial refund is supported
        /// </summary>
        public bool SupportPartiallyRefund
        {
            get { return false; }
        }

        /// <summary>
        /// Gets a value indicating whether refund is supported
        /// </summary>
        public bool SupportRefund
        {
            get { return false; }
        }

        /// <summary>
        /// Gets a value indicating whether void is supported
        /// </summary>
        public bool SupportVoid
        {
            get { return false; }
        }

        /// <summary>
        /// Gets a recurring payment type of payment method
        /// </summary>
        public RecurringPaymentType RecurringPaymentType
        {
            get { return RecurringPaymentType.Automatic; }
        }

        /// <summary>
        /// Gets a payment method type
        /// </summary>
        public PaymentMethodType PaymentMethodType
        {
            get { return PaymentMethodType.Redirection; }
        }

        /// <summary>
        /// Gets a value indicating whether we should display a payment information page for this plugin
        /// </summary>
        public bool SkipPaymentInfo
        {
            get { return true; }
        }

        /// <summary>
        /// Gets a payment method description that will be displayed on checkout pages in the public store
        /// </summary>
        public string PaymentMethodDescription
        {
            get { return _localizationService.GetResource($"Plugins.{PayFastCompleteDefaults.SystemName}.PaymentMethodDescription"); }
        }

        #endregion

        #region Configuration

        #region Installation
        /// <summary>
        /// 
        /// </summary>
        public override void Install()
        {
            //settings
            _settingService.SaveSetting(new PayFastCompleteSettings
            {
                ApiTimeOutValue = PayFastCompleteDefaults.ApiTimeOutValue,
                UseSandbox = true,
                APIBaseUri = PayFastCompleteDefaults.ApiSubmissionBaseUri,
                APIVersion = PayFastCompleteDefaults.ApiVersion,
                FormBaseUri = PayFastCompleteDefaults.FormSubmissionBaseUri,
                APIPassPhrase = "",
                ApiPingUrl = PayFastCompleteDefaults.ApiPingUrl,
                ApiTransactionHistoryForPeriodUrl = PayFastCompleteDefaults.ApiTransactionHistoryForPeriodUrl,
                ApiTransactionHistoryForDailyUrl = PayFastCompleteDefaults.ApiTransactionHistoryForDailyUrl,
                ApiTransactionHistoryForWeeklyUrl = PayFastCompleteDefaults.ApiTransactionHistoryForWeeklyUrl,
                ApiTransactionHistoryForMonthlyUrl = PayFastCompleteDefaults.ApiTransactionHistoryForMonthlyUrl,
                AdditionalFee = 0,
                AdditionalFeePercentage = false,
                MerchantId = "",
                MerchantKey = "",
                ApiTransactionDetailsUrl = PayFastCompleteDefaults.ApiTransactionDetailsUrl,
                ApiSubmissionTestingUrl = PayFastCompleteDefaults.ApiSubmissionTestingUrl,
                FormSubmissionTestingUri = PayFastCompleteDefaults.FormSubnissionTestingUri,

                SplitPayment_RecievingMerchantId = "",
                SplitPayment_Percentage = PayFastCompleteDefaults.SplitPaymentAboveThresholdPercentage,
                SplitPayment_Amount = PayFastCompleteDefaults.SplitPaymentAboveThresholdAmount,
                SplitPayment_MaximumAmount = PayFastCompleteDefaults.SplitPaymentMaximum,
                SplitPayment_MinimumAmount = PayFastCompleteDefaults.SplitPaymentMinimum,
                SplitPayment_IsSplitPaymentActive = PayFastCompleteDefaults.SplitPaymentIsSplitPaymentActive,
                SplitPayment_MustIncludeShippingCosts = PayFastCompleteDefaults.SplitPaymentMustIncludeShippingCosts,

                ApiRecurringBilling_ADHOC_CHARGE_SubscriptionUrl = PayFastCompleteDefaults.ApiRecurringBilling_ADHOC_CHARGE_SubscriptionUrlDefault,
                ApiRecurringBilling_COMMON_FETCH_SubscriptionUrl = PayFastCompleteDefaults.ApiRecurringBilling_COMMON_FETCH_SubscriptionUrlDefault,
                ApiRecurringBilling_COMMON_CANCEL_SubscriptionUrl = PayFastCompleteDefaults.ApiRecurringBilling_COMMON_CANCEL_SubscriptionUrlDefault,
                ApiRecurringBilling_NORMAL_PAUSE_SubscriptionUrl = PayFastCompleteDefaults.ApiRecurringBilling_NORMAL_PAUSE_SubscriptionUrlDefault,
                ApiRecurringBilling_NORMAL_UNPAUSE_SubscriptionUrl = PayFastCompleteDefaults.ApiRecurringBilling_NORMAL_UNPAUSE_SubscriptionUrlDefault,
                ApiRecurringBilling_NORMAL_UPDATE_SubscriptionUrl = PayFastCompleteDefaults.ApiRecurringBilling_NORMAL_UPDATE_SubscriptionUrlDefault,
            }, _storeContext.CurrentStore.Id);

            //locales
            _localizationService.AddOrUpdatePluginLocaleResource($"Plugins.{PayFastCompleteDefaults.SystemName}.Fields.ApiTimeOutValue", "API Time-Out");
            _localizationService.AddOrUpdatePluginLocaleResource($"Plugins.{PayFastCompleteDefaults.SystemName}.Fields.ApiTimeOutValue.Hint", "Amount of time to wiat before the Api Request Times Out in seconds(Default is 60 sec).");
            _localizationService.AddOrUpdatePluginLocaleResource($"Plugins.{PayFastCompleteDefaults.SystemName}.Fields.AdditionalFee", "Additional fee");
            _localizationService.AddOrUpdatePluginLocaleResource($"Plugins.{PayFastCompleteDefaults.SystemName}.Fields.AdditionalFee.Hint", "Enter additional fee to charge your customers.");
            _localizationService.AddOrUpdatePluginLocaleResource($"Plugins.{PayFastCompleteDefaults.SystemName}.Fields.AdditionalFeePercentage", "Additional fee. Use percentage");
            _localizationService.AddOrUpdatePluginLocaleResource($"Plugins.{PayFastCompleteDefaults.SystemName}.Fields.AdditionalFeePercentage.Hint", "Determines whether to apply a percentage additional fee to the order total. If not enabled, a fixed value is used.");
            _localizationService.AddOrUpdatePluginLocaleResource($"Plugins.{PayFastCompleteDefaults.SystemName}.Fields.MerchantId", "Merchant ID");
            _localizationService.AddOrUpdatePluginLocaleResource($"Plugins.{PayFastCompleteDefaults.SystemName}.Fields.MerchantId.Hint", "Specify merchant ID.");
            _localizationService.AddOrUpdatePluginLocaleResource($"Plugins.{PayFastCompleteDefaults.SystemName}.Fields.MerchantKey", "Merchant key");
            _localizationService.AddOrUpdatePluginLocaleResource($"Plugins.{PayFastCompleteDefaults.SystemName}.Fields.MerchantKey.Hint", "Specify merchant key.");
            _localizationService.AddOrUpdatePluginLocaleResource($"Plugins.{PayFastCompleteDefaults.SystemName}.Fields.UseSandbox", "Use Sandbox");
            _localizationService.AddOrUpdatePluginLocaleResource($"Plugins.{PayFastCompleteDefaults.SystemName}.Fields.UseSandbox.Hint", "Check to enable Sandbox (testing environment).");
            _localizationService.AddOrUpdatePluginLocaleResource($"Plugins.{PayFastCompleteDefaults.SystemName}.RedirectionTip", "You will be redirected to PayFast site to complete the order.");
            _localizationService.AddOrUpdatePluginLocaleResource($"Plugins.{PayFastCompleteDefaults.SystemName}.PaymentMethodDescription", "You will be redirected to PayFast site to complete the order.");
            _localizationService.AddOrUpdatePluginLocaleResource($"Plugins.{PayFastCompleteDefaults.SystemName}.Fields.APIBaseUri", "Api Base Uri");
            _localizationService.AddOrUpdatePluginLocaleResource($"Plugins.{PayFastCompleteDefaults.SystemName}.Fields.APIBaseUri.Hint", "Base Url/Uri to connect to the PayFast Api.");
            _localizationService.AddOrUpdatePluginLocaleResource($"Plugins.{PayFastCompleteDefaults.SystemName}.Fields.APIVersion", "Api Version");
            _localizationService.AddOrUpdatePluginLocaleResource($"Plugins.{PayFastCompleteDefaults.SystemName}.Fields.APIVersion.Hint", "Defines the PayFast Api version to use (this could change over time.)");
            _localizationService.AddOrUpdatePluginLocaleResource($"Plugins.{PayFastCompleteDefaults.SystemName}.Fields.FormBaseUri", "From Base Uri.");
            _localizationService.AddOrUpdatePluginLocaleResource($"Plugins.{PayFastCompleteDefaults.SystemName}.Fields.FormBaseUri.Hint", "Is the Url/Uri that is used for ITDN Payments. (Direct or normal adhoc payments)");
            _localizationService.AddOrUpdatePluginLocaleResource($"Plugins.{PayFastCompleteDefaults.SystemName}.Fields.ApiPingUrl", "Testing Url (Ping).");
            _localizationService.AddOrUpdatePluginLocaleResource($"Plugins.{PayFastCompleteDefaults.SystemName}.Fields.ApiPingUrl.Hint", "Url/Uri connection point used to test connection tot he API.");
            _localizationService.AddOrUpdatePluginLocaleResource($"Plugins.{PayFastCompleteDefaults.SystemName}.Fields.ApiTransactionHistoryForPeriodUrl", "Period End Point");
            _localizationService.AddOrUpdatePluginLocaleResource($"Plugins.{PayFastCompleteDefaults.SystemName}.Fields.ApiTransactionHistoryForPeriodUrl.Hint", "Url/Uri end-point to get the transactional history for a specified period from the API. Retruns the data in comma-delimited fields or CSV format");
            _localizationService.AddOrUpdatePluginLocaleResource($"Plugins.{PayFastCompleteDefaults.SystemName}.Fields.ApiTransactionHistoryForDailyUrl", "Daily End Point");
            _localizationService.AddOrUpdatePluginLocaleResource($"Plugins.{PayFastCompleteDefaults.SystemName}.Fields.ApiTransactionHistoryForDailyUrl.Hint", "Url/Uri end-point to get the daily transactions from the API. Retruns the data in comma-delimited fields or CSV format");
            _localizationService.AddOrUpdatePluginLocaleResource($"Plugins.{PayFastCompleteDefaults.SystemName}.Fields.ApiTransactionHistoryForWeeklyUrl", "Weekly End Point");
            _localizationService.AddOrUpdatePluginLocaleResource($"Plugins.{PayFastCompleteDefaults.SystemName}.Fields.ApiTransactionHistoryForWeeklyUrl.Hint", "Url/Uri end-point to get the weekly transactions from the API. Retruns the data in comma-delimited fields or CSV format");
            _localizationService.AddOrUpdatePluginLocaleResource($"Plugins.{PayFastCompleteDefaults.SystemName}.Fields.ApiTransactionHistoryForMonthlyUrl", "Monthly End Point");
            _localizationService.AddOrUpdatePluginLocaleResource($"Plugins.{PayFastCompleteDefaults.SystemName}.Fields.ApiTransactionHistoryForMonthlyUrl.Hint", "Url/Uri end-point to get the Monthly transactions from the API. Retruns the data in comma-delimited fields or CSV format");
            _localizationService.AddOrUpdatePluginLocaleResource($"Plugins.{PayFastCompleteDefaults.SystemName}.Fields.ApiTransactionDetailsUrl", "Transaction Details End Point");
            _localizationService.AddOrUpdatePluginLocaleResource($"Plugins.{PayFastCompleteDefaults.SystemName}.Fields.ApiTransactionDetailsUrl.Hint", "Url/Uri end-point that gets the deatils od a specific transaction that was completed on the PayFast System.");
            _localizationService.AddOrUpdatePluginLocaleResource($"Plugins.{PayFastCompleteDefaults.SystemName}.Fields.APIPassPhrase", "Api Pass Phrase");
            _localizationService.AddOrUpdatePluginLocaleResource($"Plugins.{PayFastCompleteDefaults.SystemName}.Fields.APIPassPhrase.Hint", "This is a user defined Key that is used to secure/verfiy the data sent between the system and that PayFast Api Gateway.(Used in the Header of the Http Connection).");
            _localizationService.AddOrUpdatePluginLocaleResource($"Plugins.{PayFastCompleteDefaults.SystemName}.Fields.FormSubnissionTestingUri", "From Testing Uri");
            _localizationService.AddOrUpdatePluginLocaleResource($"Plugins.{PayFastCompleteDefaults.SystemName}.Fields.FormSubnissionTestingUri.Hint", "This is the Uri used when testing FORM subbmissions within the sandbox enviroment.");
            _localizationService.AddOrUpdatePluginLocaleResource($"Plugins.{PayFastCompleteDefaults.SystemName}.Fields.ApiSubmissionTestingUrl", "Api Testing Url");
            _localizationService.AddOrUpdatePluginLocaleResource($"Plugins.{PayFastCompleteDefaults.SystemName}.Fields.ApiSubmissionTestingUrl.Hint", "This is the Url used when testing API subbmissions within the sandbox enviroment.");
            _localizationService.AddOrUpdatePluginLocaleResource($"Plugins.{PayFastCompleteDefaults.SystemName}.Fields.ApiRecurringBillingAdHocChargeUrl", "Api Recurring Ad Hoc Charge Url");
            _localizationService.AddOrUpdatePluginLocaleResource($"Plugins.{PayFastCompleteDefaults.SystemName}.Fields.ApiRecurringBillingAdHocChargeUrl.Hint", "This is the Url used when testing API subbmissions within the sandbox enviroment.");
            _localizationService.AddOrUpdatePluginLocaleResource($"Plugins.{PayFastCompleteDefaults.SystemName}.Fields.ApiRecurringBillingCommonFetchUrl", "Api Recurring Fetch Url");
            _localizationService.AddOrUpdatePluginLocaleResource($"Plugins.{PayFastCompleteDefaults.SystemName}.Fields.ApiRecurringBillingCommonFetchUrl.Hint", "This is the Url used when testing API subbmissions within the sandbox enviroment.");
            _localizationService.AddOrUpdatePluginLocaleResource($"Plugins.{PayFastCompleteDefaults.SystemName}.Fields.ApiRecurringBillingCommonCancelUrl", "Api Recurring Cancel Url");
            _localizationService.AddOrUpdatePluginLocaleResource($"Plugins.{PayFastCompleteDefaults.SystemName}.Fields.ApiRecurringBillingCommonCancelUrl.Hint", "This is the Url used when testing API subbmissions within the sandbox enviroment.");
            _localizationService.AddOrUpdatePluginLocaleResource($"Plugins.{PayFastCompleteDefaults.SystemName}.Fields.ApiRecurringBillingNormalPauseUrl", "Api Recurring Pause Url");
            _localizationService.AddOrUpdatePluginLocaleResource($"Plugins.{PayFastCompleteDefaults.SystemName}.Fields.ApiRecurringBillingNormalPauseUrl.Hint", "This is the Url used when testing API subbmissions within the sandbox enviroment.");
            _localizationService.AddOrUpdatePluginLocaleResource($"Plugins.{PayFastCompleteDefaults.SystemName}.Fields.ApiRecurringBillingNormalUnpauseUrl", "Api Recurring Unpause Url");
            _localizationService.AddOrUpdatePluginLocaleResource($"Plugins.{PayFastCompleteDefaults.SystemName}.Fields.ApiRecurringBillingNormalUnpauseUrl.Hint", "This is the Url used when testing API subbmissions within the sandbox enviroment.");
            _localizationService.AddOrUpdatePluginLocaleResource($"Plugins.{PayFastCompleteDefaults.SystemName}.Fields.ApiRecurringBillingNormalUpdateUrl", "Api Recurring Update Url");
            _localizationService.AddOrUpdatePluginLocaleResource($"Plugins.{PayFastCompleteDefaults.SystemName}.Fields.ApiRecurringBillingNormalUpdateUrl.Hint", "This is the Url used when testing API subbmissions within the sandbox enviroment.");
            _localizationService.AddOrUpdatePluginLocaleResource($"Plugins.{PayFastCompleteDefaults.SystemName}.Fields.SplitRecievingMerchantId", "Recieving Merchant ID");
            _localizationService.AddOrUpdatePluginLocaleResource($"Plugins.{PayFastCompleteDefaults.SystemName}.Fields.SplitRecievingMerchantId.Hint", "This Is the Merchant that the split payment will be paid over to.");
            _localizationService.AddOrUpdatePluginLocaleResource($"Plugins.{PayFastCompleteDefaults.SystemName}.Fields.SplitAmount", "Thresholhd Amount");
            _localizationService.AddOrUpdatePluginLocaleResource($"Plugins.{PayFastCompleteDefaults.SystemName}.Fields.SplitAmount.Hint", "the percentage will be applied to the amount excceeding this threshold. Eg. if threshold is 500 and order total is 750 the additioal charge will be the percentage((Amount Set) of 250.");
            _localizationService.AddOrUpdatePluginLocaleResource($"Plugins.{PayFastCompleteDefaults.SystemName}.Fields.SplitPercentage", "Percentage On Amount");
            _localizationService.AddOrUpdatePluginLocaleResource($"Plugins.{PayFastCompleteDefaults.SystemName}.Fields.SplitPercentage.Hint", "This is the percentage commision that is charged to the cleint.");
            _localizationService.AddOrUpdatePluginLocaleResource($"Plugins.{PayFastCompleteDefaults.SystemName}.Fields.SplitMinimumAmount", "Minimum Fee");
            _localizationService.AddOrUpdatePluginLocaleResource($"Plugins.{PayFastCompleteDefaults.SystemName}.Fields.SplitMinimumAmount.Hint", "This is the Min ammount charged per order.");
            _localizationService.AddOrUpdatePluginLocaleResource($"Plugins.{PayFastCompleteDefaults.SystemName}.Fields.SplitMaximumAmount", "Maximum Fee");
            _localizationService.AddOrUpdatePluginLocaleResource($"Plugins.{PayFastCompleteDefaults.SystemName}.Fields.SplitMaximumAmount.Hint", "This is the maximum that will ever be charged to the client, this includes minimum charge + percantage over the threshold charged to the client..");
            _localizationService.AddOrUpdatePluginLocaleResource($"Plugins.{PayFastCompleteDefaults.SystemName}.Fields.IsSplitPaymentActive", "Is Active.");
            _localizationService.AddOrUpdatePluginLocaleResource($"Plugins.{PayFastCompleteDefaults.SystemName}.Fields.IsSplitPaymentActive.Hint", "Sets the split payment to calculated when the order is processed.");
            _localizationService.AddOrUpdatePluginLocaleResource($"Plugins.{PayFastCompleteDefaults.SystemName}.Fields.SplitMustIncludeShippingCosts", "Include Shipping");
            _localizationService.AddOrUpdatePluginLocaleResource($"Plugins.{PayFastCompleteDefaults.SystemName}.Fields.SplitMustIncludeShippingCosts.Hint", "Indicates wheather the shipping must be inculded in the slipt payment, this is included if the recieving merchant handles the shipping as well.");
            _localizationService.AddOrUpdatePluginLocaleResource($"Plugins.{PayFastCompleteDefaults.SystemName}.TansactionHistorySearchFields.DayOfTranaction", "Day");
            _localizationService.AddOrUpdatePluginLocaleResource($"Plugins.{PayFastCompleteDefaults.SystemName}.TansactionHistorySearchFields.DayOfTranaction.Hint", "Select the Day that you would like to search for.");
            _localizationService.AddOrUpdatePluginLocaleResource($"Plugins.{PayFastCompleteDefaults.SystemName}.TansactionHistorySearchFields.MonthOfTranaction", "Month");
            _localizationService.AddOrUpdatePluginLocaleResource($"Plugins.{PayFastCompleteDefaults.SystemName}.TansactionHistorySearchFields.MonthOfTranaction.Hint", "Month the trans action falls in.");
            _localizationService.AddOrUpdatePluginLocaleResource($"Plugins.{PayFastCompleteDefaults.SystemName}.TansactionHistorySearchFields.YearOfTranaction", "Year");
            _localizationService.AddOrUpdatePluginLocaleResource($"Plugins.{PayFastCompleteDefaults.SystemName}.TansactionHistorySearchFields.YearOfTranaction.Hint", "Select the year that the transaction falls in that you want to search for.");
            _localizationService.AddOrUpdatePluginLocaleResource($"Plugins.{PayFastCompleteDefaults.SystemName}.TansactionHistorySearchFields.PayFastTransacionReference", "PayFast Ref");
            _localizationService.AddOrUpdatePluginLocaleResource($"Plugins.{PayFastCompleteDefaults.SystemName}.TansactionHistorySearchFields.PayFastTransacionReference.Hint", "This is the PayFast generated transaction number. Each transaction that is processed by PayFast generates a unique transaction number.");
            _localizationService.AddOrUpdatePluginLocaleResource($"Plugins.{PayFastCompleteDefaults.SystemName}.TansactionHistorySearchFields.PayFastTransacionType", "Transaction Type");
            _localizationService.AddOrUpdatePluginLocaleResource($"Plugins.{PayFastCompleteDefaults.SystemName}.TansactionHistorySearchFields.PayFastTransacionType.Hint", "Select the transaction type to filter, eg - Funds Recieved.");
            _localizationService.AddOrUpdatePluginLocaleResource($"Plugins.{PayFastCompleteDefaults.SystemName}.TansactionHistorySearchFields.NopCommerceOrderNumber", "Order Number");
            _localizationService.AddOrUpdatePluginLocaleResource($"Plugins.{PayFastCompleteDefaults.SystemName}.TansactionHistorySearchFields.NopCommerceOrderNumber.Hint", "This Is the order number generated by the system. eg - 2303");
            _localizationService.AddOrUpdatePluginLocaleResource($"Plugins.{PayFastCompleteDefaults.SystemName}.TansactionHistoryFields.TransactionDateTimeStamp", "Time Stamp ");
            _localizationService.AddOrUpdatePluginLocaleResource($"Plugins.{PayFastCompleteDefaults.SystemName}.TansactionHistoryFields.TransactionDateTimeStamp.Hint", "This is the date and timethe transaction was processed.");
            _localizationService.AddOrUpdatePluginLocaleResource($"Plugins.{PayFastCompleteDefaults.SystemName}.TansactionHistoryFields.TransactionType", "Transaction Type");
            _localizationService.AddOrUpdatePluginLocaleResource($"Plugins.{PayFastCompleteDefaults.SystemName}.TansactionHistoryFields.TransactionType.Hint", "This Indictates the type of transaction that was processed.");
            _localizationService.AddOrUpdatePluginLocaleResource($"Plugins.{PayFastCompleteDefaults.SystemName}.TansactionHistoryFields.TransactionMethod", "Transaction Method");
            _localizationService.AddOrUpdatePluginLocaleResource($"Plugins.{PayFastCompleteDefaults.SystemName}.TansactionHistoryFields.TransactionMethod.Hint", "This indeicates the method by which the transaction was processed.");
            _localizationService.AddOrUpdatePluginLocaleResource($"Plugins.{PayFastCompleteDefaults.SystemName}.TansactionHistoryFields.TransactionUserReference", "Uer Reference");
            _localizationService.AddOrUpdatePluginLocaleResource($"Plugins.{PayFastCompleteDefaults.SystemName}.TansactionHistoryFields.TransactionUserReference.Hint", "This gives an indication of whom this rtansaction relates to.");
            _localizationService.AddOrUpdatePluginLocaleResource($"Plugins.{PayFastCompleteDefaults.SystemName}.TansactionHistoryFields.TransactionName", "Short Description");
            _localizationService.AddOrUpdatePluginLocaleResource($"Plugins.{PayFastCompleteDefaults.SystemName}.TansactionHistoryFields.TransactionName.Hint", "Transaction Name - gives a short description to identify this transaction.");
            _localizationService.AddOrUpdatePluginLocaleResource($"Plugins.{PayFastCompleteDefaults.SystemName}.TansactionHistoryFields.TransactionDescription", "Full Description");
            _localizationService.AddOrUpdatePluginLocaleResource($"Plugins.{PayFastCompleteDefaults.SystemName}.TansactionHistoryFields.TransactionDescription.Hint", "This gives a full description about this specific transaction.");
            _localizationService.AddOrUpdatePluginLocaleResource($"Plugins.{PayFastCompleteDefaults.SystemName}.TansactionHistoryFields.TransactionCurrency", "Currency");
            _localizationService.AddOrUpdatePluginLocaleResource($"Plugins.{PayFastCompleteDefaults.SystemName}.TansactionHistoryFields.TransactionCurrency.Hint", "This indicates what curreny this transaction was processed in.");
            _localizationService.AddOrUpdatePluginLocaleResource($"Plugins.{PayFastCompleteDefaults.SystemName}.TansactionHistoryFields.TransactionFundingSource", "Funding Source");
            _localizationService.AddOrUpdatePluginLocaleResource($"Plugins.{PayFastCompleteDefaults.SystemName}.TansactionHistoryFields.TransactionFundingSource.Hint", "this give an indication of where the funds orginated from.");
            _localizationService.AddOrUpdatePluginLocaleResource($"Plugins.{PayFastCompleteDefaults.SystemName}.TansactionHistoryFields.TransactionGrossAmount", "Order Total/Gross");
            _localizationService.AddOrUpdatePluginLocaleResource($"Plugins.{PayFastCompleteDefaults.SystemName}.TansactionHistoryFields.TransactionGrossAmount.Hint", "The total of this order including all shipping, tax, and other related costs.");
            _localizationService.AddOrUpdatePluginLocaleResource($"Plugins.{PayFastCompleteDefaults.SystemName}.TansactionHistoryFields.TransactionFee", "Transaction Fee");
            _localizationService.AddOrUpdatePluginLocaleResource($"Plugins.{PayFastCompleteDefaults.SystemName}.TansactionHistoryFields.TransactionFee.Hint", "This is the transaction fee deducted by PayFast.");
            _localizationService.AddOrUpdatePluginLocaleResource($"Plugins.{PayFastCompleteDefaults.SystemName}.TansactionHistoryFields.TransactionNetAmount", "Net Amount");
            _localizationService.AddOrUpdatePluginLocaleResource($"Plugins.{PayFastCompleteDefaults.SystemName}.TansactionHistoryFields.TransactionNetAmount.Hint", "The Net amount paid over to the merchant account.");
            _localizationService.AddOrUpdatePluginLocaleResource($"Plugins.{PayFastCompleteDefaults.SystemName}.TansactionHistoryFields.TranactionAccountBalance", "Account Balance");
            _localizationService.AddOrUpdatePluginLocaleResource($"Plugins.{PayFastCompleteDefaults.SystemName}.TansactionHistoryFields.TranactionAccountBalance.Hint", "This is the current account balance at the time of the transaction. After the transaction was processed.");
            _localizationService.AddOrUpdatePluginLocaleResource($"Plugins.{PayFastCompleteDefaults.SystemName}.TansactionHistoryFields.MerchantTranactionReference", "Merchant Ref");
            _localizationService.AddOrUpdatePluginLocaleResource($"Plugins.{PayFastCompleteDefaults.SystemName}.TansactionHistoryFields.MerchantTranactionReference.Hint", "This is a assigned reference provided by the merchant at the time when the trasacton was processed.");
            _localizationService.AddOrUpdatePluginLocaleResource($"Plugins.{PayFastCompleteDefaults.SystemName}.TansactionHistoryFields.PayFastTranactionReference", "PayFast Ref");
            _localizationService.AddOrUpdatePluginLocaleResource($"Plugins.{PayFastCompleteDefaults.SystemName}.TansactionHistoryFields.PayFastTranactionReference.Hint", "This is the transaction reference number generated by PayFast when the transaction was processed.");
            _localizationService.AddOrUpdatePluginLocaleResource($"Plugins.{PayFastCompleteDefaults.SystemName}.TansactionHistoryFields.CustomStringProperty1", "Custom String 1");
            _localizationService.AddOrUpdatePluginLocaleResource($"Plugins.{PayFastCompleteDefaults.SystemName}.TansactionHistoryFields.CustomStringProperty1.Hint", "User Assigned property, can be used for custom string values that can be passed through during the transaction processing.");
            _localizationService.AddOrUpdatePluginLocaleResource($"Plugins.{PayFastCompleteDefaults.SystemName}.TansactionHistoryFields.CustomIntegerProperty1", "Custom Integer 1");
            _localizationService.AddOrUpdatePluginLocaleResource($"Plugins.{PayFastCompleteDefaults.SystemName}.TansactionHistoryFields.CustomIntegerProperty1.Hint", "User Assigned property, can be used for custom numeric integer values that can be passed through during the transaction processing.");
            _localizationService.AddOrUpdatePluginLocaleResource($"Plugins.{PayFastCompleteDefaults.SystemName}.TansactionHistoryFields.CustomStringProperty2", "Custom String 2");
            _localizationService.AddOrUpdatePluginLocaleResource($"Plugins.{PayFastCompleteDefaults.SystemName}.TansactionHistoryFields.CustomStringProperty2.Hint", "User Assigned property, can be used for custom string values that can be passed through during the transaction processing.");
            _localizationService.AddOrUpdatePluginLocaleResource($"Plugins.{PayFastCompleteDefaults.SystemName}.TansactionHistoryFields.CustomIntegerProperty2", "Custom Integer 2");
            _localizationService.AddOrUpdatePluginLocaleResource($"Plugins.{PayFastCompleteDefaults.SystemName}.TansactionHistoryFields.CustomIntegerProperty2.Hint", "User Assigned property, can be used for custom numeric integer values that can be passed through during the transaction processing.");
            _localizationService.AddOrUpdatePluginLocaleResource($"Plugins.{PayFastCompleteDefaults.SystemName}.TansactionHistoryFields.CustomStringProperty3", "Custom String 3");
            _localizationService.AddOrUpdatePluginLocaleResource($"Plugins.{PayFastCompleteDefaults.SystemName}.TansactionHistoryFields.CustomStringProperty3.Hint", "User Assigned property, can be used for custom string values that can be passed through during the transaction processing.");
            _localizationService.AddOrUpdatePluginLocaleResource($"Plugins.{PayFastCompleteDefaults.SystemName}.TansactionHistoryFields.CustomIntegerProperty3", "Custom Integer 3");
            _localizationService.AddOrUpdatePluginLocaleResource($"Plugins.{PayFastCompleteDefaults.SystemName}.TansactionHistoryFields.CustomIntegerProperty3.Hint", "User Assigned property, can be used for custom numeric integer values that can be passed through during the transaction processing.");
            _localizationService.AddOrUpdatePluginLocaleResource($"Plugins.{PayFastCompleteDefaults.SystemName}.TansactionHistoryFields.CustomStringProperty4", "Custom String 4");
            _localizationService.AddOrUpdatePluginLocaleResource($"Plugins.{PayFastCompleteDefaults.SystemName}.TansactionHistoryFields.CustomStringProperty4.Hint", "User Assigned property, can be used for custom string values that can be passed through during the transaction processing.");
            _localizationService.AddOrUpdatePluginLocaleResource($"Plugins.{PayFastCompleteDefaults.SystemName}.TansactionHistoryFields.CustomIntegerProperty4", "Custom Integer 4");
            _localizationService.AddOrUpdatePluginLocaleResource($"Plugins.{PayFastCompleteDefaults.SystemName}.TansactionHistoryFields.CustomIntegerProperty4.Hint", "User Assigned property, can be used for custom numeric integer values that can be passed through during the transaction processing.");
            _localizationService.AddOrUpdatePluginLocaleResource($"Plugins.{PayFastCompleteDefaults.SystemName}.TansactionHistoryFields.CustomStringProperty5", "Custom String 5");
            _localizationService.AddOrUpdatePluginLocaleResource($"Plugins.{PayFastCompleteDefaults.SystemName}.TansactionHistoryFields.CustomStringProperty5.Hint", "User Assigned property, can be used for custom string values that can be passed through during the transaction processing.");
            _localizationService.AddOrUpdatePluginLocaleResource($"Plugins.{PayFastCompleteDefaults.SystemName}.TansactionHistoryFields.CustomIntegerProperty5", "Custom Integer 5");
            _localizationService.AddOrUpdatePluginLocaleResource($"Plugins.{PayFastCompleteDefaults.SystemName}.TansactionHistoryFields.CustomIntegerProperty5.Hint", "User Assigned property, can be used for custom numeric integer values that can be passed through during the transaction processing.");
            //
            _scheduleTaskService.InsertTask(new ScheduleTask()
            {
                Enabled = true,
                Name = "Syncronize Transaction History Records",
                Type = $"{PayFastCompleteDefaults.TaskSchedulerNameSpace}." +
                $"{PayFastCompleteDefaults.TransactionHistoryTaskClassName}, " +
                $"{PayFastCompleteDefaults.SystemPackageName}",
                Seconds = 3600,
                StopOnError = false

            });

            _scheduleTaskService.InsertTask(new ScheduleTask()
            {
                Enabled = true,
                Name = "Recurring Payment Processor",
                Type = $"{PayFastCompleteDefaults.TaskSchedulerNameSpace}." +
               $"{PayFastCompleteDefaults.RecurringPaymentTaskClassName}, " +
               $"{PayFastCompleteDefaults.SystemPackageName}",
                Seconds = 7200,
                StopOnError = false

            });


            base.Install();

        }
        #endregion

        #region Uninstall
        public override void Uninstall()
        {

            //settings
            _settingService.DeleteSetting<PayFastCompleteSettings>();

            //locales
            _localizationService.DeletePluginLocaleResource($"Plugins.{PayFastCompleteDefaults.SystemName}.Fields.AdditionalFee");
            _localizationService.DeletePluginLocaleResource($"Plugins.{PayFastCompleteDefaults.SystemName}.Fields.AdditionalFee.Hint");
            _localizationService.DeletePluginLocaleResource($"Plugins.{PayFastCompleteDefaults.SystemName}.Fields.AdditionalFeePercentage");
            _localizationService.DeletePluginLocaleResource($"Plugins.{PayFastCompleteDefaults.SystemName}.Fields.AdditionalFeePercentage.Hint");
            _localizationService.DeletePluginLocaleResource($"Plugins.{PayFastCompleteDefaults.SystemName}.Fields.MerchantId");
            _localizationService.DeletePluginLocaleResource($"Plugins.{PayFastCompleteDefaults.SystemName}.Fields.MerchantId.Hint");
            _localizationService.DeletePluginLocaleResource($"Plugins.{PayFastCompleteDefaults.SystemName}.Fields.MerchantKey");
            _localizationService.DeletePluginLocaleResource($"Plugins.{PayFastCompleteDefaults.SystemName}.Fields.MerchantKey.Hint");
            _localizationService.DeletePluginLocaleResource($"Plugins.{PayFastCompleteDefaults.SystemName}.Fields.UseSandbox");
            _localizationService.DeletePluginLocaleResource($"Plugins.{PayFastCompleteDefaults.SystemName}.Fields.UseSandbox.Hint");
            _localizationService.DeletePluginLocaleResource($"Plugins.{PayFastCompleteDefaults.SystemName}.RedirectionTip");
            _localizationService.DeletePluginLocaleResource($"Plugins.{PayFastCompleteDefaults.SystemName}.PaymentMethodDescription");
            _localizationService.DeletePluginLocaleResource($"Plugins.{PayFastCompleteDefaults.SystemName}.Fields.APIBaseUri");
            _localizationService.DeletePluginLocaleResource($"Plugins.{PayFastCompleteDefaults.SystemName}.Fields.APIBaseUri.Hint");
            _localizationService.DeletePluginLocaleResource($"Plugins.{PayFastCompleteDefaults.SystemName}.Fields.APIVersion");
            _localizationService.DeletePluginLocaleResource($"Plugins.{PayFastCompleteDefaults.SystemName}.Fields.APIVersion.Hint");
            _localizationService.DeletePluginLocaleResource($"Plugins.{PayFastCompleteDefaults.SystemName}.Fields.FormBaseUri");
            _localizationService.DeletePluginLocaleResource($"Plugins.{PayFastCompleteDefaults.SystemName}.Fields.FormBaseUri.Hint");
            _localizationService.DeletePluginLocaleResource($"Plugins.{PayFastCompleteDefaults.SystemName}.Fields.ApiPingUrl");
            _localizationService.DeletePluginLocaleResource($"Plugins.{PayFastCompleteDefaults.SystemName}.Fields.ApiPingUrl.Hint");
            _localizationService.DeletePluginLocaleResource($"Plugins.{PayFastCompleteDefaults.SystemName}.Fields.ApiTransactionHistoryForPeriodUrl");
            _localizationService.DeletePluginLocaleResource($"Plugins.{PayFastCompleteDefaults.SystemName}.Fields.ApiTransactionHistoryForPeriodUrl.Hint");
            _localizationService.DeletePluginLocaleResource($"Plugins.{PayFastCompleteDefaults.SystemName}.Fields.ApiTransactionHistoryForDailyUrl");
            _localizationService.DeletePluginLocaleResource($"Plugins.{PayFastCompleteDefaults.SystemName}.Fields.ApiTransactionHistoryForDailyUrl.Hint");
            _localizationService.DeletePluginLocaleResource($"Plugins.{PayFastCompleteDefaults.SystemName}.Fields.ApiTransactionHistoryForWeeklyUrl");
            _localizationService.DeletePluginLocaleResource($"Plugins.{PayFastCompleteDefaults.SystemName}.Fields.ApiTransactionHistoryForWeeklyUrl.Hint");
            _localizationService.DeletePluginLocaleResource($"Plugins.{PayFastCompleteDefaults.SystemName}.Fields.ApiTransactionHistoryForMonthlyUrl");
            _localizationService.DeletePluginLocaleResource($"Plugins.{PayFastCompleteDefaults.SystemName}.Fields.ApiTransactionHistoryForMonthlyUrl.Hint");
            _localizationService.DeletePluginLocaleResource($"Plugins.{PayFastCompleteDefaults.SystemName}.Fields.ApiTransactionDetailsUrl");
            _localizationService.DeletePluginLocaleResource($"Plugins.{PayFastCompleteDefaults.SystemName}.Fields.ApiTransactionDetailsUrl.Hint");
            _localizationService.DeletePluginLocaleResource($"Plugins.{PayFastCompleteDefaults.SystemName}.Fields.APIPassPhrase");
            _localizationService.DeletePluginLocaleResource($"Plugins.{PayFastCompleteDefaults.SystemName}.Fields.APIPassPhrase.Hint");
            _localizationService.DeletePluginLocaleResource($"Plugins.{PayFastCompleteDefaults.SystemName}.Fields.FormSubnissionTestingUri");
            _localizationService.DeletePluginLocaleResource($"Plugins.{PayFastCompleteDefaults.SystemName}.Fields.FormSubnissionTestingUri.Hint");
            _localizationService.DeletePluginLocaleResource($"Plugins.{PayFastCompleteDefaults.SystemName}.Fields.ApiSubmissionTestingUrl");
            _localizationService.DeletePluginLocaleResource($"Plugins.{PayFastCompleteDefaults.SystemName}.Fields.ApiSubmissionTestingUrl.Hint");
            _localizationService.DeletePluginLocaleResource($"Plugins.{PayFastCompleteDefaults.SystemName}.Fields.ApiRecurringBillingAdHocChargeUrl");
            _localizationService.DeletePluginLocaleResource($"Plugins.{PayFastCompleteDefaults.SystemName}.Fields.ApiRecurringBillingAdHocChargeUrl.Hint");
            _localizationService.DeletePluginLocaleResource($"Plugins.{PayFastCompleteDefaults.SystemName}.Fields.ApiRecurringBillingCommonFetchUrl");
            _localizationService.DeletePluginLocaleResource($"Plugins.{PayFastCompleteDefaults.SystemName}.Fields.ApiRecurringBillingCommonFetchUrl.Hint");
            _localizationService.DeletePluginLocaleResource($"Plugins.{PayFastCompleteDefaults.SystemName}.Fields.ApiRecurringBillingCommonCancelUrl");
            _localizationService.DeletePluginLocaleResource($"Plugins.{PayFastCompleteDefaults.SystemName}.Fields.ApiRecurringBillingCommonCancelUrl.Hint");
            _localizationService.DeletePluginLocaleResource($"Plugins.{PayFastCompleteDefaults.SystemName}.Fields.ApiRecurringBillingNormalPauseUrl");
            _localizationService.DeletePluginLocaleResource($"Plugins.{PayFastCompleteDefaults.SystemName}.Fields.ApiRecurringBillingNormalPauseUrl.Hint");
            _localizationService.DeletePluginLocaleResource($"Plugins.{PayFastCompleteDefaults.SystemName}.Fields.ApiRecurringBillingNormalUnpauseUrl");
            _localizationService.DeletePluginLocaleResource($"Plugins.{PayFastCompleteDefaults.SystemName}.Fields.ApiRecurringBillingNormalUnpauseUrl.Hint");
            _localizationService.DeletePluginLocaleResource($"Plugins.{PayFastCompleteDefaults.SystemName}.Fields.ApiRecurringBillingNormalUpdateUrl");
            _localizationService.DeletePluginLocaleResource($"Plugins.{PayFastCompleteDefaults.SystemName}.Fields.ApiRecurringBillingNormalUpdateUrl.Hint");
            _localizationService.DeletePluginLocaleResource($"Plugins.{PayFastCompleteDefaults.SystemName}.Fields.SplitRecievingMerchantId");
            _localizationService.DeletePluginLocaleResource($"Plugins.{PayFastCompleteDefaults.SystemName}.Fields.SplitRecievingMerchantId.Hint");
            _localizationService.DeletePluginLocaleResource($"Plugins.{PayFastCompleteDefaults.SystemName}.Fields.SplitAmount");
            _localizationService.DeletePluginLocaleResource($"Plugins.{PayFastCompleteDefaults.SystemName}.Fields.SplitAmount.Hint");
            _localizationService.DeletePluginLocaleResource($"Plugins.{PayFastCompleteDefaults.SystemName}.Fields.SplitPercentage");
            _localizationService.DeletePluginLocaleResource($"Plugins.{PayFastCompleteDefaults.SystemName}.Fields.SplitPercentage.Hint");
            _localizationService.DeletePluginLocaleResource($"Plugins.{PayFastCompleteDefaults.SystemName}.Fields.SplitMinimumAmount");
            _localizationService.DeletePluginLocaleResource($"Plugins.{PayFastCompleteDefaults.SystemName}.Fields.SplitMinimumAmount.Hint");
            _localizationService.DeletePluginLocaleResource($"Plugins.{PayFastCompleteDefaults.SystemName}.Fields.SplitMaximumAmount");
            _localizationService.DeletePluginLocaleResource($"Plugins.{PayFastCompleteDefaults.SystemName}.Fields.SplitMaximumAmount.Hint");
            _localizationService.DeletePluginLocaleResource($"Plugins.{PayFastCompleteDefaults.SystemName}.Fields.IsSplitPaymentActive");
            _localizationService.DeletePluginLocaleResource($"Plugins.{PayFastCompleteDefaults.SystemName}.Fields.IsSplitPaymentActive.Hint");
            _localizationService.DeletePluginLocaleResource($"Plugins.{PayFastCompleteDefaults.SystemName}.Fields.SplitMustIncludeShippingCosts");
            _localizationService.DeletePluginLocaleResource($"Plugins.{PayFastCompleteDefaults.SystemName}.Fields.SplitMustIncludeShippingCosts.Hint");
            _localizationService.DeletePluginLocaleResource($"Plugins.{PayFastCompleteDefaults.SystemName}.TansactionHistorySearchFields.DayOfTranaction");
            _localizationService.DeletePluginLocaleResource($"Plugins.{PayFastCompleteDefaults.SystemName}.TansactionHistorySearchFields.DayOfTranaction.Hint");
            _localizationService.DeletePluginLocaleResource($"Plugins.{PayFastCompleteDefaults.SystemName}.TansactionHistorySearchFields.MonthOfTranaction");
            _localizationService.DeletePluginLocaleResource($"Plugins.{PayFastCompleteDefaults.SystemName}.TansactionHistorySearchFields.MonthOfTranaction.Hint");
            _localizationService.DeletePluginLocaleResource($"Plugins.{PayFastCompleteDefaults.SystemName}.TansactionHistorySearchFields.YearOfTranaction");
            _localizationService.DeletePluginLocaleResource($"Plugins.{PayFastCompleteDefaults.SystemName}.TansactionHistorySearchFields.YearOfTranaction.Hint");
            _localizationService.DeletePluginLocaleResource($"Plugins.{PayFastCompleteDefaults.SystemName}.TansactionHistorySearchFields.PayFastTransacionReference");
            _localizationService.DeletePluginLocaleResource($"Plugins.{PayFastCompleteDefaults.SystemName}.TansactionHistorySearchFields.PayFastTransacionReference.Hint");
            _localizationService.DeletePluginLocaleResource($"Plugins.{PayFastCompleteDefaults.SystemName}.TansactionHistorySearchFields.PayFastTransacionType");
            _localizationService.DeletePluginLocaleResource($"Plugins.{PayFastCompleteDefaults.SystemName}.TansactionHistorySearchFields.PayFastTransacionType.Hint");
            _localizationService.DeletePluginLocaleResource($"Plugins.{PayFastCompleteDefaults.SystemName}.TansactionHistorySearchFields.NopCommerceOrderNumber");
            _localizationService.DeletePluginLocaleResource($"Plugins.{PayFastCompleteDefaults.SystemName}.TansactionHistorySearchFields.NopCommerceOrderNumber.Hint");
            _localizationService.DeletePluginLocaleResource($"Plugins.{PayFastCompleteDefaults.SystemName}.TansactionHistoryFields.TransactionDateTimeStamp");
            _localizationService.DeletePluginLocaleResource($"Plugins.{PayFastCompleteDefaults.SystemName}.TansactionHistoryFields.TransactionDateTimeStamp.Hint");
            _localizationService.DeletePluginLocaleResource($"Plugins.{PayFastCompleteDefaults.SystemName}.TansactionHistoryFields.TransactionType");
            _localizationService.DeletePluginLocaleResource($"Plugins.{PayFastCompleteDefaults.SystemName}.TansactionHistoryFields.TransactionType.Hint");
            _localizationService.DeletePluginLocaleResource($"Plugins.{PayFastCompleteDefaults.SystemName}.TansactionHistoryFields.TransactionMethod");
            _localizationService.DeletePluginLocaleResource($"Plugins.{PayFastCompleteDefaults.SystemName}.TansactionHistoryFields.TransactionMethod.Hint");
            _localizationService.DeletePluginLocaleResource($"Plugins.{PayFastCompleteDefaults.SystemName}.TansactionHistoryFields.TransactionUserReference");
            _localizationService.DeletePluginLocaleResource($"Plugins.{PayFastCompleteDefaults.SystemName}.TansactionHistoryFields.TransactionUserReference.Hint");
            _localizationService.DeletePluginLocaleResource($"Plugins.{PayFastCompleteDefaults.SystemName}.TansactionHistoryFields.TransactionName");
            _localizationService.DeletePluginLocaleResource($"Plugins.{PayFastCompleteDefaults.SystemName}.TansactionHistoryFields.TransactionName.Hint");
            _localizationService.DeletePluginLocaleResource($"Plugins.{PayFastCompleteDefaults.SystemName}.TansactionHistoryFields.TransactionDescription");
            _localizationService.DeletePluginLocaleResource($"Plugins.{PayFastCompleteDefaults.SystemName}.TansactionHistoryFields.TransactionDescription.Hint");
            _localizationService.DeletePluginLocaleResource($"Plugins.{PayFastCompleteDefaults.SystemName}.TansactionHistoryFields.TransactionCurrency");
            _localizationService.DeletePluginLocaleResource($"Plugins.{PayFastCompleteDefaults.SystemName}.TansactionHistoryFields.TransactionCurrency.Hint");
            _localizationService.DeletePluginLocaleResource($"Plugins.{PayFastCompleteDefaults.SystemName}.TansactionHistoryFields.TransactionFundingSource");
            _localizationService.DeletePluginLocaleResource($"Plugins.{PayFastCompleteDefaults.SystemName}.TansactionHistoryFields.TransactionFundingSource.Hint");
            _localizationService.DeletePluginLocaleResource($"Plugins.{PayFastCompleteDefaults.SystemName}.TansactionHistoryFields.TransactionGrossAmount");
            _localizationService.DeletePluginLocaleResource($"Plugins.{PayFastCompleteDefaults.SystemName}.TansactionHistoryFields.TransactionGrossAmount.Hint");
            _localizationService.DeletePluginLocaleResource($"Plugins.{PayFastCompleteDefaults.SystemName}.TansactionHistoryFields.TransactionFee");
            _localizationService.DeletePluginLocaleResource($"Plugins.{PayFastCompleteDefaults.SystemName}.TansactionHistoryFields.TransactionFee.Hint");
            _localizationService.DeletePluginLocaleResource($"Plugins.{PayFastCompleteDefaults.SystemName}.TansactionHistoryFields.TransactionNetAmount");
            _localizationService.DeletePluginLocaleResource($"Plugins.{PayFastCompleteDefaults.SystemName}.TansactionHistoryFields.TransactionNetAmount.Hint");
            _localizationService.DeletePluginLocaleResource($"Plugins.{PayFastCompleteDefaults.SystemName}.TansactionHistoryFields.TranactionAccountBalance");
            _localizationService.DeletePluginLocaleResource($"Plugins.{PayFastCompleteDefaults.SystemName}.TansactionHistoryFields.TranactionAccountBalance.Hint");
            _localizationService.DeletePluginLocaleResource($"Plugins.{PayFastCompleteDefaults.SystemName}.TansactionHistoryFields.MerchantTranactionReference");
            _localizationService.DeletePluginLocaleResource($"Plugins.{PayFastCompleteDefaults.SystemName}.TansactionHistoryFields.MerchantTranactionReference.Hint");
            _localizationService.DeletePluginLocaleResource($"Plugins.{PayFastCompleteDefaults.SystemName}.TansactionHistoryFields.PayFastTranactionReference");
            _localizationService.DeletePluginLocaleResource($"Plugins.{PayFastCompleteDefaults.SystemName}.TansactionHistoryFields.PayFastTranactionReference.Hint");
            _localizationService.DeletePluginLocaleResource($"Plugins.{PayFastCompleteDefaults.SystemName}.TansactionHistoryFields.CustomStringProperty1");
            _localizationService.DeletePluginLocaleResource($"Plugins.{PayFastCompleteDefaults.SystemName}.TansactionHistoryFields.CustomStringProperty1.Hint");
            _localizationService.DeletePluginLocaleResource($"Plugins.{PayFastCompleteDefaults.SystemName}.TansactionHistoryFields.CustomIntegerProperty1");
            _localizationService.DeletePluginLocaleResource($"Plugins.{PayFastCompleteDefaults.SystemName}.TansactionHistoryFields.CustomIntegerProperty1.Hint");
            _localizationService.DeletePluginLocaleResource($"Plugins.{PayFastCompleteDefaults.SystemName}.TansactionHistoryFields.CustomStringProperty2");
            _localizationService.DeletePluginLocaleResource($"Plugins.{PayFastCompleteDefaults.SystemName}.TansactionHistoryFields.CustomStringProperty2.Hint");
            _localizationService.DeletePluginLocaleResource($"Plugins.{PayFastCompleteDefaults.SystemName}.TansactionHistoryFields.CustomIntegerProperty2");
            _localizationService.DeletePluginLocaleResource($"Plugins.{PayFastCompleteDefaults.SystemName}.TansactionHistoryFields.CustomIntegerProperty2.Hint");
            _localizationService.DeletePluginLocaleResource($"Plugins.{PayFastCompleteDefaults.SystemName}.TansactionHistoryFields.CustomStringProperty3");
            _localizationService.DeletePluginLocaleResource($"Plugins.{PayFastCompleteDefaults.SystemName}.TansactionHistoryFields.CustomStringProperty3.Hint");
            _localizationService.DeletePluginLocaleResource($"Plugins.{PayFastCompleteDefaults.SystemName}.TansactionHistoryFields.CustomIntegerProperty3");
            _localizationService.DeletePluginLocaleResource($"Plugins.{PayFastCompleteDefaults.SystemName}.TansactionHistoryFields.CustomIntegerProperty3.Hint");
            _localizationService.DeletePluginLocaleResource($"Plugins.{PayFastCompleteDefaults.SystemName}.TansactionHistoryFields.CustomStringProperty4");
            _localizationService.DeletePluginLocaleResource($"Plugins.{PayFastCompleteDefaults.SystemName}.TansactionHistoryFields.CustomStringProperty4.Hint");
            _localizationService.DeletePluginLocaleResource($"Plugins.{PayFastCompleteDefaults.SystemName}.TansactionHistoryFields.CustomIntegerProperty4");
            _localizationService.DeletePluginLocaleResource($"Plugins.{PayFastCompleteDefaults.SystemName}.TansactionHistoryFields.CustomIntegerProperty4.Hint");
            _localizationService.DeletePluginLocaleResource($"Plugins.{PayFastCompleteDefaults.SystemName}.TansactionHistoryFields.CustomStringProperty5");
            _localizationService.DeletePluginLocaleResource($"Plugins.{PayFastCompleteDefaults.SystemName}.TansactionHistoryFields.CustomStringProperty5.Hint");
            _localizationService.DeletePluginLocaleResource($"Plugins.{PayFastCompleteDefaults.SystemName}.TansactionHistoryFields.CustomIntegerProperty5");
            _localizationService.DeletePluginLocaleResource($"Plugins.{PayFastCompleteDefaults.SystemName}.TansactionHistoryFields.CustomIntegerProperty5.Hint");
            _localizationService.DeletePluginLocaleResource($"Plugins.{PayFastCompleteDefaults.SystemName}.Fields.ApiTimeOutValue.Hint");
            _localizationService.DeletePluginLocaleResource($"Plugins.{PayFastCompleteDefaults.SystemName}.Fields.ApiTimeOutValue");
            
            //Remove the Task
            if (_scheduleTaskService.GetTaskByType
                ($"{PayFastCompleteDefaults.TaskSchedulerNameSpace}." +
                $"{PayFastCompleteDefaults.TransactionHistoryTaskClassName}, " +
                $"{PayFastCompleteDefaults.SystemPackageName}") is ScheduleTask CurrentTransactionHistoryTask)
                _scheduleTaskService.DeleteTask(CurrentTransactionHistoryTask);

            if (_scheduleTaskService.GetTaskByType
                ($"{PayFastCompleteDefaults.TaskSchedulerNameSpace}." +
                $"{PayFastCompleteDefaults.RecurringPaymentTaskClassName}, " +
                $"{PayFastCompleteDefaults.SystemPackageName}") is ScheduleTask CurrentRecurringPaymentTask)
                _scheduleTaskService.DeleteTask(CurrentRecurringPaymentTask);

           
            base.Uninstall();
        }
        #endregion
        public override string GetConfigurationPageUrl()
        {
            return $"{_webHelper.GetStoreLocation()}Admin/PayFastCompleteConfiguration/PayFastDocumentation";
        }


        public override PluginDescriptor PluginDescriptor { get => base.PluginDescriptor; set => base.PluginDescriptor = value; }


        #endregion

        #region PayFast Admin Menu
        public void ManageSiteMap(SiteMapNode rootNode)
        {
            List<KeyValuePair<KeyValuePair<int, int>, SiteMapNode>> MenuItemList = new List<KeyValuePair<KeyValuePair<int, int>, SiteMapNode>>
            {
                new KeyValuePair<KeyValuePair<int, int>, SiteMapNode>                          //0-0 - Nop Admin Root Menu
                (new KeyValuePair<int, int>(0, 0), rootNode)
            };

            Build_PayFastGateway_MAIN_ROOT_MenuItem(MenuItemList, 1, 0);                                    //1-0 -> PayFast GateWay
                                                                                                            //----------------------------------------------------------
            Build_PayFastGateway_MAIN_DASHBOARD_MenuItem(MenuItemList, 2, 1);                               //2-1 -> DashBoard
                                                                                                            //----------------------------------------------------------
            Build_PayFastGateway_MAIN_TRANSACTION_HISTORY_MenuItem(MenuItemList, 3, 1);                     //3-1 -> Transaction History
            Build_PayFastGateway_MAIN_TRANSACTION_HISTORY_SEARCH_MenuItem(MenuItemList, 4, 3);              //4-3 -> Transaction History -> Search
            Build_PayFastGateway_MAIN_TRANSACTION_HISTORY_MAINTENENCE_MenuItem(MenuItemList, 5, 3);               //5-3 -> Transaction History -> Daily
                                                                                                                  //Build_PayFastGateway_MAIN_TRANSACTION_HISTORY_WEEKLY_MenuItem(MenuItemList, 6, 3);              //6-3 -> Transaction History -> Weekly
                                                                                                                  //Build_PayFastGateway_MAIN_TRANSACTION_HISTORY_MONTHLY_MenuItem(MenuItemList, 7, 3);             //7-3 -> Transaction History -> Monthly
                                                                                                                  //----------------------------------------------------------
            Build_PayFastGateway_MAIN_RECURRING_BILLING_MenuItem(MenuItemList, 8, 1);                       //8-1 -> Recurring Billing
            Build_PayFastGateway_MAIN_RECURRING_BILLING_SUBSCRIPTION_PAYMENTS_MenuItem(MenuItemList, 9, 8); //9-8 -> Recurring Billing -> Subscription Payments
            Build_PayFastGateway_MAIN_RECURRING_BILLING_AD_HOC_PAYMENTS_MenuItem(MenuItemList, 10, 8);       //10-8 -> Recurring Billing -> Ad Hoc Payments
                                                                                                             //----------------------------------------------------------
            Build_PayFastGateway_MAIN_CONFIGURATION_MenuItem(MenuItemList, 11, 1);                           //11-1 -> Configuration
            Build_PayFastGateway_MAIN_CONFIGURATION_SECURITY_SETTINGS_MenuItem(MenuItemList, 12, 11);         //12-11 -> Configuration -> Security Settings
            Build_PayFastGateway_MAIN_CONFIGURATION_ADDITIONAL_CHARGES_MenuItem(MenuItemList, 13, 11);        //13-11 -> Configuration -> Addtional Charges
            Build_PayFastGateway_MAIN_CONFIGURATION_TESTING_MODE_MenuItem(MenuItemList, 14, 11);              //14-11 -> Configuration -> Testing Mode
            Build_PayFastGateway_MAIN_CONFIGURATION_SPLIT_PAYMENTS_MenuItem(MenuItemList, 15, 11);            //15-11 -> Configuration -> URL Configuration
            Build_PayFastGateway_MAIN_CONFIGURATION_URL_CONFIG_MenuItem(MenuItemList, 16, 11);                //16-11 -> Split Payments
                                                                                                              //----------------------------------------------------------

            foreach (var item in MenuItemList)
            {
                int CurrentRootID = item.Key.Key;
                SiteMapNode ParentNode = item.Value;
                foreach (var innerItem in MenuItemList)
                {
                    SiteMapNode ChildNode = innerItem.Value;
                    int CurrerntParentID = innerItem.Key.Value;
                    if (CurrerntParentID == CurrentRootID && CurrentRootID != innerItem.Key.Key)
                    {
                        ParentNode.ChildNodes.Add(ChildNode);
                    }
                }
            }
        }

        #endregion

        #region Build menu Items Methods

        #region PayFast Root Menu Item

        /// <summary>
        /// Builds PayFast Main Root Menu Item
        /// </summary>
        /// <param name="rootNode">the Main Root menu item shown on the bottom of the Admin Menu.</param>
        private void Build_PayFastGateway_MAIN_ROOT_MenuItem(List<KeyValuePair<KeyValuePair<int, int>, SiteMapNode>> MenuItemList, int ID, int ParentID)
        {
            //Main Root Menu 1-0
            SiteMapNode PayFastGatewayMainRootSiteMapNode = new SiteMapNode()
            {
                SystemName = "PayFast Gateway",
                OpenUrlInNewTab = false,
                Title = "PayFast Gateway",
                Visible = true,
                IconClass = "fa-database",
                RouteValues = new RouteValueDictionary() { { "area", AreaNames.Admin } },
            };

            MenuItemList.Add(new KeyValuePair<KeyValuePair<int, int>, SiteMapNode>
               (new KeyValuePair<int, int>(ID, ParentID), PayFastGatewayMainRootSiteMapNode));
        }
        #endregion

        #region DashBoard Menu Item
        private void Build_PayFastGateway_MAIN_DASHBOARD_MenuItem(List<KeyValuePair<KeyValuePair<int, int>, SiteMapNode>> MenuItemList, int ID, int ParentID)
        {
            SiteMapNode PayFastDashBoardSiteMapNode = new SiteMapNode()
            {
                SystemName = "PayFast DashBoard",
                Title = "PayFast DashBoard",
                ControllerName = "PayFastDashBoard",
                ActionName = "Display",
                Visible = true,
                IconClass = "fa-desktop",
                RouteValues = new RouteValueDictionary() { { "area", AreaNames.Admin } }
            };
            MenuItemList.Add(new KeyValuePair<KeyValuePair<int, int>, SiteMapNode>
              (new KeyValuePair<int, int>(ID, ParentID), PayFastDashBoardSiteMapNode));
        }

        #endregion

        #region Transaction History
        void Build_PayFastGateway_MAIN_TRANSACTION_HISTORY_MenuItem(List<KeyValuePair<KeyValuePair<int, int>, SiteMapNode>> MenuItemList, int ID, int ParentID)
        {

            SiteMapNode PayFasTransactionHistorySiteMapNode = new SiteMapNode()
            {
                SystemName = "PayFast Transaction Histroy",
                Title = "Transaction Histroy",
                Visible = true,
                IconClass = "fa-bar-chart",
                RouteValues = new RouteValueDictionary() { { "area", AreaNames.Admin } }
            };
            MenuItemList.Add(new KeyValuePair<KeyValuePair<int, int>, SiteMapNode>
              (new KeyValuePair<int, int>(ID, ParentID), PayFasTransactionHistorySiteMapNode));
        }
        void Build_PayFastGateway_MAIN_TRANSACTION_HISTORY_SEARCH_MenuItem(List<KeyValuePair<KeyValuePair<int, int>, SiteMapNode>> MenuItemList, int ID, int ParentID)
        {
            SiteMapNode PayFasTransactionHistoryPeriodSiteMapNode = new SiteMapNode()
            {
                SystemName = "PayFast Transaction History",
                Title = "Transaction History",
                ControllerName = "PayFastTransactionHistroy",
                ActionName = "List",
                Visible = true,
                IconClass = "fa-dot-circle-o",
                RouteValues = new RouteValueDictionary() { { "area", AreaNames.Admin } }
            };
            MenuItemList.Add(new KeyValuePair<KeyValuePair<int, int>, SiteMapNode>
              (new KeyValuePair<int, int>(ID, ParentID), PayFasTransactionHistoryPeriodSiteMapNode));
        }
        void Build_PayFastGateway_MAIN_TRANSACTION_HISTORY_MAINTENENCE_MenuItem(List<KeyValuePair<KeyValuePair<int, int>, SiteMapNode>> MenuItemList, int ID, int ParentID)
        {
            SiteMapNode PayFasTransactionHistoryPeriodSiteMapNode = new SiteMapNode()
            {
                SystemName = "PayFast Transaction History Maintenance",
                Title = "Transaction Maintenance",
                ControllerName = "PayFastTransactionHistroy",
                ActionName = "TransactionMaintenence",
                Visible = true,
                IconClass = "fa-dot-circle-o",
                RouteValues = new RouteValueDictionary() { { "area", AreaNames.Admin } }
            };
            MenuItemList.Add(new KeyValuePair<KeyValuePair<int, int>, SiteMapNode>
              (new KeyValuePair<int, int>(ID, ParentID), PayFasTransactionHistoryPeriodSiteMapNode));
        }
        void Build_PayFastGateway_MAIN_TRANSACTION_HISTORY_WEEKLY_MenuItem(List<KeyValuePair<KeyValuePair<int, int>, SiteMapNode>> MenuItemList, int ID, int ParentID)
        {
            SiteMapNode PayFasTransactionHistoryPeriodSiteMapNode = new SiteMapNode()
            {
                SystemName = "PayFast Transaction Histroy Weekly",
                Title = "Weekly Transactions",
                ControllerName = "PayFastTransactionHistroy",
                ActionName = "ListWeeklyTransactions",
                Visible = true,
                IconClass = "fa-dot-circle-o",
                RouteValues = new RouteValueDictionary() { { "area", AreaNames.Admin } }
            };
            MenuItemList.Add(new KeyValuePair<KeyValuePair<int, int>, SiteMapNode>
              (new KeyValuePair<int, int>(ID, ParentID), PayFasTransactionHistoryPeriodSiteMapNode));
        }
        void Build_PayFastGateway_MAIN_TRANSACTION_HISTORY_MONTHLY_MenuItem(List<KeyValuePair<KeyValuePair<int, int>, SiteMapNode>> MenuItemList, int ID, int ParentID)
        {
            SiteMapNode PayFasTransactionHistoryPeriodSiteMapNode = new SiteMapNode()
            {

                SystemName = "PayFast Transaction Histroy Monthly",
                Title = "Monthly Transactions",
                ControllerName = "PayFastTransactionHistroy",
                ActionName = "ListMonthlyTransactions",
                Visible = true,
                IconClass = "fa-dot-circle-o",
                RouteValues = new RouteValueDictionary() { { "area", AreaNames.Admin } }
            };
            MenuItemList.Add(new KeyValuePair<KeyValuePair<int, int>, SiteMapNode>
              (new KeyValuePair<int, int>(ID, ParentID), PayFasTransactionHistoryPeriodSiteMapNode));
        }

        #endregion

        #region Recurring Billing
        void Build_PayFastGateway_MAIN_RECURRING_BILLING_MenuItem(List<KeyValuePair<KeyValuePair<int, int>, SiteMapNode>> MenuItemList, int ID, int ParentID)
        {
            SiteMapNode PayFastRecurringBillingSiteMapNode = new SiteMapNode()
            {
                SystemName = "PayFast Recurring Billing",
                Title = "Recurring Billing",
                Visible = true,
                IconClass = "fa-credit-card",
                RouteValues = new RouteValueDictionary() { { "area", AreaNames.Admin } }
            };
            MenuItemList.Add(new KeyValuePair<KeyValuePair<int, int>, SiteMapNode>
              (new KeyValuePair<int, int>(ID, ParentID), PayFastRecurringBillingSiteMapNode));
        }
        void Build_PayFastGateway_MAIN_RECURRING_BILLING_SUBSCRIPTION_PAYMENTS_MenuItem(List<KeyValuePair<KeyValuePair<int, int>, SiteMapNode>> MenuItemList, int ID, int ParentID)
        {
            SiteMapNode PayFastRecurringBillingSubscriptionPaymentsSiteMapNode = new SiteMapNode()
            {
                SystemName = "PayFast Recurring Billing Subscription Payments",
                Title = " Subscription Payments",
                ControllerName = "PayFastRecurringBilling",
                ActionName = "ListSubscriptionPayments",
                Visible = true,
                IconClass = "fa-dot-circle-o",
                RouteValues = new RouteValueDictionary() { { "area", AreaNames.Admin } }
            }; MenuItemList.Add(new KeyValuePair<KeyValuePair<int, int>, SiteMapNode>
               (new KeyValuePair<int, int>(ID, ParentID), PayFastRecurringBillingSubscriptionPaymentsSiteMapNode));
        }
        void Build_PayFastGateway_MAIN_RECURRING_BILLING_AD_HOC_PAYMENTS_MenuItem(List<KeyValuePair<KeyValuePair<int, int>, SiteMapNode>> MenuItemList, int ID, int ParentID)
        {
            SiteMapNode PayFastRecurringBillingAdHocPaymentsSiteMapNode = new SiteMapNode()
            {
                SystemName = "PayFast Recurring Billing Ad Hoc Payments",
                Title = "Ad Hoc Payments",
                ControllerName = "PayFastRecurringBilling",
                ActionName = "ListAdHocPayments",
                Visible = true,
                IconClass = "fa-dot-circle-o",
                RouteValues = new RouteValueDictionary() { { "area", AreaNames.Admin } }
            };
            MenuItemList.Add(new KeyValuePair<KeyValuePair<int, int>, SiteMapNode>
               (new KeyValuePair<int, int>(ID, ParentID), PayFastRecurringBillingAdHocPaymentsSiteMapNode));
        }

        #endregion

        #region Configuration Menu Items
        void Build_PayFastGateway_MAIN_CONFIGURATION_MenuItem(List<KeyValuePair<KeyValuePair<int, int>, SiteMapNode>> MenuItemList, int ID, int ParentID)
        {
            SiteMapNode PayFastMainConfigurationSiteMapNode = new SiteMapNode()
            {
                SystemName = "PayFast Configuration",
                Title = "PayFast Configuration",
                Visible = true,
                IconClass = "glyphicon glyphicon-fullscreen",
                RouteValues = new RouteValueDictionary() { { "area", AreaNames.Admin } }
            };
            MenuItemList.Add(new KeyValuePair<KeyValuePair<int, int>, SiteMapNode>
              (new KeyValuePair<int, int>(ID, ParentID), PayFastMainConfigurationSiteMapNode));
        }
        void Build_PayFastGateway_MAIN_CONFIGURATION_SECURITY_SETTINGS_MenuItem(List<KeyValuePair<KeyValuePair<int, int>, SiteMapNode>> MenuItemList, int ID, int ParentID)
        {
            SiteMapNode PayFastSecuritySettingsSiteMapNode = new SiteMapNode()
            {
                SystemName = "PayFast Main Configuration Security Settings",
                Title = " Security Settings",
                ControllerName = "PayFastConfiguration",
                ActionName = "ListSecuritySettings",
                Visible = true,
                IconClass = "fa-dot-circle-o",
                RouteValues = new RouteValueDictionary() { { "area", AreaNames.Admin } }
            }; MenuItemList.Add(new KeyValuePair<KeyValuePair<int, int>, SiteMapNode>
               (new KeyValuePair<int, int>(ID, ParentID), PayFastSecuritySettingsSiteMapNode));
        }
        void Build_PayFastGateway_MAIN_CONFIGURATION_ADDITIONAL_CHARGES_MenuItem(List<KeyValuePair<KeyValuePair<int, int>, SiteMapNode>> MenuItemList, int ID, int ParentID)
        {
            SiteMapNode PayFastAdditionalChargesSiteMapNode = new SiteMapNode()
            {
                SystemName = "PayFast Main Configuration Additional Charges",
                Title = "Additional Charges",
                ControllerName = "PayFastConfiguration",
                ActionName = "ListAdditionalCharges",
                Visible = true,
                IconClass = "fa-dot-circle-o",
                RouteValues = new RouteValueDictionary() { { "area", AreaNames.Admin } }
            }; MenuItemList.Add(new KeyValuePair<KeyValuePair<int, int>, SiteMapNode>
               (new KeyValuePair<int, int>(ID, ParentID), PayFastAdditionalChargesSiteMapNode));
        }
        void Build_PayFastGateway_MAIN_CONFIGURATION_TESTING_MODE_MenuItem(List<KeyValuePair<KeyValuePair<int, int>, SiteMapNode>> MenuItemList, int ID, int ParentID)
        {
            SiteMapNode PayFastConfigurationTestingSiteMapNode = new SiteMapNode()
            {
                SystemName = "PayFast Main Configuration Testing Mode",
                Title = "Configuration Testing",
                ControllerName = "PayFastConfiguration",
                ActionName = "ListConfigurationTesting",
                Visible = true,
                IconClass = "fa-dot-circle-o",
                RouteValues = new RouteValueDictionary() { { "area", AreaNames.Admin } }
            }; MenuItemList.Add(new KeyValuePair<KeyValuePair<int, int>, SiteMapNode>
               (new KeyValuePair<int, int>(ID, ParentID), PayFastConfigurationTestingSiteMapNode));
        }
        void Build_PayFastGateway_MAIN_CONFIGURATION_URL_CONFIG_MenuItem(List<KeyValuePair<KeyValuePair<int, int>, SiteMapNode>> MenuItemList, int ID, int ParentID)
        {
            SiteMapNode PayFastUrlConfigurationSiteMapNode = new SiteMapNode()
            {
                SystemName = "PayFast Main Configuration URL Config",
                Title = "URL Configuration",
                ControllerName = "PayFastConfiguration",
                ActionName = "ListURLConfiguration",
                Visible = true,
                IconClass = "fa-dot-circle-o",
                RouteValues = new RouteValueDictionary() { { "area", AreaNames.Admin } }
            }; MenuItemList.Add(new KeyValuePair<KeyValuePair<int, int>, SiteMapNode>
               (new KeyValuePair<int, int>(ID, ParentID), PayFastUrlConfigurationSiteMapNode));
        }


        void Build_PayFastGateway_MAIN_CONFIGURATION_SPLIT_PAYMENTS_MenuItem(List<KeyValuePair<KeyValuePair<int, int>, SiteMapNode>> MenuItemList, int ID, int ParentID)
        {
            SiteMapNode PayFastSplitPaymentSiteMapNode = new SiteMapNode()
            {
                SystemName = "PayFast Main Configuration Split Payments",
                Title = "Split Payments",
                ControllerName = "PayFastConfiguration",
                ActionName = "ListSplitPayments",
                Visible = true,
                IconClass = "fa-dot-circle-o",
                RouteValues = new RouteValueDictionary() { { "area", AreaNames.Admin } }
            }; MenuItemList.Add(new KeyValuePair<KeyValuePair<int, int>, SiteMapNode>
               (new KeyValuePair<int, int>(ID, ParentID), PayFastSplitPaymentSiteMapNode));
        }


        #endregion

        #endregion


    }
}
