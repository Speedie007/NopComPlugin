﻿using FluentValidation;
using Nop.Plugin.Payments.PayFastComplete.Areas.Admin.Models.TransactionalHistory;
using Nop.Web.Framework.Validators;
using System;
using System.Collections.Generic;
using System.Text;

namespace Nop.Plugin.Payments.PayFastComplete.Validators
{
    public partial class TransactionHistoryValidators : BaseNopValidator<TransactionHistroyMaintenanceViewModel>
    {

        #region Cstor
        public TransactionHistoryValidators(
           )
        {
            #region Rules
            RuleFor(x => x.StartDatetime).Must((StartDatetimeObj, context) =>
            {
                if (StartDatetimeObj.StartDatetime > StartDatetimeObj.EndDatetime)
                {
                    return false;
                }
               
                return true;
            }).WithMessage("Start date time can not be greater that the end date.");//localizationService.GetResource("Account.Fields.StateProvince.Required"));
            RuleFor(x => x.EndDatetime).Must((EndDateTimeObj, context) =>
            {
                if (EndDateTimeObj.EndDatetime < EndDateTimeObj.StartDatetime)
                {
                    return false;
                }

                return true;
            }).WithMessage("End date time can not be Less that the Start date.");//localizationService.GetResource("Account.Fields.StateProvince.Required"));
            #endregion
        }
        #endregion


    }
}