﻿using FluentValidation;
using Nop.Plugin.Payments.PayFastComplete.Areas.Admin.Models.Configuration;
using Nop.Web.Framework.Validators;

namespace Nop.Plugin.Payments.PayFastComplete.Validators
{
    public partial class SplitPaymentValidators : BaseNopValidator<SpiltPaymentsViewModel>
    {

        #region Cstor
        public SplitPaymentValidators(
           )
        {
            #region Rules
            RuleFor(x => x.RecievingMerchantId).Must((isActive, context) =>
            {
                if (isActive.IsSplitPaymentActive)
                {
                    if (isActive.RecievingMerchantId == null)
                    {
                        return false;
                    }
                    if (isActive.RecievingMerchantId.Length < 8 || isActive.RecievingMerchantId.Length > 8)
                    {
                        return false;
                    }
                    foreach (var item in isActive.RecievingMerchantId.ToCharArray())
                    {
                        if (char.IsLetter(item) || char.IsWhiteSpace(item) || char.IsPunctuation(item))
                        {
                            return false;
                        }
                    } 
                    
                }
                return true;
            }).WithMessage("The Merchant ID can not be blank, it must also be 8 digits long else its not valid.");//localizationService.GetResource("Account.Fields.StateProvince.Required"));
            #endregion
        }
        #endregion


    }
}
