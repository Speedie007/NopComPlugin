﻿using FluentValidation;
using Nop.Plugin.Payments.PayFastComplete.Areas.Admin.Models.Configuration;
using Nop.Plugin.Payments.PayFastComplete.Settings;
using Nop.Services.Localization;
using Nop.Web.Framework.Validators;
using System;
using System.Collections.Generic;
using System.Text;

namespace Nop.Plugin.Payments.PayFastComplete.Validators
{
    public partial class SecuritySettingsValidators : BaseNopValidator<SecuritySettingsViewModel>
    {

        #region Cstor
        public SecuritySettingsValidators(
           )
        {
            #region Rules
            RuleFor(x => x.APIPassPhrase).NotEmpty().WithMessage("Required* - The PassPhrase is compolsary as this is used to secure the data sent between the system and PayFast. if you have not yet saet up a PassPhrase in your PayFast Portal, please do so now!");
            RuleFor(x => x.MerchantKey).NotEmpty().WithMessage("Required* - The Merchant Key is compolsary as this is used to secure the data sent between the system and PayFast. Your Merchant Key can be found in your PayFast Portal!");
            RuleFor(x => x.MerchantId).NotEmpty().WithMessage("Required* - The Merchant ID is compolsary as this is used to identify form whom the data comes from on the PayFast system. Your Merchant ID can be found in your PayFast Portal!");
            #endregion
        }
        #endregion


    }
}
