﻿using Nop.Core;
using Nop.Core.Domain.Orders;
using Nop.Plugin.Payments.PayFastComplete.Services.RecurringPaymentsServices;
using Nop.Services.Orders;
using Nop.Services.Payments;
using Nop.Services.Stores;
using Nop.Services.Tasks;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Nop.Plugin.Payments.PayFastComplete.TaskScheduler
{
    public partial class RecurringPaymentTask : IScheduleTask
    {
        private readonly IOrderProcessingService _orderProcessingService;
        private readonly IPaymentService _paymentService;
        private readonly IRecurringPaymentTaskService _recurringPaymentService;

        #region Fields
        private readonly IOrderService _orderService;
        private readonly IStoreContext _storeContext;
        #endregion


        #region ctor
        public RecurringPaymentTask(
            IOrderService orderService,
             IStoreContext storeContext,
             IPaymentService paymentService,
             IOrderProcessingService orderProcessingService,
             IRecurringPaymentTaskService recurringPaymentService
            )
        {
            _orderProcessingService = orderProcessingService;
            _paymentService = paymentService;
            _recurringPaymentService = recurringPaymentService;
            _orderService = orderService;
            _storeContext = storeContext;
        }
        #endregion
        public void Execute()
        {
            var recurringPaymentList = _orderService.SearchRecurringPayments(storeId: _storeContext.CurrentStore.Id);

            foreach (var rp in recurringPaymentList.Where(x => x.IsActive).ToList())
            {
                var NextPaymentDate = _orderProcessingService.GetNextPaymentDate(rp);

                //if (NextPaymentDate > DateTime.Now)
                //{
                    Order order = _orderService.GetOrderById(rp.InitialOrderId);
                    if (order.SubscriptionTransactionId is string token)
                    {
                        _recurringPaymentService.ProcessRecurringPayment(order);
                    }
                //}
            }
        }
    }
}
