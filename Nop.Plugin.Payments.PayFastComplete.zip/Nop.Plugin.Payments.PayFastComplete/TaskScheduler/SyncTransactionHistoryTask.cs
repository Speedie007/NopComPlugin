﻿using Nop.Plugin.Payments.PayFastComplete.Services.IPayFastApiClientServices;
using Nop.Plugin.Payments.PayFastComplete.Services.PayFastApiClientServices.Models.Api.Results.TransactionHistroy;
using Nop.Plugin.Payments.PayFastComplete.Services.TransactionHistoryServices;
using Nop.Services.Logging;
using Nop.Services.Tasks;
using System;

namespace Nop.Plugin.Payments.PayFastComplete.TaskScheduler
{
    public partial class SyncTransactionHistoryTask : IScheduleTask
    {
        private readonly IPayFastTransactionHistoryService _payFastTransactionHistoryService;
        private readonly IPayFastApiClientService _payFastApiClientService;
        private readonly ILogger _logger;

        #region Ctor
        public SyncTransactionHistoryTask(

            ILogger logger,
            IPayFastApiClientService   payFastApiClientService,
            IPayFastTransactionHistoryService payFastTransactionHistoryService)
        {
            _payFastTransactionHistoryService = payFastTransactionHistoryService;
            _payFastApiClientService = payFastApiClientService;
            _logger = logger;
        }
        #endregion

        #region Methods
        public void Execute()
        {
            //IF Api Active.
            if (_payFastApiClientService.PingPayFastApiGateway().Success)
            {
                //cause no date is supplied it defaults to todays date.
                TransactionHistoryPayFastApiGatewayResult result =_payFastApiClientService.GetTransactionHistoryBySelectedDailyPeriod();

                if (result.Success)
                {
                    var ArchiveResult = _payFastTransactionHistoryService.ArchiveTransactionHistoryByDay();

                    if (!ArchiveResult.Success)
                        result.CombineError(ArchiveResult.Errors);
                }
                else
                {
                    foreach (var item in result.Errors)
                    {
                        _logger.Error($"Error getting the daily transaction records to update the archive from the task scheduler : [{DateTime.Now}], Internal Errors :[{item}]", null, null);
                    }
                }
            }
        }
        #endregion
    }


}
